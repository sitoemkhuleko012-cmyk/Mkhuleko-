import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import {
  claimInitialAdminPassword,
  createAdminSession,
  createArticle,
  createContactMessage,
  deleteArticle,
  deleteContactMessage,
  deleteSubscriberById,
  getAdminAuthStatus,
  getAllArticles,
  getArticleById,
  getArticleBySlug,
  getSiteSettings,
  listContactMessagesForAdmin,
  listSubscribersForAdmin,
  markContactMessageStatus,
  revokeAdminSession,
  subscribeNewsletter,
  unsubscribeNewsletter,
  updateArticle,
  updateSiteSettings,
  validateAdminSession,
  verifyAdminPasscode,
} from './src/server/db.ts';
import {
  getEmailServiceStatus,
  sendContactNotificationEmail,
  sendWelcomeNewsletterEmail,
} from './src/server/email.ts';
import { buildAllArticlesHtmlDocument } from './src/server/exportHtml.ts';
import { buildWebsiteSourceZip } from './src/server/websiteZip.ts';
import type { ArticleCategory } from './src/shared/types.ts';

const PORT = Number(process.env.PORT) || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';

const uploadsDir = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const VALID_CATEGORIES = new Set<ArticleCategory>([
  'Supercars',
  'Luxury Cars',
  'Comparisons',
  'Car Reviews',
  'Latest Updates',
]);

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}

function sanitizeHttpUrl(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return parsed.toString();
    }
  } catch {
    return '';
  }
  return '';
}

function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 90);
}

function getBaseUrl(req: Request): string {
  const configured = (process.env.APP_URL || '').trim();
  if (configured && configured !== 'MY_APP_URL') {
    return configured.replace(/\/+$/, '');
  }
  const proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'http';
  const host = (req.headers['x-forwarded-host'] as string) || req.get('host') || `localhost:${PORT}`;
  return `${proto}://${host}`;
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function escapeHtmlAttr(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization || '';
  const match = authHeader.match(/^Bearer\s+([a-f0-9]{64})$/i);
  if (!match) {
    res.status(401).json({ error: 'Administrator authentication required.' });
    return;
  }
  const token = match[1];
  if (!validateAdminSession(token)) {
    res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
    return;
  }
  next();
}

async function startServer() {
  const app = express();
  app.set('trust proxy', true);

  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.use(express.json({ limit: '10mb' }));

  // --- Serve Uploaded Images Safely (Path-Confined) ---
  app.get('/uploads/:filename', (req, res) => {
    const filename = path.basename(req.params.filename || '');
    if (!/^[a-zA-Z0-9._-]+$/.test(filename)) {
      res.status(400).send('Invalid filename');
      return;
    }
    const resolved = path.resolve(uploadsDir, filename);
    if (!resolved.startsWith(uploadsDir + path.sep) || !fs.existsSync(resolved)) {
      res.status(404).send('Not found');
      return;
    }
    res.sendFile(resolved);
  });

  // --- SEO: robots.txt & dynamic sitemap.xml ---
  app.get('/robots.txt', (req, res) => {
    const base = getBaseUrl(req);
    res.type('text/plain');
    res.send(
      [
        'User-agent: *',
        'Allow: /',
        'Disallow: /admin',
        'Disallow: /api/admin',
        `Sitemap: ${base}/sitemap.xml`,
      ].join('\n')
    );
  });

  app.get('/sitemap.xml', (req, res) => {
    const base = getBaseUrl(req);
    const articles = getAllArticles();
    const staticPaths = [
      { loc: '/', priority: '1.0', changefreq: 'daily' },
      { loc: '/supercars', priority: '0.9', changefreq: 'daily' },
      { loc: '/luxury-cars', priority: '0.9', changefreq: 'daily' },
      { loc: '/comparisons', priority: '0.9', changefreq: 'weekly' },
      { loc: '/car-reviews', priority: '0.9', changefreq: 'weekly' },
      { loc: '/latest-updates', priority: '0.9', changefreq: 'daily' },
      { loc: '/about-us', priority: '0.7', changefreq: 'monthly' },
      { loc: '/contact-us', priority: '0.7', changefreq: 'monthly' },
      { loc: '/privacy-policy', priority: '0.5', changefreq: 'yearly' },
      { loc: '/cookie-policy', priority: '0.5', changefreq: 'yearly' },
      { loc: '/terms-and-conditions', priority: '0.5', changefreq: 'yearly' },
    ];

    const today = new Date().toISOString().split('T')[0];
    const urlNodes = [
      ...staticPaths.map(
        (p) => `  <url>
    <loc>${escapeXml(base + p.loc)}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${p.changefreq}</changefreq>
    <priority>${p.priority}</priority>
  </url>`
      ),
      ...articles.map(
        (a) => `  <url>
    <loc>${escapeXml(`${base}/article/${a.slug}`)}</loc>
    <lastmod>${escapeXml((a.updatedAt || a.publishedAt).split('T')[0])}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>`
      ),
    ];

    res.type('application/xml');
    res.send(
      `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urlNodes.join('\n')}\n</urlset>`
    );
  });

  // --- Public API Routes ---
  app.get('/api/bootstrap', (_req, res) => {
    const articles = getAllArticles();
    const settings = getSiteSettings();
    const emailService = getEmailServiceStatus();
    res.json({ articles, settings, emailService });
  });

  app.get('/api/articles', (req, res) => {
    const category = typeof req.query.category === 'string' ? req.query.category : undefined;
    const q = typeof req.query.q === 'string' ? req.query.q : undefined;
    res.json({ articles: getAllArticles(category, q) });
  });

  app.get('/api/export/articles.html', (_req, res) => {
    const articles = getAllArticles();
    const html = buildAllArticlesHtmlDocument(articles);
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="apex-auto-articles.html"');
    res.send(html);
  });

  app.get('/api/export/articles.json', (_req, res) => {
    const articles = getAllArticles();
    const payload = {
      publication: 'APEX AUTO',
      tagline: 'THE WORLD OF PERFORMANCE & LUXURY.',
      publisher: 'Mkhuleko Sitoe',
      exportedAt: new Date().toISOString(),
      count: articles.length,
      articles,
    };
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="apex-auto-articles.json"');
    res.send(JSON.stringify(payload, null, 2));
  });

  app.get('/api/articles/:slug', (req, res) => {
    const article = getArticleBySlug(req.params.slug);
    if (!article) {
      res.status(404).json({ error: 'Article not found.' });
      return;
    }
    const all = getAllArticles();
    const related = all
      .filter((a) => a.id !== article.id && a.category === article.category)
      .slice(0, 3);
    const fallbackRelated =
      related.length >= 3
        ? related
        : [
            ...related,
            ...all.filter((a) => a.id !== article.id && !related.some((r) => r.id === a.id)),
          ].slice(0, 3);

    res.json({ article, related: fallbackRelated });
  });

  app.get('/api/settings', (_req, res) => {
    res.json({ settings: getSiteSettings() });
  });

  app.get('/api/newsletter/status', (_req, res) => {
    res.json(getEmailServiceStatus());
  });

  app.post('/api/newsletter/subscribe', async (req, res) => {
    const email = typeof req.body?.email === 'string' ? req.body.email.trim() : '';
    const consent = Boolean(req.body?.consent);

    if (!consent) {
      res.status(400).json({ error: 'Please confirm your consent to receive editorial updates.' });
      return;
    }
    if (!isValidEmail(email)) {
      res.status(400).json({ error: 'Please provide a valid email address.' });
      return;
    }

    const { alreadySubscribed, unsubscribeToken } = subscribeNewsletter(email);
    const base = getBaseUrl(req);
    const unsubscribeUrl = `${base}/unsubscribe?token=${encodeURIComponent(unsubscribeToken)}`;

    if (alreadySubscribed) {
      res.json({
        ok: true,
        alreadySubscribed: true,
        emailDispatched: false,
        emailServiceConfigured: getEmailServiceStatus().configured,
        message: 'This email address is already subscribed to APEX AUTO.',
      });
      return;
    }

    const mailResult = await sendWelcomeNewsletterEmail(email, unsubscribeUrl);
    res.status(201).json({
      ok: true,
      alreadySubscribed: false,
      emailDispatched: mailResult.sent,
      emailServiceConfigured: getEmailServiceStatus().configured,
      message: mailResult.sent
        ? 'Welcome to APEX AUTO. A confirmation email with an unsubscribe link has been sent to your inbox.'
        : 'Your subscription has been securely recorded in the APEX AUTO subscriber database. Automated email dispatch requires SMTP configuration on the server.',
    });
  });

  app.post('/api/newsletter/unsubscribe', (req, res) => {
    const token = typeof req.body?.token === 'string' ? req.body.token.trim() : '';
    const email = typeof req.body?.email === 'string' ? req.body.email.trim() : '';

    if (!token && !isValidEmail(email)) {
      res.status(400).json({ error: 'Provide a valid email address or unsubscribe token.' });
      return;
    }

    const updated = unsubscribeNewsletter({
      token: token || undefined,
      email: email || undefined,
    });

    if (!updated) {
      res.status(404).json({ error: 'No active subscription matched the provided details.' });
      return;
    }

    res.json({
      ok: true,
      message: 'You have been unsubscribed from APEX AUTO editorial mailings.',
    });
  });

  app.post('/api/contact', async (req, res) => {
    const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
    const email = typeof req.body?.email === 'string' ? req.body.email.trim() : '';
    const subject = typeof req.body?.subject === 'string' ? req.body.subject.trim() : '';
    const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';

    if (name.length < 2 || name.length > 120) {
      res.status(400).json({ error: 'Please enter your full name (2–120 characters).' });
      return;
    }
    if (!isValidEmail(email)) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }
    if (subject.length < 2 || subject.length > 160) {
      res.status(400).json({ error: 'Please enter a subject (2–160 characters).' });
      return;
    }
    if (message.length < 10 || message.length > 5000) {
      res.status(400).json({ error: 'Please enter a message (10–5000 characters).' });
      return;
    }

    createContactMessage({ name, email, subject, message });
    const mailResult = await sendContactNotificationEmail({ name, email, subject, message });

    res.status(201).json({
      ok: true,
      emailDispatched: mailResult.sent,
      message: mailResult.sent
        ? 'Your message has been delivered to the APEX AUTO editorial desk.'
        : 'Your inquiry has been securely saved to the APEX AUTO editorial inbox for review.',
    });
  });

  // --- Admin Auth Routes ---
  app.get('/api/admin/auth/status', (_req, res) => {
    res.json(getAdminAuthStatus());
  });

  app.post('/api/admin/auth/setup', (req, res) => {
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const result = claimInitialAdminPassword(password);
    if (!result.ok) {
      res.status(400).json({ error: result.error });
      return;
    }
    const token = createAdminSession();
    res.status(201).json({ token });
  });

  app.post('/api/admin/auth/login', (req, res) => {
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!password || !verifyAdminPasscode(password)) {
      res.status(401).json({ error: 'Invalid administrator credentials.' });
      return;
    }
    const token = createAdminSession();
    res.json({ token });
  });

  app.post('/api/admin/auth/logout', (req, res) => {
    const authHeader = req.headers.authorization || '';
    const match = authHeader.match(/^Bearer\s+([a-f0-9]{64})$/i);
    if (match) {
      revokeAdminSession(match[1]);
    }
    res.json({ ok: true });
  });

  // --- Protected Admin Routes ---
  app.get('/api/admin/dashboard', requireAdmin, (_req, res) => {
    res.json({
      articles: getAllArticles(),
      settings: getSiteSettings(),
      subscribers: listSubscribersForAdmin(),
      messages: listContactMessagesForAdmin(),
      emailService: getEmailServiceStatus(),
    });
  });

  app.post('/api/admin/upload', requireAdmin, (req, res) => {
    const dataUrl = typeof req.body?.dataUrl === 'string' ? req.body.dataUrl : '';
    const match = dataUrl.match(/^data:(image\/(jpeg|jpg|png|webp));base64,([A-Za-z0-9+/=]+)$/);
    if (!match) {
      res.status(400).json({ error: 'Only JPEG, PNG, or WebP images are permitted.' });
      return;
    }

    const mimeSubtype = match[2] === 'jpg' ? 'jpeg' : match[2];
    const buffer = Buffer.from(match[3], 'base64');
    if (buffer.length > 5 * 1024 * 1024) {
      res.status(400).json({ error: 'Image size must not exceed 5 MB.' });
      return;
    }

    // Verify basic magic bytes
    const isJpeg = buffer[0] === 0xff && buffer[1] === 0xd8;
    const isPng =
      buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47;
    const isWebp =
      buffer.subarray(0, 4).toString('ascii') === 'RIFF' &&
      buffer.subarray(8, 12).toString('ascii') === 'WEBP';

    if (
      (mimeSubtype === 'jpeg' && !isJpeg) ||
      (mimeSubtype === 'png' && !isPng) ||
      (mimeSubtype === 'webp' && !isWebp)
    ) {
      res.status(400).json({ error: 'Uploaded file signature does not match image format.' });
      return;
    }

    const ext = mimeSubtype === 'jpeg' ? 'jpg' : mimeSubtype;
    const filename = `apex-${Date.now()}-${crypto.randomBytes(6).toString('hex')}.${ext}`;
    const dest = path.resolve(uploadsDir, filename);
    if (!dest.startsWith(uploadsDir + path.sep)) {
      res.status(400).json({ error: 'Invalid upload destination.' });
      return;
    }

    fs.writeFileSync(dest, buffer);
    res.status(201).json({ url: `/uploads/${filename}` });
  });

  app.post('/api/admin/articles', requireAdmin, (req, res) => {
    const body = req.body || {};
    const title = typeof body.title === 'string' ? body.title.trim() : '';
    const description = typeof body.description === 'string' ? body.description.trim() : '';
    const category = body.category as ArticleCategory;
    const content = typeof body.content === 'string' ? body.content.trim() : '';
    const featuredImage = typeof body.featuredImage === 'string' ? body.featuredImage.trim() : '';

    if (!title || !description || !VALID_CATEGORIES.has(category) || !content || !featuredImage) {
      res.status(400).json({
        error: 'Title, description, valid category, featured image, and article content are required.',
      });
      return;
    }

    const baseSlug = slugify(typeof body.slug === 'string' && body.slug.trim() ? body.slug : title) || `article-${Date.now()}`;
    let finalSlug = baseSlug;
    let suffix = 1;
    while (getArticleBySlug(finalSlug)) {
      finalSlug = `${baseSlug}-${suffix++}`;
    }

    const created = createArticle({
      slug: finalSlug,
      title,
      description,
      category,
      manufacturer: typeof body.manufacturer === 'string' ? body.manufacturer.trim() : '',
      author: typeof body.author === 'string' && body.author.trim() ? body.author.trim() : 'Sitoe Mkhuleko',
      publishedAt:
        typeof body.publishedAt === 'string' && body.publishedAt.trim()
          ? body.publishedAt.trim()
          : new Date().toISOString().split('T')[0],
      featuredImage,
      imageCaption: typeof body.imageCaption === 'string' ? body.imageCaption.trim() : '',
      content,
      isFeatured: Boolean(body.isFeatured),
      isTrending: Boolean(body.isTrending),
      readTime: typeof body.readTime === 'string' && body.readTime.trim() ? body.readTime.trim() : '5 min read',
      specs: body.specs && typeof body.specs === 'object' ? body.specs : {},
      pros: Array.isArray(body.pros) ? body.pros.filter((x: unknown) => typeof x === 'string' && x.trim()) : [],
      cons: Array.isArray(body.cons) ? body.cons.filter((x: unknown) => typeof x === 'string' && x.trim()) : [],
      verdict: typeof body.verdict === 'string' ? body.verdict.trim() : '',
      rating: Number(body.rating) || 0,
      comparisonVehicles: Array.isArray(body.comparisonVehicles) ? body.comparisonVehicles : [],
      seoTitle: typeof body.seoTitle === 'string' ? body.seoTitle.trim() : '',
      seoDescription: typeof body.seoDescription === 'string' ? body.seoDescription.trim() : '',
    });

    res.status(201).json({ article: created });
  });

  app.put('/api/admin/articles/:id', requireAdmin, (req, res) => {
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid article ID.' });
      return;
    }
    const existing = getArticleById(id);
    if (!existing) {
      res.status(404).json({ error: 'Article not found.' });
      return;
    }

    const body = req.body || {};
    if (body.category && !VALID_CATEGORIES.has(body.category)) {
      res.status(400).json({ error: 'Invalid category.' });
      return;
    }

    let nextSlug = existing.slug;
    if (typeof body.slug === 'string' && body.slug.trim()) {
      const candidate = slugify(body.slug);
      const conflict = getArticleBySlug(candidate);
      if (!conflict || conflict.id === id) {
        nextSlug = candidate;
      }
    }

    const updated = updateArticle(id, {
      slug: nextSlug,
      title: typeof body.title === 'string' ? body.title.trim() : existing.title,
      description: typeof body.description === 'string' ? body.description.trim() : existing.description,
      category: body.category || existing.category,
      manufacturer: typeof body.manufacturer === 'string' ? body.manufacturer.trim() : existing.manufacturer,
      author: typeof body.author === 'string' ? body.author.trim() : existing.author,
      publishedAt: typeof body.publishedAt === 'string' ? body.publishedAt.trim() : existing.publishedAt,
      featuredImage: typeof body.featuredImage === 'string' ? body.featuredImage.trim() : existing.featuredImage,
      imageCaption: typeof body.imageCaption === 'string' ? body.imageCaption.trim() : existing.imageCaption,
      content: typeof body.content === 'string' ? body.content.trim() : existing.content,
      isFeatured: body.isFeatured !== undefined ? Boolean(body.isFeatured) : existing.isFeatured,
      isTrending: body.isTrending !== undefined ? Boolean(body.isTrending) : existing.isTrending,
      readTime: typeof body.readTime === 'string' ? body.readTime.trim() : existing.readTime,
      specs: body.specs && typeof body.specs === 'object' ? body.specs : existing.specs,
      pros: Array.isArray(body.pros) ? body.pros : existing.pros,
      cons: Array.isArray(body.cons) ? body.cons : existing.cons,
      verdict: typeof body.verdict === 'string' ? body.verdict.trim() : existing.verdict,
      rating: body.rating !== undefined ? Number(body.rating) || 0 : existing.rating,
      comparisonVehicles: Array.isArray(body.comparisonVehicles)
        ? body.comparisonVehicles
        : existing.comparisonVehicles,
      seoTitle: typeof body.seoTitle === 'string' ? body.seoTitle.trim() : existing.seoTitle,
      seoDescription:
        typeof body.seoDescription === 'string' ? body.seoDescription.trim() : existing.seoDescription,
    });

    res.json({ article: updated });
  });

  app.delete('/api/admin/articles/:id', requireAdmin, (req, res) => {
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid article ID.' });
      return;
    }
    const ok = deleteArticle(id);
    if (!ok) {
      res.status(404).json({ error: 'Article not found.' });
      return;
    }
    res.json({ ok: true });
  });

  app.put('/api/admin/settings', requireAdmin, (req, res) => {
    const body = req.body || {};
    const updated = updateSiteSettings({
      publisherName: typeof body.publisherName === 'string' ? body.publisherName.trim() : undefined,
      publisherBio: typeof body.publisherBio === 'string' ? body.publisherBio : undefined,
      publisherPhoto: typeof body.publisherPhoto === 'string' ? body.publisherPhoto.trim() : undefined,
      aboutContent: typeof body.aboutContent === 'string' ? body.aboutContent : undefined,
      privacyPolicy: typeof body.privacyPolicy === 'string' ? body.privacyPolicy : undefined,
      cookiePolicy: typeof body.cookiePolicy === 'string' ? body.cookiePolicy : undefined,
      termsContent: typeof body.termsContent === 'string' ? body.termsContent : undefined,
      instagramUrl: typeof body.instagramUrl === 'string' ? sanitizeHttpUrl(body.instagramUrl) : undefined,
      facebookUrl: typeof body.facebookUrl === 'string' ? sanitizeHttpUrl(body.facebookUrl) : undefined,
      seoSiteTitle: typeof body.seoSiteTitle === 'string' ? body.seoSiteTitle.trim() : undefined,
      seoSiteDescription:
        typeof body.seoSiteDescription === 'string' ? body.seoSiteDescription.trim() : undefined,
      googleSiteVerification:
        typeof body.googleSiteVerification === 'string'
          ? body.googleSiteVerification.trim()
          : undefined,
      adsensePublisherId:
        typeof body.adsensePublisherId === 'string' ? body.adsensePublisherId.trim() : undefined,
      adPlacements:
        body.adPlacements && typeof body.adPlacements === 'object' ? body.adPlacements : undefined,
    });

    res.json({ settings: updated });
  });

  app.delete('/api/admin/subscribers/:id', requireAdmin, (req, res) => {
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid subscriber ID.' });
      return;
    }
    deleteSubscriberById(id);
    res.json({ ok: true });
  });

  app.patch('/api/admin/messages/:id', requireAdmin, (req, res) => {
    const id = Number.parseInt(req.params.id, 10);
    const status = req.body?.status === 'read' ? 'read' : 'unread';
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid message ID.' });
      return;
    }
    markContactMessageStatus(id, status);
    res.json({ ok: true });
  });

  app.delete('/api/admin/messages/:id', requireAdmin, (req, res) => {
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: 'Invalid message ID.' });
      return;
    }
    deleteContactMessage(id);
    res.json({ ok: true });
  });

  app.get('/api/admin/export/website.zip', requireAdmin, (_req, res) => {
    try {
      const zipBytes = buildWebsiteSourceZip();
      const dateStr = new Date().toISOString().split('T')[0];
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="apex-auto-website-${dateStr}.zip"`
      );
      res.setHeader('Cache-Control', 'no-store');
      res.send(Buffer.from(zipBytes));
    } catch {
      res.status(500).json({ error: 'Failed to package website ZIP archive.' });
    }
  });

  // --- HTML SEO Injection helper ---
  function injectDynamicSeo(html: string, req: Request): string {
    const settings = getSiteSettings();
    const base = getBaseUrl(req);
    const urlPath = req.path;

    let title = settings.seoSiteTitle || 'APEX AUTO — The World of Performance & Luxury';
    let description = settings.seoSiteDescription;
    let extraMeta = '';

    if (settings.googleSiteVerification) {
      extraMeta += `\n    <meta name="google-site-verification" content="${escapeHtmlAttr(settings.googleSiteVerification)}" />`;
    }
    extraMeta += `\n    <link rel="canonical" href="${escapeHtmlAttr(base + urlPath)}" />`;

    const articleMatch = urlPath.match(/^\/article\/([^/]+)$/);
    if (articleMatch) {
      const article = getArticleBySlug(articleMatch[1]);
      if (article) {
        title = article.seoTitle || `${article.title} | APEX AUTO`;
        description = article.seoDescription || article.description;
        const ld = {
          '@context': 'https://schema.org',
          '@type': 'Article',
          headline: article.title,
          description: article.description,
          image: article.featuredImage.startsWith('http')
            ? article.featuredImage
            : `${base}${article.featuredImage}`,
          datePublished: article.publishedAt,
          dateModified: article.updatedAt,
          author: {
            '@type': 'Person',
            name: article.author || settings.publisherName,
          },
          publisher: {
            '@type': 'Organization',
            name: 'APEX AUTO',
          },
          mainEntityOfPage: {
            '@type': 'WebPage',
            '@id': `${base}/article/${article.slug}`,
          },
        };
        extraMeta += `\n    <script type="application/ld+json">${JSON.stringify(ld)}</script>`;
      }
    }

    return html
      .replace(/<title>.*?<\/title>/, `<title>${escapeHtmlAttr(title)}</title>`)
      .replace(
        /<meta\s+name="description"\s+content="[^"]*"\s*\/>/,
        `<meta name="description" content="${escapeHtmlAttr(description)}" />`
      )
      .replace(
        /<meta property="og:title" content="[^"]*"\s*\/>/,
        `<meta property="og:title" content="${escapeHtmlAttr(title)}" />`
      )
      .replace(
        /<meta\s+property="og:description"\s+content="[^"]*"\s*\/>/,
        `<meta property="og:description" content="${escapeHtmlAttr(description)}" />`
      )
      .replace('</head>', `${extraMeta}\n  </head>`);
  }

  // --- Vite Dev Middleware or Production Static Serving ---
  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });

    app.use(vite.middlewares);

    app.use(async (req, res, next) => {
      if (req.path.startsWith('/api/') || req.path.startsWith('/uploads/')) {
        next();
        return;
      }
      try {
        const indexPath = path.resolve(process.cwd(), 'index.html');
        let template = fs.readFileSync(indexPath, 'utf-8');
        template = await vite.transformIndexHtml(req.originalUrl, template);
        template = injectDynamicSeo(template, req);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (err) {
        vite.ssrFixStacktrace(err as Error);
        next(err);
      }
    });
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir, { index: false }));
    app.use((req, res, next) => {
      if (req.path.startsWith('/api/') || req.path.startsWith('/uploads/')) {
        next();
        return;
      }
      const indexPath = path.join(distDir, 'index.html');
      if (!fs.existsSync(indexPath)) {
        res.status(500).send('Production build not found. Run npm run build.');
        return;
      }
      const template = fs.readFileSync(indexPath, 'utf-8');
      res.status(200).set({ 'Content-Type': 'text/html' }).end(injectDynamicSeo(template, req));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`APEX AUTO editorial server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
