import { useCallback, useEffect, useState } from 'react';
import { CookieConsentModal } from './components/CookieConsentModal';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { fetchBootstrap } from './lib/api';
import {
  readCookieConsent,
  saveCookieConsent,
  syncOptionalConsentScripts,
} from './lib/cookies';
import { AboutPage } from './pages/AboutPage';
import { AdminPage } from './pages/AdminPage';
import { ArticleDetailPage } from './pages/ArticleDetailPage';
import { CategoryPage } from './pages/CategoryPage';
import { ContactPage } from './pages/ContactPage';
import { HomePage } from './pages/HomePage';
import { LegalPage } from './pages/LegalPage';
import { UnsubscribePage } from './pages/UnsubscribePage';
import type {
  Article,
  CookiePreferences,
  SiteSettings,
} from './shared/types';

const EMPTY_SETTINGS: SiteSettings = {
  publisherName: 'Sitoe Mkhuleko',
  publisherBio: '',
  publisherPhoto: '',
  aboutContent: '',
  privacyPolicy: '',
  cookiePolicy: '',
  termsContent: '',
  instagramUrl: '',
  facebookUrl: '',
  seoSiteTitle: 'APEX AUTO — The World of Performance & Luxury',
  seoSiteDescription:
    'International automotive magazine covering supercars, bespoke luxury vehicles, comparisons, car reviews, and industry updates.',
  googleSiteVerification: '',
  adsensePublisherId: '',
  adPlacements: {
    headerBannerEnabled: true,
    inArticleEnabled: true,
    sidebarEnabled: true,
    footerBannerEnabled: true,
  },
};

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(
    () => window.location.pathname || '/'
  );
  const [urlSearch, setUrlSearch] = useState<string>(() => window.location.search || '');
  const [articles, setArticles] = useState<Article[]>([]);
  const [settings, setSettings] = useState<SiteSettings>(EMPTY_SETTINGS);
  const [emailServiceConfigured, setEmailServiceConfigured] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [cookieConsent, setCookieConsent] = useState<CookiePreferences | null>(() =>
    readCookieConsent()
  );
  const [cookieModalOpen, setCookieModalOpen] = useState<boolean>(() => !readCookieConsent());

  const loadData = useCallback(async () => {
    try {
      const data = await fetchBootstrap();
      setArticles(data.articles);
      setSettings(data.settings);
      setEmailServiceConfigured(data.emailService.configured);
      setLoadError(null);
    } catch (err) {
      setLoadError(
        err instanceof Error ? err.message : 'Unable to connect to editorial server.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    const onPopState = () => {
      setCurrentPath(window.location.pathname || '/');
      setUrlSearch(window.location.search || '');
      window.scrollTo({ top: 0, behavior: 'auto' });
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    syncOptionalConsentScripts(cookieConsent, settings.adsensePublisherId);
  }, [cookieConsent, settings.adsensePublisherId]);

  useEffect(() => {
    const titleMap: Record<string, string> = {
      '/': settings.seoSiteTitle || 'APEX AUTO — The World of Performance & Luxury',
      '/supercars': 'Supercars & Hypercars | APEX AUTO',
      '/luxury-cars': 'Luxury Cars & Grand Tourers | APEX AUTO',
      '/comparisons': 'Car Comparisons & Specifications | APEX AUTO',
      '/car-reviews': 'Car Reviews & Road Tests | APEX AUTO',
      '/latest-updates': 'Latest Automotive Updates | APEX AUTO',
      '/about-us': 'About Us — Publisher Sitoe Mkhuleko | APEX AUTO',
      '/privacy-policy': 'Privacy Policy | APEX AUTO',
      '/cookie-policy': 'Cookie Policy | APEX AUTO',
      '/terms-and-conditions': 'Terms and Conditions | APEX AUTO',
      '/contact-us': 'Contact Us | APEX AUTO',
      '/unsubscribe': 'Newsletter Unsubscribe | APEX AUTO',
      '/admin': 'Administrator Dashboard | APEX AUTO',
    };

    let nextTitle = titleMap[currentPath];
    if (!nextTitle && currentPath.startsWith('/article/')) {
      const slug = currentPath.replace('/article/', '');
      const matched = articles.find((a) => a.slug === slug);
      nextTitle = matched ? matched.seoTitle || `${matched.title} | APEX AUTO` : 'Article | APEX AUTO';
    }
    if (nextTitle) {
      document.title = nextTitle;
    }

    if (settings.googleSiteVerification) {
      let meta = document.querySelector('meta[name="google-site-verification"]');
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute('name', 'google-site-verification');
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', settings.googleSiteVerification);
    }
  }, [currentPath, articles, settings]);

  const navigate = useCallback((target: string) => {
    const [nextPathname, nextQuery] = target.split('?');
    const normalizedPath = nextPathname || '/';
    const normalizedSearch = nextQuery ? `?${nextQuery}` : '';
    if (normalizedPath === currentPath && normalizedSearch === urlSearch) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    window.history.pushState({}, '', normalizedPath + normalizedSearch);
    setCurrentPath(normalizedPath);
    setUrlSearch(normalizedSearch);
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [currentPath, urlSearch]);

  const handleSaveCookieConsent = (prefs: { analytics: boolean; advertising: boolean }) => {
    const saved = saveCookieConsent(prefs);
    setCookieConsent(saved);
    setCookieModalOpen(false);
  };

  const renderPage = () => {
    if (loading && articles.length === 0) {
      return (
        <div className="mx-auto max-w-[1440px] px-4 py-24 text-center sm:px-6 lg:px-10">
          <p className="font-serif text-3xl text-[#0A0A0C]">APEX AUTO</p>
          <p className="mt-2 text-xs uppercase tracking-[0.22em] text-[#8D6B20]">
            Loading Editorial Edition...
          </p>
        </div>
      );
    }

    if (loadError && articles.length === 0) {
      return (
        <div className="mx-auto max-w-xl px-4 py-24 text-center">
          <h1 className="font-serif text-3xl font-semibold text-[#0A0A0C]">
            Editorial Server Unavailable
          </h1>
          <p className="mt-3 text-sm text-neutral-600">{loadError}</p>
          <button
            type="button"
            onClick={loadData}
            className="mt-6 min-h-[44px] bg-[#0A0A0C] px-6 py-2.5 text-xs font-semibold uppercase tracking-[0.16em] text-[#E2C779]"
          >
            Retry Connection
          </button>
        </div>
      );
    }

    if (currentPath === '/' || currentPath === '') {
      return (
        <HomePage
          articles={articles}
          settings={settings}
          cookieConsent={cookieConsent}
          emailServiceConfigured={emailServiceConfigured}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath === '/supercars') {
      return (
        <CategoryPage
          category="Supercars"
          urlSearch={urlSearch}
          articles={articles}
          settings={settings}
          cookieConsent={cookieConsent}
          emailServiceConfigured={emailServiceConfigured}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath === '/luxury-cars') {
      return (
        <CategoryPage
          category="Luxury Cars"
          urlSearch={urlSearch}
          articles={articles}
          settings={settings}
          cookieConsent={cookieConsent}
          emailServiceConfigured={emailServiceConfigured}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath === '/comparisons') {
      return (
        <CategoryPage
          category="Comparisons"
          urlSearch={urlSearch}
          articles={articles}
          settings={settings}
          cookieConsent={cookieConsent}
          emailServiceConfigured={emailServiceConfigured}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath === '/car-reviews') {
      return (
        <CategoryPage
          category="Car Reviews"
          urlSearch={urlSearch}
          articles={articles}
          settings={settings}
          cookieConsent={cookieConsent}
          emailServiceConfigured={emailServiceConfigured}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath === '/latest-updates') {
      return (
        <CategoryPage
          category="Latest Updates"
          urlSearch={urlSearch}
          articles={articles}
          settings={settings}
          cookieConsent={cookieConsent}
          emailServiceConfigured={emailServiceConfigured}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath.startsWith('/article/')) {
      const slug = currentPath.replace('/article/', '').split('?')[0];
      return (
        <ArticleDetailPage
          slug={slug}
          allArticles={articles}
          settings={settings}
          cookieConsent={cookieConsent}
          emailServiceConfigured={emailServiceConfigured}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath === '/about-us') {
      return (
        <AboutPage
          settings={settings}
          emailServiceConfigured={emailServiceConfigured}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath === '/privacy-policy') {
      return (
        <LegalPage
          type="privacy"
          settings={settings}
          onOpenCookieSettings={() => setCookieModalOpen(true)}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath === '/cookie-policy') {
      return (
        <LegalPage
          type="cookie"
          settings={settings}
          onOpenCookieSettings={() => setCookieModalOpen(true)}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath === '/terms-and-conditions') {
      return (
        <LegalPage
          type="terms"
          settings={settings}
          onOpenCookieSettings={() => setCookieModalOpen(true)}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath === '/contact-us') {
      return (
        <ContactPage
          settings={settings}
          emailServiceConfigured={emailServiceConfigured}
          onNavigate={navigate}
        />
      );
    }
    if (currentPath === '/unsubscribe') {
      return <UnsubscribePage onNavigate={navigate} />;
    }
    if (currentPath === '/admin') {
      return <AdminPage onDataMutated={loadData} onNavigate={navigate} />;
    }

    return (
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#8D6B20]">
          404 Editorial Notice
        </p>
        <h1 className="mt-3 font-serif text-4xl font-semibold text-[#0A0A0C]">
          Page Not Found
        </h1>
        <p className="mt-3 text-sm text-neutral-600">
          The requested page does not exist on APEX AUTO.
        </p>
        <button
          type="button"
          onClick={() => navigate('/')}
          className="mt-8 min-h-[44px] bg-[#0A0A0C] px-7 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#E2C779]"
        >
          Return to Homepage
        </button>
      </div>
    );
  };

  return (
    <div className="flex min-h-screen flex-col bg-[#FAF9F6]">
      <Header currentPath={currentPath} onNavigate={navigate} settings={settings} />
      <main className="flex-1">{renderPage()}</main>
      <Footer
        onNavigate={navigate}
        onOpenCookieSettings={() => setCookieModalOpen(true)}
        settings={settings}
      />
      <CookieConsentModal
        open={cookieModalOpen}
        initialPrefs={cookieConsent}
        onSave={handleSaveCookieConsent}
        onCloseIfSaved={() => {
          if (cookieConsent) setCookieModalOpen(false);
        }}
        onNavigate={navigate}
      />
    </div>
  );
}
