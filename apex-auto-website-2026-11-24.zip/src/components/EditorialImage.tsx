import { useState } from 'react';
import { Car } from 'lucide-react';

interface EditorialImageProps {
  src: string;
  alt: string;
  caption?: string;
  className?: string;
  imgClassName?: string;
  aspectClassName?: string;
  priority?: boolean;
}

export function EditorialImage({
  src,
  alt,
  caption,
  className = '',
  imgClassName = '',
  aspectClassName = 'aspect-[4/3]',
  priority = false,
}: EditorialImageProps) {
  const [failed, setFailed] = useState(false);

  return (
    <figure className={`group ${className}`}>
      <div
        className={`relative overflow-hidden bg-[#121215] ${aspectClassName}`}
      >
        {!failed && src ? (
          <img
            src={src}
            alt={alt}
            referrerPolicy="no-referrer"
            loading={priority ? 'eager' : 'lazy'}
            decoding="async"
            onError={() => setFailed(true)}
            className={`h-full w-full object-cover transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.025] ${imgClassName}`}
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#141418] via-[#0B0B0D] to-[#1D1912] p-6 text-center">
            <Car className="mb-3 h-8 w-8 text-[#C9A24D]/70" strokeWidth={1.3} />
            <span className="font-serif text-base text-[#FAF9F6]/90 line-clamp-2 max-w-xs">
              {alt}
            </span>
          </div>
        )}
      </div>
      {caption && (
        <figcaption className="mt-2.5 font-serif text-xs italic text-neutral-500 leading-relaxed">
          {caption}
        </figcaption>
      )}
    </figure>
  );
}
