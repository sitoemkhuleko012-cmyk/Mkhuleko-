import { ArrowUpRight } from 'lucide-react';
import { FacebookIcon, InstagramIcon } from './Header';
import { safeExternalHref } from '../lib/format';
import type { SiteSettings } from '../shared/types';

interface FollowSectionProps {
  settings: SiteSettings;
}

export function FollowSection({ settings }: FollowSectionProps) {
  const instagramHref = safeExternalHref(settings.instagramUrl);
  const facebookHref = safeExternalHref(settings.facebookUrl);

  return (
    <section
      id="follow-apex"
      aria-labelledby="follow-heading"
      className="bg-[#FAF9F6] py-16 text-[#111113]"
    >
      <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-10">
        <div className="flex flex-col items-start justify-between gap-8 border-t border-b border-neutral-200 py-12 lg:flex-row lg:items-center">
          <div className="max-w-xl">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#8D6B20]">
              International Community
            </p>
            <h2
              id="follow-heading"
              className="mt-2 font-serif text-3xl font-semibold tracking-wide text-[#0A0A0C] sm:text-4xl"
            >
              FOLLOW APEX AUTO
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-neutral-600 sm:text-base">
              Join our automotive community for the latest supercars, luxury cars and automotive
              updates.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            {instagramHref ? (
              <a
                href={instagramHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center gap-3 border border-[#0A0A0C] bg-[#0A0A0C] px-6 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-white transition-colors hover:border-[#C9A24D] hover:bg-[#1A1A1F] whitespace-nowrap"
              >
                <InstagramIcon className="h-4 w-4 text-[#E2C779]" />
                <span>Instagram · sitoe mkhule</span>
                <ArrowUpRight className="h-4 w-4 text-[#E2C779]" />
              </a>
            ) : (
              <div className="inline-flex min-h-[48px] items-center gap-3 border border-neutral-300 bg-white px-5 py-3 text-xs text-neutral-600">
                <InstagramIcon className="h-4 w-4 text-[#8D6B20]" />
                <span>Instagram URL awaiting admin setup</span>
              </div>
            )}

            {facebookHref ? (
              <a
                href={facebookHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center gap-3 border border-[#0A0A0C] bg-white px-6 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#0A0A0C] transition-colors hover:bg-[#0A0A0C] hover:text-white whitespace-nowrap"
              >
                <FacebookIcon className="h-4 w-4 text-[#8D6B20]" />
                <span>Facebook · sitoe mkhule</span>
                <ArrowUpRight className="h-4 w-4" />
              </a>
            ) : (
              <div className="inline-flex min-h-[48px] items-center gap-3 border border-neutral-300 bg-white px-5 py-3 text-xs text-neutral-600">
                <FacebookIcon className="h-4 w-4 text-[#8D6B20]" />
                <span>Facebook Page URL awaiting admin setup</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
