import { useState } from 'react';
import { FacebookIcon, InstagramIcon } from './Header';
import { safeExternalHref } from '../lib/format';
import type { SiteSettings } from '../shared/types';

interface FooterProps {
  onNavigate: (path: string) => void;
  onOpenCookieSettings: () => void;
  settings: SiteSettings;
}

export function Footer({ onNavigate, onOpenCookieSettings, settings }: FooterProps) {
  const [notice, setNotice] = useState<string | null>(null);
  const currentYear = new Date().getFullYear();
  const instagramHref = safeExternalHref(settings.instagramUrl);
  const facebookHref = safeExternalHref(settings.facebookUrl);

  const go = (e: React.MouseEvent<HTMLAnchorElement>, path: string) => {
    e.preventDefault();
    onNavigate(path);
  };

  const handleUnconfigured = (platform: string) => {
    setNotice(`${platform} URL can be configured by the administrator in site settings.`);
    window.setTimeout(() => setNotice(null), 4000);
  };

  const portraitSrc =
    settings.publisherPhoto || '/assets/aistudio/IMG_20250922_202212_153_748d0b24.jpg';

  return (
    <footer className="border-t border-[#C9A24D]/30 bg-[#0A0A0C] text-[#FAF9F6]">
      {/* End-of-Page Publisher Signature */}
      <div className="border-b border-white/10 bg-[#0F0F13]">
        <div className="mx-auto flex max-w-[1440px] flex-col items-center justify-center px-4 py-7 text-center sm:px-6 lg:px-10">
          <a
            href="/about-us"
            onClick={(e) => go(e, '/about-us')}
            className="group inline-flex flex-col items-center"
          >
            <div className="h-20 w-20 overflow-hidden border border-[#C9A24D]/75 bg-[#141418] p-0.5 shadow-lg transition-transform duration-200 group-hover:scale-[1.03]">
              <img
                src={portraitSrc}
                alt="Mkhuleko Sitoe"
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover object-top"
              />
            </div>
            <p className="mt-2.5 font-serif text-base font-semibold tracking-wider text-[#E2C779] transition-colors group-hover:text-white">
              Mkhuleko Sitoe
            </p>
            <p className="mt-0.5 text-[11px] uppercase tracking-[0.18em] text-neutral-400">
              Publisher · APEX AUTO
            </p>
          </a>
        </div>
      </div>

      <div className="mx-auto max-w-[1440px] px-4 py-14 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 gap-10 border-b border-white/10 pb-12 md:grid-cols-12">
          {/* Brand & Tagline */}
          <div className="md:col-span-5">
            <a
              href="/"
              onClick={(e) => go(e, '/')}
              className="font-serif text-2xl font-semibold tracking-[0.18em] text-white"
            >
              APEX <span className="text-[#C9A24D]">AUTO</span>
            </a>
            <p className="mt-3 text-xs tracking-[0.2em] uppercase text-[#E2C779]">
              The World of Performance &amp; Luxury.
            </p>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-neutral-400">
              An international automotive publication dedicated to supercars, luxury coachbuilding,
              performance comparisons, and technical road tests.
            </p>
            <p className="mt-4 text-sm font-medium text-neutral-200">
              Published by {settings.publisherName || 'Sitoe Mkhuleko'}.
            </p>
          </div>

          {/* Navigation Column */}
          <div className="md:col-span-2">
            <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.18em] text-[#C9A24D]">
              Navigation
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-neutral-300">
              <li>
                <a href="/" onClick={(e) => go(e, '/')} className="hover:text-white transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="/about-us" onClick={(e) => go(e, '/about-us')} className="hover:text-white transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="/latest-updates" onClick={(e) => go(e, '/latest-updates')} className="hover:text-white transition-colors">
                  Latest Updates
                </a>
              </li>
              <li>
                <a href="/contact-us" onClick={(e) => go(e, '/contact-us')} className="hover:text-white transition-colors">
                  Contact Us
                </a>
              </li>
            </ul>
          </div>

          {/* Legal Column */}
          <div className="md:col-span-3">
            <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.18em] text-[#C9A24D]">
              Legal
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-neutral-300">
              <li>
                <a href="/privacy-policy" onClick={(e) => go(e, '/privacy-policy')} className="hover:text-white transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="/cookie-policy" onClick={(e) => go(e, '/cookie-policy')} className="hover:text-white transition-colors">
                  Cookie Policy
                </a>
              </li>
              <li>
                <a href="/terms-and-conditions" onClick={(e) => go(e, '/terms-and-conditions')} className="hover:text-white transition-colors">
                  Terms and Conditions
                </a>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenCookieSettings}
                  className="text-left text-sm text-[#E2C779] underline-offset-4 hover:underline transition-colors"
                >
                  Cookie Settings
                </button>
              </li>
            </ul>
          </div>

          {/* Social Column */}
          <div className="md:col-span-2">
            <h3 className="font-sans text-xs font-semibold uppercase tracking-[0.18em] text-[#C9A24D]">
              Social
            </h3>
            <ul className="mt-4 space-y-3 text-sm text-neutral-300">
              <li>
                {instagramHref ? (
                  <a
                    href={instagramHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2.5 hover:text-[#E2C779] transition-colors"
                  >
                    <InstagramIcon className="h-4 w-4" />
                    <span>Instagram · sitoe mkhule</span>
                  </a>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleUnconfigured('Instagram')}
                    className="inline-flex items-center gap-2.5 text-neutral-400 hover:text-[#E2C779] transition-colors"
                  >
                    <InstagramIcon className="h-4 w-4" />
                    <span>Instagram</span>
                  </button>
                )}
              </li>
              <li>
                {facebookHref ? (
                  <a
                    href={facebookHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2.5 hover:text-[#E2C779] transition-colors"
                  >
                    <FacebookIcon className="h-4 w-4" />
                    <span>Facebook · sitoe mkhule</span>
                  </a>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleUnconfigured('Facebook')}
                    className="inline-flex items-center gap-2.5 text-neutral-400 hover:text-[#E2C779] transition-colors"
                  >
                    <FacebookIcon className="h-4 w-4" />
                    <span>Facebook</span>
                  </button>
                )}
              </li>
            </ul>
            {notice && <p className="mt-3 text-xs text-[#E2C779]">{notice}</p>}
          </div>
        </div>

        {/* Bottom Copyright Bar */}
        <div className="flex flex-col items-start justify-between gap-4 pt-8 text-xs text-neutral-400 sm:flex-row sm:items-center">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
            <span>© {currentYear} APEX AUTO. All Rights Reserved.</span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span>Published by {settings.publisherName || 'Sitoe Mkhuleko'}.</span>
          </div>
          <div className="flex items-center gap-5">
            <a
              href="/sitemap.xml"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-neutral-200 transition-colors"
            >
              Sitemap
            </a>
            <a
              href="/admin"
              onClick={(e) => go(e, '/admin')}
              className="text-neutral-500 hover:text-[#E2C779] transition-colors"
            >
              Editorial Portal
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
