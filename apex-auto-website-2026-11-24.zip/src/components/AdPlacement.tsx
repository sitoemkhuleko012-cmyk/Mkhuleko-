import { useEffect, useRef } from 'react';
import type { AdPlacements, CookiePreferences, SiteSettings } from '../shared/types';

interface AdPlacementProps {
  slot: keyof AdPlacements;
  settings: SiteSettings;
  cookieConsent: CookiePreferences | null;
  variant?: 'leaderboard' | 'in-article' | 'sidebar';
}

export function AdPlacement({
  slot,
  settings,
  cookieConsent,
  variant = 'leaderboard',
}: AdPlacementProps) {
  const adRef = useRef<HTMLModElement | null>(null);
  const enabled = settings.adPlacements?.[slot] ?? false;
  const publisherId = settings.adsensePublisherId.trim();
  const hasAdsenseId = /^ca-pub-\d{10,20}$/.test(publisherId);
  const consented = Boolean(cookieConsent?.advertising);

  useEffect(() => {
    if (enabled && hasAdsenseId && consented && adRef.current) {
      try {
        const w = window as unknown as { adsbygoogle?: unknown[] };
        w.adsbygoogle = w.adsbygoogle || [];
        w.adsbygoogle.push({});
      } catch {
        // Ignore AdSense push errors before script readiness
      }
    }
  }, [enabled, hasAdsenseId, consented]);

  if (!enabled) return null;

  // Do not render active ad slots if visitor rejected advertising cookies and no AdSense ID is live
  if (!hasAdsenseId) {
    return null;
  }

  return (
    <aside
      aria-label="Advertisement"
      className={`mx-auto my-8 border border-neutral-200 bg-[#F3F0E9]/60 p-4 text-center ${
        variant === 'sidebar' ? 'w-full' : 'max-w-[1000px]'
      }`}
    >
      <p className="mb-2 text-[11px] font-medium uppercase tracking-[0.2em] text-neutral-500">
        Advertisement
      </p>
      {consented ? (
        <ins
          ref={adRef}
          className="adsbygoogle block min-h-[90px]"
          style={{ display: 'block' }}
          data-ad-client={publisherId}
          data-ad-format="auto"
          data-full-width-responsive="true"
        />
      ) : (
        <p className="py-4 text-xs text-neutral-500">
          Advertising cookies are currently disabled in your Cookie Settings.
        </p>
      )}
    </aside>
  );
}
