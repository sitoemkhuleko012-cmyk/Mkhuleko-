import { useEffect, useState } from 'react';
import { ShieldCheck, SlidersHorizontal, X } from 'lucide-react';
import type { CookiePreferences } from '../shared/types';

interface CookieConsentModalProps {
  open: boolean;
  initialPrefs: CookiePreferences | null;
  onSave: (prefs: { analytics: boolean; advertising: boolean }) => void;
  onCloseIfSaved: () => void;
  onNavigate: (path: string) => void;
}

export function CookieConsentModal({
  open,
  initialPrefs,
  onSave,
  onCloseIfSaved,
  onNavigate,
}: CookieConsentModalProps) {
  const [customizing, setCustomizing] = useState(false);
  const [analytics, setAnalytics] = useState(initialPrefs?.analytics ?? false);
  const [advertising, setAdvertising] = useState(initialPrefs?.advertising ?? false);

  useEffect(() => {
    if (open) {
      setAnalytics(initialPrefs?.analytics ?? false);
      setAdvertising(initialPrefs?.advertising ?? false);
      setCustomizing(Boolean(initialPrefs));
    }
  }, [open, initialPrefs]);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="cookie-consent-heading"
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/65 p-4 backdrop-blur-xs sm:items-center"
    >
      <div className="animate-editorial-in w-full max-w-2xl border border-[#C9A24D]/40 bg-[#0A0A0C] p-6 text-[#FAF9F6] shadow-2xl sm:p-8">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-2.5 text-[#E2C779]">
            <ShieldCheck className="h-5 w-5 shrink-0" />
            <span className="text-xs font-semibold uppercase tracking-[0.2em]">
              APEX AUTO Privacy
            </span>
          </div>
          {initialPrefs && (
            <button
              type="button"
              onClick={onCloseIfSaved}
              aria-label="Close cookie preferences"
              className="flex h-9 w-9 items-center justify-center text-neutral-400 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        <h2
          id="cookie-consent-heading"
          className="mt-4 font-serif text-2xl font-semibold tracking-wide text-white sm:text-3xl"
        >
          YOUR PRIVACY MATTERS TO US
        </h2>

        <p className="mt-3 text-sm leading-relaxed text-neutral-300">
          APEX AUTO uses cookies and similar technologies to improve your browsing experience,
          understand website traffic and support advertising. You can choose which optional cookies
          you allow.
        </p>

        {customizing && (
          <div className="mt-6 space-y-4 border-t border-b border-white/10 py-5">
            {/* Essential */}
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-sm font-semibold text-white">Essential Cookies</p>
                <p className="mt-1 text-xs leading-relaxed text-neutral-400">
                  Required for core website navigation, security integrity, and saving your privacy
                  preferences. Always active.
                </p>
              </div>
              <span className="shrink-0 border border-[#C9A24D]/50 px-3 py-1 text-xs font-medium text-[#E2C779] whitespace-nowrap">
                Always Active
              </span>
            </div>

            {/* Analytics */}
            <div className="flex items-start justify-between gap-4 pt-2 border-t border-white/5">
              <div>
                <label htmlFor="cookie-analytics-toggle" className="text-sm font-semibold text-white cursor-pointer">
                  Analytics Cookies
                </label>
                <p className="mt-1 text-xs leading-relaxed text-neutral-400">
                  Helps our editorial team measure readership and improve automotive coverage.
                </p>
              </div>
              <button
                id="cookie-analytics-toggle"
                type="button"
                role="switch"
                aria-checked={analytics}
                onClick={() => setAnalytics((v) => !v)}
                className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer items-center border transition-colors ${
                  analytics
                    ? 'border-[#C9A24D] bg-[#C9A24D]'
                    : 'border-white/25 bg-[#1A1A1F]'
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform bg-[#0A0A0C] transition-transform ${
                    analytics ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Advertising */}
            <div className="flex items-start justify-between gap-4 pt-2 border-t border-white/5">
              <div>
                <label htmlFor="cookie-advertising-toggle" className="text-sm font-semibold text-white cursor-pointer">
                  Advertising Cookies
                </label>
                <p className="mt-1 text-xs leading-relaxed text-neutral-400">
                  Allows advertising partners such as Google AdSense to display relevant ads when
                  configured.
                </p>
              </div>
              <button
                id="cookie-advertising-toggle"
                type="button"
                role="switch"
                aria-checked={advertising}
                onClick={() => setAdvertising((v) => !v)}
                className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer items-center border transition-colors ${
                  advertising
                    ? 'border-[#C9A24D] bg-[#C9A24D]'
                    : 'border-white/25 bg-[#1A1A1F]'
                }`}
              >
                <span
                  className={`inline-block h-5 w-5 transform bg-[#0A0A0C] transition-transform ${
                    advertising ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        )}

        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
          <button
            type="button"
            onClick={() => onSave({ analytics: true, advertising: true })}
            className="min-h-[44px] bg-[#C9A24D] px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#0A0A0C] transition-colors hover:bg-[#E2C779] whitespace-nowrap"
          >
            ACCEPT ALL COOKIES
          </button>

          <button
            type="button"
            onClick={() => onSave({ analytics: false, advertising: false })}
            className="min-h-[44px] border border-white/30 bg-transparent px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-white transition-colors hover:border-white hover:bg-white/10 whitespace-nowrap"
          >
            REJECT OPTIONAL COOKIES
          </button>

          {!customizing ? (
            <button
              type="button"
              onClick={() => setCustomizing(true)}
              className="inline-flex min-h-[44px] items-center justify-center gap-2 border border-[#C9A24D]/50 px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779] transition-colors hover:border-[#C9A24D] hover:bg-[#C9A24D]/10 whitespace-nowrap"
            >
              <SlidersHorizontal className="h-3.5 w-3.5" />
              CUSTOMIZE MY PREFERENCES
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onSave({ analytics, advertising })}
              className="min-h-[44px] border border-[#C9A24D] bg-[#141418] px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779] transition-colors hover:bg-[#C9A24D]/15 whitespace-nowrap"
            >
              SAVE MY PREFERENCES
            </button>
          )}
        </div>

        <p className="mt-4 text-xs text-neutral-400">
          Optional cookies remain disabled until you grant consent. Read our{' '}
          <a
            href="/cookie-policy"
            onClick={(e) => {
              e.preventDefault();
              onCloseIfSaved();
              onNavigate('/cookie-policy');
            }}
            className="text-[#E2C779] underline underline-offset-4 hover:text-white"
          >
            Cookie Policy
          </a>{' '}
          and{' '}
          <a
            href="/privacy-policy"
            onClick={(e) => {
              e.preventDefault();
              onCloseIfSaved();
              onNavigate('/privacy-policy');
            }}
            className="text-[#E2C779] underline underline-offset-4 hover:text-white"
          >
            Privacy Policy
          </a>
          .
        </p>
      </div>
    </div>
  );
}
