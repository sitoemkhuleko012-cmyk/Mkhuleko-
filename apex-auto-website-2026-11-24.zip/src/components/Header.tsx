import { useState } from 'react';
import { ChevronDown, Menu, X } from 'lucide-react';
import { safeExternalHref } from '../lib/format';
import type { SiteSettings } from '../shared/types';

export interface NavSubItem {
  label: string;
  path: string;
}

export interface NavItem {
  label: string;
  path: string;
  children?: NavSubItem[];
}

export const MAIN_NAV_ITEMS: NavItem[] = [
  { label: 'Home', path: '/' },
  {
    label: 'Supercars',
    path: '/supercars',
    children: [
      { label: 'All Supercars', path: '/supercars' },
      { label: 'Ferrari', path: '/supercars?brand=Ferrari' },
      { label: 'Lamborghini', path: '/supercars?brand=Lamborghini' },
      { label: 'Bugatti', path: '/supercars?brand=Bugatti' },
      { label: 'McLaren', path: '/supercars?brand=McLaren' },
      { label: 'Koenigsegg', path: '/supercars?brand=Koenigsegg' },
      { label: 'Pagani', path: '/supercars?brand=Pagani' },
    ],
  },
  {
    label: 'Luxury Cars',
    path: '/luxury-cars',
    children: [
      { label: 'All Luxury Cars', path: '/luxury-cars' },
      { label: 'Rolls-Royce', path: '/luxury-cars?brand=Rolls-Royce' },
      { label: 'Bentley', path: '/luxury-cars?brand=Bentley' },
      { label: 'Mercedes-Benz', path: '/luxury-cars?brand=Mercedes-Benz' },
      { label: 'BMW', path: '/luxury-cars?brand=BMW' },
      { label: 'Porsche', path: '/luxury-cars?brand=Porsche' },
      { label: 'Aston Martin', path: '/luxury-cars?brand=Aston+Martin' },
    ],
  },
  { label: 'Comparisons', path: '/comparisons' },
  { label: 'Car Reviews', path: '/car-reviews' },
  { label: 'Latest Updates', path: '/latest-updates' },
  { label: 'About Us', path: '/about-us' },
  { label: 'Privacy Policy', path: '/privacy-policy' },
  { label: 'Cookie Policy', path: '/cookie-policy' },
  { label: 'Contact Us', path: '/contact-us' },
];

export function InstagramIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
    </svg>
  );
}

export function FacebookIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
    </svg>
  );
}

interface HeaderProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  settings: SiteSettings;
}

export function Header({ currentPath, onNavigate, settings }: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [socialNotice, setSocialNotice] = useState<string | null>(null);

  const instagramHref = safeExternalHref(settings.instagramUrl);
  const facebookHref = safeExternalHref(settings.facebookUrl);

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, path: string) => {
    e.preventDefault();
    setMobileOpen(false);
    setOpenDropdown(null);
    setSocialNotice(null);
    onNavigate(path);
  };

  const handleUnconfiguredSocial = (platform: string) => {
    setSocialNotice(
      `The official APEX AUTO ${platform} URL has not been configured yet by the administrator.`
    );
    window.setTimeout(() => setSocialNotice(null), 4000);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#0A0A0C]/95 backdrop-blur-md text-[#FAF9F6]">
      <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-6 px-4 py-3.5 sm:px-6 lg:px-10">
        {/* Zone 1: Single-line Brand Wordmark */}
        <a
          href="/"
          onClick={(e) => handleLinkClick(e, '/')}
          className="font-serif text-xl sm:text-2xl font-semibold tracking-[0.18em] text-white whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#C9A24D]"
        >
          APEX <span className="text-[#C9A24D]">AUTO</span>
        </a>

        {/* Zone 2: 10 Editorial Navigation Links with Marque Sub-Menus */}
        <nav
          aria-label="Primary Navigation"
          className="hidden xl:flex items-center gap-4 2xl:gap-5"
        >
          {MAIN_NAV_ITEMS.map((item) => {
            const isActive =
              item.path === '/'
                ? currentPath === '/'
                : currentPath.startsWith(item.path);

            if (item.children) {
              const isOpen = openDropdown === item.path;
              return (
                <div
                  key={item.path}
                  className="relative"
                  onMouseEnter={() => setOpenDropdown(item.path)}
                  onMouseLeave={() => setOpenDropdown(null)}
                >
                  <a
                    href={item.path}
                    onClick={(e) => handleLinkClick(e, item.path)}
                    aria-expanded={isOpen}
                    className={`relative inline-flex items-center gap-1 py-1 text-[13px] font-medium tracking-wide whitespace-nowrap shrink-0 transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-[#C9A24D] ${
                      isActive
                        ? 'text-[#E2C779]'
                        : 'text-neutral-300 hover:text-white'
                    }`}
                  >
                    <span>{item.label}</span>
                    <ChevronDown className="h-3 w-3 opacity-75" />
                    <span
                      className={`absolute inset-x-0 -bottom-0.5 h-px bg-[#C9A24D] transition-transform duration-200 origin-left ${
                        isActive ? 'scale-x-100' : 'scale-x-0'
                      }`}
                    />
                  </a>

                  {isOpen && (
                    <div className="absolute left-0 top-full pt-2 z-50">
                      <div className="w-48 border border-[#C9A24D]/35 bg-[#0A0A0C] py-2 shadow-2xl">
                        {item.children.map((sub) => (
                          <a
                            key={sub.path}
                            href={sub.path}
                            onClick={(e) => handleLinkClick(e, sub.path)}
                            className="block px-4 py-2 text-xs font-medium text-neutral-300 transition-colors hover:bg-[#16161B] hover:text-[#E2C779]"
                          >
                            {sub.label}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            }

            return (
              <a
                key={item.path}
                href={item.path}
                onClick={(e) => handleLinkClick(e, item.path)}
                className={`relative py-1 text-[13px] font-medium tracking-wide whitespace-nowrap shrink-0 transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-[#C9A24D] ${
                  isActive
                    ? 'text-[#E2C779]'
                    : 'text-neutral-300 hover:text-white'
                }`}
              >
                {item.label}
                <span
                  className={`absolute inset-x-0 -bottom-0.5 h-px bg-[#C9A24D] transition-transform duration-200 origin-left ${
                    isActive ? 'scale-x-100' : 'scale-x-0'
                  }`}
                />
              </a>
            );
          })}
        </nav>

        {/* Zone 3: Social Icons (sitoe mkhule) & Mobile Drawer Trigger */}
        <div className="flex items-center gap-2.5 shrink-0">
          {instagramHref ? (
            <a
              href={instagramHref}
              target="_blank"
              rel="noopener noreferrer"
              title="Instagram: sitoe mkhule"
              aria-label="APEX AUTO Instagram — sitoe mkhule"
              className="flex h-10 w-10 items-center justify-center text-neutral-300 transition-colors hover:text-[#E2C779] focus-visible:outline-2 focus-visible:outline-[#C9A24D]"
            >
              <InstagramIcon className="h-[18px] w-[18px]" />
            </a>
          ) : (
            <button
              type="button"
              onClick={() => handleUnconfiguredSocial('Instagram')}
              aria-label="Instagram profile (awaiting configuration)"
              className="flex h-10 w-10 items-center justify-center text-neutral-400 transition-colors hover:text-[#E2C779] focus-visible:outline-2 focus-visible:outline-[#C9A24D]"
            >
              <InstagramIcon className="h-[18px] w-[18px]" />
            </button>
          )}

          {facebookHref ? (
            <a
              href={facebookHref}
              target="_blank"
              rel="noopener noreferrer"
              title="Facebook: sitoe mkhule"
              aria-label="APEX AUTO Facebook — sitoe mkhule"
              className="flex h-10 w-10 items-center justify-center text-neutral-300 transition-colors hover:text-[#E2C779] focus-visible:outline-2 focus-visible:outline-[#C9A24D]"
            >
              <FacebookIcon className="h-[18px] w-[18px]" />
            </a>
          ) : (
            <button
              type="button"
              onClick={() => handleUnconfiguredSocial('Facebook')}
              aria-label="Facebook page (awaiting configuration)"
              className="flex h-10 w-10 items-center justify-center text-neutral-400 transition-colors hover:text-[#E2C779] focus-visible:outline-2 focus-visible:outline-[#C9A24D]"
            >
              <FacebookIcon className="h-[18px] w-[18px]" />
            </button>
          )}

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="flex h-11 w-11 items-center justify-center border border-white/15 text-white xl:hidden transition-colors hover:border-[#C9A24D] hover:text-[#E2C779]"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {socialNotice && (
        <div className="border-t border-[#C9A24D]/30 bg-[#141418] px-4 py-2 text-center text-xs text-[#E2C779]">
          {socialNotice}
        </div>
      )}

      {/* Mobile & Tablet Navigation Drawer */}
      {mobileOpen && (
        <div className="max-h-[80vh] overflow-y-auto border-t border-white/10 bg-[#0A0A0C] xl:hidden">
          <nav
            aria-label="Mobile Navigation"
            className="mx-auto grid max-w-[1440px] grid-cols-1 divide-y divide-white/10 px-4 py-2 sm:grid-cols-2 sm:divide-y-0 sm:gap-2 sm:px-6"
          >
            {MAIN_NAV_ITEMS.map((item) => {
              const isActive =
                item.path === '/'
                  ? currentPath === '/'
                  : currentPath.startsWith(item.path);
              return (
                <div key={item.path} className="py-1">
                  <a
                    href={item.path}
                    onClick={(e) => handleLinkClick(e, item.path)}
                    className={`flex min-h-[44px] items-center px-3 py-2 text-sm font-medium transition-colors ${
                      isActive
                        ? 'text-[#E2C779]'
                        : 'text-neutral-200 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </a>
                  {item.children && (
                    <div className="flex flex-wrap gap-x-3 gap-y-1 px-3 pb-2">
                      {item.children.slice(1).map((sub) => (
                        <a
                          key={sub.path}
                          href={sub.path}
                          onClick={(e) => handleLinkClick(e, sub.path)}
                          className="text-xs text-neutral-400 hover:text-[#E2C779]"
                        >
                          {sub.label}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </nav>
        </div>
      )}
    </header>
  );
}
