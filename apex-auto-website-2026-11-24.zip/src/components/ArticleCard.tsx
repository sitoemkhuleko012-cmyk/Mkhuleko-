import { ArrowRight } from 'lucide-react';
import { EditorialImage } from './EditorialImage';
import { formatPublicationDate } from '../lib/format';
import type { Article } from '../shared/types';

interface ArticleCardProps {
  article: Article;
  onNavigate: (path: string) => void;
  variant?: 'standard' | 'featured' | 'compact';
}

export function ArticleCard({
  article,
  onNavigate,
  variant = 'standard',
}: ArticleCardProps) {
  const href = `/article/${article.slug}`;

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    onNavigate(href);
  };

  if (variant === 'compact') {
    return (
      <article className="group border-b border-neutral-200 py-5 last:border-b-0">
        <a href={href} onClick={handleClick} className="grid grid-cols-12 gap-4 items-center">
          <div className="col-span-4 sm:col-span-3">
            <EditorialImage
              src={article.featuredImage}
              alt={article.title}
              aspectClassName="aspect-[4/3]"
            />
          </div>
          <div className="col-span-8 sm:col-span-9">
            <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500">
              <span className="font-semibold uppercase tracking-[0.14em] text-[#8D6B20]">
                {article.category}
              </span>
              <span aria-hidden="true">·</span>
              <span>{formatPublicationDate(article.publishedAt)}</span>
            </div>
            <h3 className="mt-1.5 font-serif text-xl font-semibold leading-snug text-[#0A0A0C] transition-colors group-hover:text-[#8D6B20]">
              {article.title}
            </h3>
            <p className="mt-1.5 hidden text-sm text-neutral-600 line-clamp-2 sm:block">
              {article.description}
            </p>
          </div>
        </a>
      </article>
    );
  }

  return (
    <article className="group flex flex-col border border-neutral-200 bg-white transition-colors duration-200 hover:border-[#C9A24D]">
      <a href={href} onClick={handleClick} className="flex h-full flex-col">
        <EditorialImage
          src={article.featuredImage}
          alt={article.title}
          aspectClassName={variant === 'featured' ? 'aspect-[16/10]' : 'aspect-[4/3]'}
        />
        <div className="flex flex-1 flex-col p-6">
          <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500">
            <span className="font-semibold uppercase tracking-[0.14em] text-[#8D6B20]">
              {article.category}
            </span>
            {article.manufacturer && (
              <>
                <span aria-hidden="true">·</span>
                <span>{article.manufacturer}</span>
              </>
            )}
            <span aria-hidden="true">·</span>
            <span>{formatPublicationDate(article.publishedAt)}</span>
          </div>

          <h3
            className={`mt-3 font-serif font-semibold leading-tight text-[#0A0A0C] transition-colors group-hover:text-[#8D6B20] ${
              variant === 'featured' ? 'text-2xl sm:text-3xl' : 'text-xl sm:text-2xl'
            }`}
          >
            {article.title}
          </h3>

          <p className="mt-3 flex-1 text-sm leading-relaxed text-neutral-600 line-clamp-3">
            {article.description}
          </p>

          <div className="mt-5 flex items-center justify-between border-t border-neutral-100 pt-4 text-xs font-medium text-[#0A0A0C]">
            <span className="text-neutral-500">
              By {article.author} <span aria-hidden="true">·</span> {article.readTime}
            </span>
            <span className="inline-flex items-center gap-1.5 uppercase tracking-[0.14em] text-[#8D6B20] transition-transform duration-200 group-hover:translate-x-1">
              Read Story
              <ArrowRight className="h-3.5 w-3.5" />
            </span>
          </div>
        </div>
      </a>
    </article>
  );
}
