import { useState } from 'react';
import { CheckCircle2, Mail } from 'lucide-react';
import { subscribeNewsletterApi } from '../lib/api';

interface NewsletterSectionProps {
  onNavigate: (path: string) => void;
  emailServiceConfigured?: boolean;
  dark?: boolean;
}

export function NewsletterSection({
  onNavigate,
  emailServiceConfigured = false,
  dark = true,
}: NewsletterSectionProps) {
  const [email, setEmail] = useState('');
  const [consent, setConsent] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!email.trim()) {
      setError('Please enter your email address.');
      return;
    }
    if (!consent) {
      setError('Please confirm your consent to receive APEX AUTO editorial emails.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await subscribeNewsletterApi(email.trim(), consent);
      setSuccessMsg(res.message);
      if (!res.alreadySubscribed) {
        setEmail('');
        setConsent(false);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to complete subscription.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section
      aria-labelledby="newsletter-heading"
      className={
        dark
          ? 'border-y border-[#C9A24D]/25 bg-[#0D0D10] py-16 text-[#FAF9F6]'
          : 'border border-neutral-200 bg-[#F3F0E9] py-14 px-6 sm:px-10 text-[#111113]'
      }
    >
      <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-10">
        <div className="mx-auto max-w-3xl text-center">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.22em] text-[#C9A24D]">
            <Mail className="h-4 w-4" />
            <span>Editorial Dispatch</span>
          </div>

          <h2
            id="newsletter-heading"
            className={`mt-3 font-serif text-3xl font-semibold tracking-wide sm:text-4xl ${
              dark ? 'text-white' : 'text-[#0A0A0C]'
            }`}
          >
            STAY AHEAD OF THE CURVE
          </h2>

          <p
            className={`mx-auto mt-4 max-w-2xl text-sm leading-relaxed sm:text-base ${
              dark ? 'text-neutral-300' : 'text-neutral-700'
            }`}
          >
            Subscribe to APEX AUTO and receive the latest supercar news, luxury car stories,
            comparisons and automotive updates directly in your inbox.
          </p>

          <form onSubmit={handleSubmit} className="mx-auto mt-8 max-w-xl text-left">
            <div className="flex flex-col gap-3 sm:flex-row">
              <label htmlFor="newsletter-email" className="sr-only">
                Email address
              </label>
              <input
                id="newsletter-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                className={`min-h-[48px] flex-1 border px-4 py-3 text-sm transition-colors focus:outline-none ${
                  dark
                    ? 'border-white/20 bg-[#141418] text-white placeholder:text-neutral-500 focus:border-[#C9A24D]'
                    : 'border-neutral-300 bg-white text-[#111113] placeholder:text-neutral-500 focus:border-[#8D6B20]'
                }`}
              />
              <button
                type="submit"
                disabled={submitting}
                className="min-h-[48px] bg-[#C9A24D] px-7 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#0A0A0C] transition-colors hover:bg-[#E2C779] disabled:opacity-60 whitespace-nowrap shrink-0"
              >
                {submitting ? 'Subscribing...' : 'Subscribe'}
              </button>
            </div>

            <div className="mt-4 flex items-start gap-3">
              <input
                id="newsletter-consent"
                type="checkbox"
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
                className="mt-1 h-4 w-4 shrink-0 accent-[#C9A24D]"
              />
              <label
                htmlFor="newsletter-consent"
                className={`text-xs leading-relaxed ${
                  dark ? 'text-neutral-400' : 'text-neutral-600'
                }`}
              >
                I agree to receive editorial updates and automotive dispatches from APEX AUTO and
                confirm that I have read the{' '}
                <a
                  href="/privacy-policy"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/privacy-policy');
                  }}
                  className={`underline underline-offset-4 ${
                    dark
                      ? 'text-[#E2C779] hover:text-white'
                      : 'text-[#8D6B20] hover:text-[#0A0A0C]'
                  }`}
                >
                  Privacy Policy
                </a>
                . You may{' '}
                <a
                  href="/unsubscribe"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/unsubscribe');
                  }}
                  className={`underline underline-offset-4 ${
                    dark
                      ? 'text-[#E2C779] hover:text-white'
                      : 'text-[#8D6B20] hover:text-[#0A0A0C]'
                  }`}
                >
                  unsubscribe at any time
                </a>
                .
              </label>
            </div>

            {!emailServiceConfigured && (
              <p
                className={`mt-3 text-xs ${
                  dark ? 'text-neutral-400' : 'text-neutral-600'
                }`}
              >
                Subscriptions are stored securely in the APEX AUTO subscriber database. Outbound
                email delivery activates once SMTP credentials are configured on the server.
              </p>
            )}

            {error && (
              <div
                role="alert"
                className="mt-4 border border-red-500/40 bg-red-950/30 px-4 py-3 text-xs text-red-200"
              >
                {error}
              </div>
            )}

            {successMsg && (
              <div
                role="status"
                className={`mt-4 flex items-start gap-2.5 border px-4 py-3 text-xs ${
                  dark
                    ? 'border-[#C9A24D]/50 bg-[#141418] text-[#E2C779]'
                    : 'border-[#8D6B20]/40 bg-white text-[#0A0A0C]'
                }`}
              >
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#C9A24D]" />
                <span>{successMsg}</span>
              </div>
            )}
          </form>
        </div>
      </div>
    </section>
  );
}
