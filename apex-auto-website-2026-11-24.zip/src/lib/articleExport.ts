import type { Article } from '../shared/types';
import { formatPublicationDate } from './format';

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function safeFilename(raw: string, fallback = 'apex-auto-article'): string {
  const cleaned = raw
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9-_]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return cleaned || fallback;
}

function triggerBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const SPEC_LABELS: Record<string, string> = {
  engine: 'Powertrain / Engine',
  horsepower: 'Maximum Power',
  torque: 'Peak Torque',
  zeroToSixty: '0–60 mph Acceleration',
  topSpeed: 'Top Speed',
  transmission: 'Transmission',
  drivetrain: 'Drivetrain',
  curbWeight: 'Curb Weight',
  price: 'Estimated Base Price',
};

function renderArticleSectionHtml(article: Article): string {
  const paragraphs = article.content
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean);

  const specEntries = Object.entries(article.specs || {}).filter(
    ([, val]) => typeof val === 'string' && val.trim().length > 0
  );

  const specsBlock =
    specEntries.length > 0
      ? `<section class="box">
          <h2>Technical Specifications</h2>
          <table>
            <tbody>
              ${specEntries
                .map(
                  ([key, val]) => `<tr>
                    <th>${escapeHtml(SPEC_LABELS[key] || key)}</th>
                    <td>${escapeHtml(String(val))}</td>
                  </tr>`
                )
                .join('')}
            </tbody>
          </table>
        </section>`
      : '';

  const comparisonBlock =
    article.comparisonVehicles && article.comparisonVehicles.length > 0
      ? `<section class="box">
          <h2>Head-to-Head Comparison</h2>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Model</th>
                  <th>Powertrain</th>
                  <th>Power</th>
                  <th>0–60 mph</th>
                  <th>Top Speed</th>
                  <th>Price</th>
                </tr>
              </thead>
              <tbody>
                ${article.comparisonVehicles
                  .map(
                    (v) => `<tr>
                      <td><strong>${escapeHtml(v.name)}</strong><br /><span class="muted">${escapeHtml(v.manufacturer)}</span></td>
                      <td>${escapeHtml(v.engine)}</td>
                      <td>${escapeHtml(v.horsepower)}</td>
                      <td>${escapeHtml(v.zeroToSixty)}</td>
                      <td>${escapeHtml(v.topSpeed)}</td>
                      <td>${escapeHtml(v.price)}</td>
                    </tr>`
                  )
                  .join('')}
              </tbody>
            </table>
          </div>
        </section>`
      : '';

  const reviewBlock =
    (article.pros && article.pros.length > 0) ||
    (article.cons && article.cons.length > 0) ||
    article.verdict
      ? `<section class="box">
          <h2>Editorial Assessment${article.rating > 0 ? ` — ${article.rating.toFixed(1)} / 10` : ''}</h2>
          ${
            article.pros && article.pros.length > 0
              ? `<h3>Advantages</h3><ul>${article.pros.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}</ul>`
              : ''
          }
          ${
            article.cons && article.cons.length > 0
              ? `<h3>Disadvantages</h3><ul>${article.cons.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}</ul>`
              : ''
          }
          ${article.verdict ? `<p class="verdict"><strong>Editorial Verdict:</strong> ${escapeHtml(article.verdict)}</p>` : ''}
        </section>`
      : '';

  return `<article class="article">
    <p class="meta">
      ${escapeHtml(article.category)}
      ${article.manufacturer ? ` · ${escapeHtml(article.manufacturer)}` : ''}
      · ${escapeHtml(formatPublicationDate(article.publishedAt))}
      · ${escapeHtml(article.readTime)}
    </p>
    <h1>${escapeHtml(article.title)}</h1>
    <p class="deck">${escapeHtml(article.description)}</p>
    <p class="byline">By ${escapeHtml(article.author || 'Sitoe Mkhuleko')} · Publisher: Mkhuleko Sitoe · APEX AUTO</p>
    <div class="prose">
      ${paragraphs.map((p) => `<p>${escapeHtml(p)}</p>`).join('\n')}
    </div>
    ${specsBlock}
    ${comparisonBlock}
    ${reviewBlock}
  </article>`;
}

function wrapEditorialDocumentHtml(title: string, bodyHtml: string): string {
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${escapeHtml(title)} — APEX AUTO</title>
    <style>
      body {
        margin: 0;
        background: #FAF9F6;
        color: #111113;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        line-height: 1.7;
      }
      header.masthead {
        background: #0A0A0C;
        color: #FAF9F6;
        border-bottom: 2px solid #C9A24D;
        padding: 28px 20px;
        text-align: center;
      }
      header.masthead .brand {
        font-family: Georgia, "Times New Roman", serif;
        font-size: 28px;
        letter-spacing: 0.2em;
        font-weight: 600;
      }
      header.masthead .brand span { color: #C9A24D; }
      header.masthead .tagline {
        margin-top: 6px;
        font-size: 11px;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #E2C779;
      }
      main {
        max-width: 820px;
        margin: 0 auto;
        padding: 32px 20px 60px;
      }
      .article {
        padding-bottom: 44px;
        margin-bottom: 44px;
        border-bottom: 1px solid #DDD6C8;
      }
      .article:last-child { border-bottom: none; }
      .meta {
        font-size: 12px;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        color: #8D6B20;
        font-weight: 600;
      }
      h1 {
        font-family: Georgia, "Times New Roman", serif;
        font-size: 32px;
        line-height: 1.15;
        margin: 10px 0 14px;
        color: #0A0A0C;
      }
      h2 {
        font-family: Georgia, "Times New Roman", serif;
        font-size: 20px;
        margin: 0 0 12px;
        color: #0A0A0C;
      }
      h3 {
        font-size: 13px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #8D6B20;
        margin: 16px 0 6px;
      }
      .deck {
        font-size: 17px;
        color: #44444A;
        margin: 0 0 14px;
      }
      .byline {
        font-size: 13px;
        color: #55555C;
        border-top: 1px solid #E5E0D5;
        border-bottom: 1px solid #E5E0D5;
        padding: 10px 0;
        margin-bottom: 22px;
      }
      .prose p { margin: 0 0 16px; font-size: 16px; }
      .box {
        margin-top: 26px;
        padding: 18px;
        background: #FFFFFF;
        border: 1px solid #E2DDD2;
      }
      .table-wrap { overflow-x: auto; }
      table { width: 100%; border-collapse: collapse; font-size: 14px; }
      th, td {
        text-align: left;
        padding: 8px 10px;
        border-bottom: 1px solid #EFECE4;
      }
      th { color: #55555C; font-weight: 600; }
      .muted { color: #6B6B72; font-size: 12px; }
      .verdict { margin-top: 14px; padding-top: 12px; border-top: 1px solid #EFECE4; }
      footer.doc-foot {
        text-align: center;
        padding: 24px 20px;
        background: #0A0A0C;
        color: #E2C779;
        font-size: 12px;
        letter-spacing: 0.12em;
        text-transform: uppercase;
      }
    </style>
  </head>
  <body>
    <header class="masthead">
      <div class="brand">APEX <span>AUTO</span></div>
      <div class="tagline">The World of Performance &amp; Luxury · Published by Mkhuleko Sitoe</div>
    </header>
    <main>
      ${bodyHtml}
    </main>
    <footer class="doc-foot">
      APEX AUTO · Mkhuleko Sitoe
    </footer>
  </body>
</html>`;
}

export function downloadSingleArticleHtml(article: Article): void {
  const html = wrapEditorialDocumentHtml(article.title, renderArticleSectionHtml(article));
  const blob = new Blob([html], { type: 'text/html;charset=utf-8;' });
  triggerBlobDownload(blob, `${safeFilename(article.slug || article.title)}.html`);
}

export function downloadAllArticlesHtml(articles: Article[]): void {
  const today = new Date().toISOString().split('T')[0];
  const bodyHtml = articles.map(renderArticleSectionHtml).join('\n');
  const html = wrapEditorialDocumentHtml(`Editorial Catalogue (${articles.length} Articles)`, bodyHtml);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8;' });
  triggerBlobDownload(blob, `apex-auto-articles-${today}.html`);
}

export function downloadAllArticlesJson(articles: Article[]): void {
  const today = new Date().toISOString().split('T')[0];
  const payload = {
    publication: 'APEX AUTO',
    tagline: 'THE WORLD OF PERFORMANCE & LUXURY.',
    publisher: 'Mkhuleko Sitoe',
    exportedAt: new Date().toISOString(),
    count: articles.length,
    articles,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], {
    type: 'application/json;charset=utf-8;',
  });
  triggerBlobDownload(blob, `apex-auto-articles-${today}.json`);
}
