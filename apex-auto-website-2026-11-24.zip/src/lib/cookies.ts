import type { CookiePreferences } from '../shared/types';

const STORAGE_KEY = 'apex_cookie_consent';
const COOKIE_VERSION = 1;

export function readCookieConsent(): CookiePreferences | null {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as CookiePreferences;
      if (parsed && parsed.essential === true && typeof parsed.analytics === 'boolean' && typeof parsed.advertising === 'boolean') {
        return parsed;
      }
    }
  } catch {
    // Fallback to document.cookie
  }

  try {
    const match = document.cookie
      .split('; ')
      .find((row) => row.startsWith(`${STORAGE_KEY}=`));
    if (match) {
      const value = decodeURIComponent(match.split('=').slice(1).join('='));
      const parsed = JSON.parse(value) as CookiePreferences;
      if (parsed && parsed.essential === true) {
        return parsed;
      }
    }
  } catch {
    return null;
  }

  return null;
}

export function saveCookieConsent(prefs: {
  analytics: boolean;
  advertising: boolean;
}): CookiePreferences {
  const record: CookiePreferences = {
    essential: true,
    analytics: Boolean(prefs.analytics),
    advertising: Boolean(prefs.advertising),
    updatedAt: new Date().toISOString(),
    version: COOKIE_VERSION,
  };

  const serialized = JSON.stringify(record);
  try {
    window.localStorage.setItem(STORAGE_KEY, serialized);
  } catch {
    // Ignore storage quota errors
  }

  try {
    const maxAge = 60 * 60 * 24 * 365;
    document.cookie = `${STORAGE_KEY}=${encodeURIComponent(serialized)}; Path=/; Max-Age=${maxAge}; SameSite=Lax`;
  } catch {
    // Ignore cookie errors
  }

  return record;
}

export function syncOptionalConsentScripts(
  prefs: CookiePreferences | null,
  adsensePublisherId: string
): void {
  const existingAdScript = document.getElementById('apex-adsense-script');
  const cleanId = adsensePublisherId.trim();

  if (prefs?.advertising && cleanId && /^ca-pub-\d{10,20}$/.test(cleanId)) {
    if (!existingAdScript) {
      const script = document.createElement('script');
      script.id = 'apex-adsense-script';
      script.async = true;
      script.crossOrigin = 'anonymous';
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(cleanId)}`;
      document.head.appendChild(script);
    }
  } else if (existingAdScript) {
    existingAdScript.remove();
  }
}
