import type {
  Article,
  ContactMessageRecord,
  EmailServiceStatus,
  SiteSettings,
  SubscriberRecord,
} from '../shared/types';

let memoryAdminToken: string | null = null;

export function getAdminToken(): string | null {
  return memoryAdminToken;
}

export function setAdminToken(token: string | null): void {
  memoryAdminToken = token;
}

async function requestJson<T>(url: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {}),
  };
  if (memoryAdminToken) {
    headers.Authorization = `Bearer ${memoryAdminToken}`;
  }

  const res = await fetch(url, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data as T;
}

export function fetchBootstrap() {
  return requestJson<{
    articles: Article[];
    settings: SiteSettings;
    emailService: EmailServiceStatus;
  }>('/api/bootstrap');
}

export function fetchArticleBySlug(slug: string) {
  return requestJson<{ article: Article; related: Article[] }>(
    `/api/articles/${encodeURIComponent(slug)}`
  );
}

export function subscribeNewsletterApi(email: string, consent: boolean) {
  return requestJson<{
    ok: boolean;
    alreadySubscribed: boolean;
    emailDispatched: boolean;
    emailServiceConfigured: boolean;
    message: string;
  }>('/api/newsletter/subscribe', {
    method: 'POST',
    body: JSON.stringify({ email, consent }),
  });
}

export function unsubscribeNewsletterApi(payload: { token?: string; email?: string }) {
  return requestJson<{ ok: boolean; message: string }>('/api/newsletter/unsubscribe', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function submitContactApi(payload: {
  name: string;
  email: string;
  subject: string;
  message: string;
}) {
  return requestJson<{ ok: boolean; emailDispatched: boolean; message: string }>('/api/contact', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

// --- Admin Auth & CMS APIs ---

export function fetchAdminAuthStatus() {
  return requestJson<{ needsSetup: boolean; usesEnvPasscode: boolean }>('/api/admin/auth/status');
}

export async function claimAdminPasswordApi(password: string) {
  const res = await requestJson<{ token: string }>('/api/admin/auth/setup', {
    method: 'POST',
    body: JSON.stringify({ password }),
  });
  setAdminToken(res.token);
  return res;
}

export async function loginAdminApi(password: string) {
  const res = await requestJson<{ token: string }>('/api/admin/auth/login', {
    method: 'POST',
    body: JSON.stringify({ password }),
  });
  setAdminToken(res.token);
  return res;
}

export async function logoutAdminApi() {
  try {
    await requestJson<{ ok: boolean }>('/api/admin/auth/logout', { method: 'POST' });
  } finally {
    setAdminToken(null);
  }
}

export function fetchAdminDashboard() {
  return requestJson<{
    articles: Article[];
    settings: SiteSettings;
    subscribers: SubscriberRecord[];
    messages: ContactMessageRecord[];
    emailService: EmailServiceStatus;
  }>('/api/admin/dashboard');
}

export function uploadAdminImageApi(dataUrl: string) {
  return requestJson<{ url: string }>('/api/admin/upload', {
    method: 'POST',
    body: JSON.stringify({ dataUrl }),
  });
}

export function createArticleApi(article: Partial<Article>) {
  return requestJson<{ article: Article }>('/api/admin/articles', {
    method: 'POST',
    body: JSON.stringify(article),
  });
}

export function updateArticleApi(id: number, article: Partial<Article>) {
  return requestJson<{ article: Article }>(`/api/admin/articles/${id}`, {
    method: 'PUT',
    body: JSON.stringify(article),
  });
}

export function deleteArticleApi(id: number) {
  return requestJson<{ ok: boolean }>(`/api/admin/articles/${id}`, {
    method: 'DELETE',
  });
}

export function updateSiteSettingsApi(settings: Partial<SiteSettings>) {
  return requestJson<{ settings: SiteSettings }>('/api/admin/settings', {
    method: 'PUT',
    body: JSON.stringify(settings),
  });
}

export function deleteSubscriberApi(id: number) {
  return requestJson<{ ok: boolean }>(`/api/admin/subscribers/${id}`, {
    method: 'DELETE',
  });
}

export function updateMessageStatusApi(id: number, status: 'read' | 'unread') {
  return requestJson<{ ok: boolean }>(`/api/admin/messages/${id}`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  });
}

export function deleteMessageApi(id: number) {
  return requestJson<{ ok: boolean }>(`/api/admin/messages/${id}`, {
    method: 'DELETE',
  });
}

export async function downloadAdminWebsiteZipApi(): Promise<{
  blob: Blob;
  filename: string;
}> {
  const headers: Record<string, string> = {};
  if (memoryAdminToken) {
    headers.Authorization = `Bearer ${memoryAdminToken}`;
  }
  const res = await fetch('/api/admin/export/website.zip', { headers });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || `Failed to download website ZIP (${res.status})`);
  }
  const blob = await res.blob();
  const dateStr = new Date().toISOString().split('T')[0];
  return { blob, filename: `apex-auto-website-${dateStr}.zip` };
}
