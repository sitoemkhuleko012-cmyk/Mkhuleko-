import { useEffect, useState } from 'react';
import { ArrowLeft, Check, Copy, Download, Mail, Share2, ThumbsDown, ThumbsUp } from 'lucide-react';
import { AdPlacement } from '../components/AdPlacement';
import { ArticleCard } from '../components/ArticleCard';
import { EditorialImage } from '../components/EditorialImage';
import { NewsletterSection } from '../components/NewsletterSection';
import { fetchArticleBySlug } from '../lib/api';
import { downloadSingleArticleHtml } from '../lib/articleExport';
import { formatPublicationDate } from '../lib/format';
import type { Article, CookiePreferences, SiteSettings } from '../shared/types';

interface ArticleDetailPageProps {
  slug: string;
  allArticles: Article[];
  settings: SiteSettings;
  cookieConsent: CookiePreferences | null;
  emailServiceConfigured: boolean;
  onNavigate: (path: string) => void;
}

export function ArticleDetailPage({
  slug,
  allArticles,
  settings,
  cookieConsent,
  emailServiceConfigured,
  onNavigate,
}: ArticleDetailPageProps) {
  const initialFromList = allArticles.find((a) => a.slug === slug) || null;
  const [article, setArticle] = useState<Article | null>(initialFromList);
  const [related, setRelated] = useState<Article[]>([]);
  const [loading, setLoading] = useState(!initialFromList);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let active = true;
    const localMatch = allArticles.find((a) => a.slug === slug) || null;
    if (localMatch) {
      setArticle(localMatch);
      const rel = allArticles
        .filter((a) => a.id !== localMatch.id && a.category === localMatch.category)
        .slice(0, 3);
      const filled =
        rel.length >= 3
          ? rel
          : [
              ...rel,
              ...allArticles.filter((a) => a.id !== localMatch.id && !rel.some((r) => r.id === a.id)),
            ].slice(0, 3);
      setRelated(filled);
      setLoading(false);
    }

    fetchArticleBySlug(slug)
      .then((res) => {
        if (!active) return;
        setArticle(res.article);
        setRelated(res.related);
        setLoading(false);
      })
      .catch(() => {
        if (!active) return;
        setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [slug, allArticles]);

  if (loading) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-20 text-center">
        <p className="font-serif text-2xl text-neutral-600">Loading article...</p>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <h1 className="font-serif text-4xl font-semibold text-[#0A0A0C]">Article Not Found</h1>
        <p className="mt-4 text-sm text-neutral-600">
          The requested story could not be located in the APEX AUTO archive.
        </p>
        <button
          type="button"
          onClick={() => onNavigate('/latest-updates')}
          className="mt-8 min-h-[44px] bg-[#0A0A0C] px-6 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#E2C779]"
        >
          Browse Latest Updates
        </button>
      </div>
    );
  }

  const shareUrl = typeof window !== 'undefined' ? window.location.href : '';
  const paragraphs = article.content.split(/\n\s*\n/).filter((p) => p.trim());
  const specEntries = Object.entries(article.specs || {}).filter(
    ([, val]) => typeof val === 'string' && val.trim().length > 0
  );

  const specLabelMap: Record<string, string> = {
    engine: 'Powertrain / Engine',
    horsepower: 'Maximum Power',
    torque: 'Peak Torque',
    zeroToSixty: '0–60 mph Acceleration',
    topSpeed: 'Top Speed',
    transmission: 'Transmission',
    drivetrain: 'Drivetrain',
    curbWeight: 'Curb Weight',
    price: 'Estimated Base Price',
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2500);
    } catch {
      // Ignore clipboard failures
    }
  };

  return (
    <article className="bg-[#FAF9F6] text-[#111113]">
      {/* Breadcrumb & Header */}
      <div className="mx-auto max-w-[1100px] px-4 pt-10 pb-8 sm:px-6 lg:px-10">
        <button
          type="button"
          onClick={() => onNavigate('/latest-updates')}
          className="inline-flex min-h-[40px] items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-neutral-500 hover:text-[#0A0A0C] transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Editorial Feed
        </button>

        <div className="mt-6 flex flex-wrap items-center gap-2.5 text-xs text-neutral-500">
          <span className="font-semibold uppercase tracking-[0.18em] text-[#8D6B20]">
            {article.category}
          </span>
          {article.manufacturer && (
            <>
              <span aria-hidden="true">·</span>
              <span>{article.manufacturer}</span>
            </>
          )}
          <span aria-hidden="true">·</span>
          <span>{formatPublicationDate(article.publishedAt)}</span>
          <span aria-hidden="true">·</span>
          <span>{article.readTime}</span>
        </div>

        <h1 className="mt-4 font-serif text-3xl font-semibold leading-[1.08] text-[#0A0A0C] sm:text-5xl">
          {article.title}
        </h1>

        <p className="mt-5 max-w-3xl text-lg leading-relaxed text-neutral-600">
          {article.description}
        </p>

        {/* Author Byline & Social Share Bar */}
        <div className="mt-8 flex flex-col justify-between gap-6 border-y border-neutral-200 py-5 sm:flex-row sm:items-center">
          <div className="flex items-center gap-4">
            {settings.publisherPhoto ? (
              <img
                src={settings.publisherPhoto}
                alt={article.author || settings.publisherName}
                referrerPolicy="no-referrer"
                className="h-12 w-12 rounded-full object-cover object-top border border-[#C9A24D]/40"
              />
            ) : (
              <div
                aria-hidden="true"
                className="flex h-12 w-12 items-center justify-center rounded-full border border-[#C9A24D]/50 bg-[#0A0A0C] font-serif text-base font-semibold text-[#E2C779]"
              >
                SM
              </div>
            )}
            <div>
              <p className="text-sm font-semibold text-[#0A0A0C]">
                {article.author || 'Sitoe Mkhuleko'}
              </p>
              <p className="text-xs text-neutral-500">
                Publisher &amp; Automotive Editor, APEX AUTO
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="mr-1 inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-[0.14em] text-neutral-500">
              <Share2 className="h-3.5 w-3.5" />
              Share
            </span>
            <a
              href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[38px] inline-flex items-center border border-neutral-300 bg-white px-3 py-1.5 text-xs font-medium text-[#111113] hover:border-[#0A0A0C] transition-colors"
            >
              Facebook
            </a>
            <a
              href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(article.title)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[38px] inline-flex items-center border border-neutral-300 bg-white px-3 py-1.5 text-xs font-medium text-[#111113] hover:border-[#0A0A0C] transition-colors"
            >
              X / Share
            </a>
            <a
              href={`mailto:?subject=${encodeURIComponent(article.title)}&body=${encodeURIComponent(`${article.description}\n\n${shareUrl}`)}`}
              className="min-h-[38px] inline-flex items-center gap-1.5 border border-neutral-300 bg-white px-3 py-1.5 text-xs font-medium text-[#111113] hover:border-[#0A0A0C] transition-colors"
            >
              <Mail className="h-3.5 w-3.5" />
              Email
            </a>
            <button
              type="button"
              onClick={handleCopyLink}
              className="min-h-[38px] inline-flex items-center gap-1.5 border border-neutral-300 bg-white px-3 py-1.5 text-xs font-medium text-[#111113] hover:border-[#0A0A0C] transition-colors whitespace-nowrap"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-[#8D6B20]" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? 'Copied' : 'Copy Link'}
            </button>
            <button
              type="button"
              onClick={() => downloadSingleArticleHtml(article)}
              className="min-h-[38px] inline-flex items-center gap-1.5 border border-[#0A0A0C] bg-[#0A0A0C] px-3.5 py-1.5 text-xs font-medium text-[#E2C779] hover:bg-[#1E1E24] transition-colors whitespace-nowrap"
            >
              <Download className="h-3.5 w-3.5" />
              Download File
            </button>
          </div>
        </div>
      </div>

      {/* Featured Image */}
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6 lg:px-10">
        <EditorialImage
          src={article.featuredImage}
          alt={article.title}
          caption={article.imageCaption}
          aspectClassName="aspect-[16/9]"
          priority
        />
      </div>

      {/* Main Broadsheet Reading Layout */}
      <div className="mx-auto max-w-[1200px] px-4 py-12 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
          {/* Body Prose Column */}
          <div className="lg:col-span-8">
            <div className="max-w-prose space-y-6 text-base leading-[1.82] text-[#1D1D20] sm:text-[17px]">
              {paragraphs.map((para, idx) => (
                <p key={idx} className={idx === 0 ? 'editorial-drop-cap' : ''}>
                  {para}
                </p>
              ))}
            </div>

            {/* Comparison Matrix if Comparison Vehicles exist */}
            {article.comparisonVehicles.length >= 2 && (
              <section className="mt-12 border border-neutral-200 bg-white p-6 sm:p-8">
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8D6B20]">
                  Technical Comparison
                </p>
                <h2 className="mt-2 font-serif text-2xl font-semibold text-[#0A0A0C]">
                  Head-to-Head Specifications
                </h2>
                <div className="mt-6 overflow-x-auto">
                  <table className="w-full min-w-[560px] border-collapse text-left text-sm">
                    <thead>
                      <tr className="border-b border-neutral-200 text-xs uppercase tracking-[0.14em] text-neutral-500">
                        <th className="py-3 pr-4">Specification</th>
                        {article.comparisonVehicles.map((v) => (
                          <th key={v.name} className="py-3 px-4 font-semibold text-[#0A0A0C]">
                            {v.name}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100">
                      <tr>
                        <td className="py-3 pr-4 text-neutral-600">Manufacturer</td>
                        {article.comparisonVehicles.map((v) => (
                          <td key={v.name} className="py-3 px-4">{v.manufacturer}</td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 pr-4 text-neutral-600">Engine / Powertrain</td>
                        {article.comparisonVehicles.map((v) => (
                          <td key={v.name} className="py-3 px-4">{v.engine}</td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 pr-4 text-neutral-600">Horsepower</td>
                        {article.comparisonVehicles.map((v) => (
                          <td key={v.name} className="py-3 px-4 font-mono tabular-nums font-semibold text-[#8D6B20]">
                            {v.horsepower}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 pr-4 text-neutral-600">Torque</td>
                        {article.comparisonVehicles.map((v) => (
                          <td key={v.name} className="py-3 px-4 font-mono tabular-nums">{v.torque}</td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 pr-4 text-neutral-600">0–60 mph</td>
                        {article.comparisonVehicles.map((v) => (
                          <td key={v.name} className="py-3 px-4 font-mono tabular-nums">{v.zeroToSixty}</td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 pr-4 text-neutral-600">Top Speed</td>
                        {article.comparisonVehicles.map((v) => (
                          <td key={v.name} className="py-3 px-4 font-mono tabular-nums">{v.topSpeed}</td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 pr-4 text-neutral-600">Curb Weight</td>
                        {article.comparisonVehicles.map((v) => (
                          <td key={v.name} className="py-3 px-4 font-mono tabular-nums">{v.weight}</td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 pr-4 text-neutral-600">Drivetrain</td>
                        {article.comparisonVehicles.map((v) => (
                          <td key={v.name} className="py-3 px-4">{v.drivetrain}</td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 pr-4 text-neutral-600">Base Pricing</td>
                        {article.comparisonVehicles.map((v) => (
                          <td key={v.name} className="py-3 px-4 font-mono tabular-nums font-semibold text-[#0A0A0C]">
                            {v.price}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </section>
            )}

            {/* Advantages, Disadvantages & Editorial Verdict */}
            {(article.pros.length > 0 || article.cons.length > 0 || article.verdict) && (
              <section className="mt-12 border border-neutral-200 bg-white p-6 sm:p-8">
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-neutral-200 pb-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8D6B20]">
                      Editorial Assessment
                    </p>
                    <h2 className="mt-1 font-serif text-2xl font-semibold text-[#0A0A0C]">
                      Advantages, Disadvantages &amp; Verdict
                    </h2>
                  </div>
                  {article.rating > 0 && (
                    <div className="text-right">
                      <span className="block text-[11px] uppercase tracking-[0.16em] text-neutral-500">
                        Editorial Rating
                      </span>
                      <span className="font-mono text-2xl font-semibold tabular-nums text-[#8D6B20]">
                        {article.rating.toFixed(1)} / 10
                      </span>
                    </div>
                  )}
                </div>

                <div className="mt-6 grid grid-cols-1 gap-8 sm:grid-cols-2">
                  {article.pros.length > 0 && (
                    <div>
                      <h3 className="flex items-center gap-2 font-sans text-xs font-semibold uppercase tracking-[0.16em] text-emerald-800">
                        <ThumbsUp className="h-4 w-4" />
                        Advantages
                      </h3>
                      <ul className="mt-3 space-y-2.5 text-sm leading-relaxed text-neutral-700">
                        {article.pros.map((pro, i) => (
                          <li key={i} className="flex items-start gap-2.5">
                            <span className="mt-2 h-1.5 w-1.5 shrink-0 bg-[#C9A24D]" />
                            <span>{pro}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {article.cons.length > 0 && (
                    <div>
                      <h3 className="flex items-center gap-2 font-sans text-xs font-semibold uppercase tracking-[0.16em] text-neutral-700">
                        <ThumbsDown className="h-4 w-4" />
                        Disadvantages
                      </h3>
                      <ul className="mt-3 space-y-2.5 text-sm leading-relaxed text-neutral-700">
                        {article.cons.map((con, i) => (
                          <li key={i} className="flex items-start gap-2.5">
                            <span className="mt-2 h-1.5 w-1.5 shrink-0 bg-neutral-400" />
                            <span>{con}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {article.verdict && (
                  <div className="mt-8 border-t border-neutral-200 pt-6">
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#8D6B20]">
                      Editorial Opinion
                    </p>
                    <p className="mt-2 font-serif text-xl italic leading-relaxed text-[#0A0A0C]">
                      “{article.verdict}”
                    </p>
                  </div>
                )}
              </section>
            )}

            <AdPlacement
              slot="inArticleEnabled"
              settings={settings}
              cookieConsent={cookieConsent}
              variant="in-article"
            />
          </div>

          {/* Right Technical Margin Sidebar */}
          <aside className="lg:col-span-4 space-y-8">
            {specEntries.length > 0 && (
              <div className="border border-neutral-200 bg-white p-6">
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8D6B20]">
                  Data Sheet
                </p>
                <h2 className="mt-1.5 font-serif text-2xl font-semibold text-[#0A0A0C]">
                  Key Specifications
                </h2>
                <dl className="mt-5 divide-y divide-neutral-200 text-sm">
                  {specEntries.map(([key, value]) => (
                    <div key={key} className="py-3 flex flex-col gap-1">
                      <dt className="text-xs uppercase tracking-[0.12em] text-neutral-500">
                        {specLabelMap[key] || key}
                      </dt>
                      <dd className="font-mono text-sm font-medium tabular-nums text-[#0A0A0C]">
                        {value}
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>
            )}

            <AdPlacement
              slot="sidebarEnabled"
              settings={settings}
              cookieConsent={cookieConsent}
              variant="sidebar"
            />
          </aside>
        </div>
      </div>

      {/* Related Articles */}
      {related.length > 0 && (
        <section className="border-t border-neutral-200 bg-white py-16">
          <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-10">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#8D6B20]">
              Continue Reading
            </p>
            <h2 className="mt-2 font-serif text-3xl font-semibold text-[#0A0A0C]">
              Related Articles
            </h2>
            <div className="mt-8 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              {related.map((item) => (
                <ArticleCard key={item.id} article={item} onNavigate={onNavigate} />
              ))}
            </div>
          </div>
        </section>
      )}

      <NewsletterSection
        onNavigate={onNavigate}
        emailServiceConfigured={emailServiceConfigured}
        dark
      />
    </article>
  );
}
