import { ArrowRight, Gauge } from 'lucide-react';
import { AdPlacement } from '../components/AdPlacement';
import { ArticleCard } from '../components/ArticleCard';
import { EditorialImage } from '../components/EditorialImage';
import { FollowSection } from '../components/FollowSection';
import { NewsletterSection } from '../components/NewsletterSection';
import { formatPublicationDate } from '../lib/format';
import type { Article, CookiePreferences, SiteSettings } from '../shared/types';

interface HomePageProps {
  articles: Article[];
  settings: SiteSettings;
  cookieConsent: CookiePreferences | null;
  emailServiceConfigured: boolean;
  onNavigate: (path: string) => void;
}

export function HomePage({
  articles,
  settings,
  cookieConsent,
  emailServiceConfigured,
  onNavigate,
}: HomePageProps) {
  const leadArticle =
    articles.find((a) => a.isFeatured) ||
    articles[0];

  const featuredSupercars = articles
    .filter((a) => a.category === 'Supercars')
    .slice(0, 3);

  const latestNews = articles
    .filter((a) => a.id !== leadArticle?.id)
    .slice(0, 4);

  const popularComparisons = articles
    .filter((a) => a.category === 'Comparisons')
    .slice(0, 2);

  const trendingLuxury = articles
    .filter((a) => a.category === 'Luxury Cars' || (a.isTrending && a.category === 'Car Reviews'))
    .slice(0, 3);

  const recentlyPublished = articles.slice(0, 6);

  return (
    <div className="bg-[#FAF9F6] text-[#111113]">
      {/* Grand Automotive Hero */}
      <section className="relative overflow-hidden bg-[#0A0A0C] text-white">
        <div className="relative min-h-[560px] lg:min-h-[680px]">
          <img
            src="/src/assets/images/hero_hypercar_showcase_1795508612490.jpg"
            alt="Flagship obsidian carbon-fiber V12 hypercar at dusk"
            referrerPolicy="no-referrer"
            className="absolute inset-0 h-full w-full object-cover object-center opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0C] via-[#0A0A0C]/55 to-[#0A0A0C]/35" />

          <div className="relative z-10 mx-auto flex min-h-[560px] max-w-[1440px] flex-col justify-between px-4 py-12 sm:px-6 lg:min-h-[680px] lg:px-10 lg:py-16">
            <div className="border-b border-white/15 pb-6">
              <p className="font-serif text-3xl font-semibold tracking-[0.22em] text-white sm:text-4xl">
                APEX <span className="text-[#C9A24D]">AUTO</span>
              </p>
              <p className="mt-2 text-xs font-medium uppercase tracking-[0.28em] text-[#E2C779]">
                THE WORLD OF PERFORMANCE &amp; LUXURY.
              </p>
            </div>

            {leadArticle && (
              <div className="mt-12 max-w-3xl">
                <div className="flex flex-wrap items-center gap-2.5 text-xs text-neutral-300">
                  <span className="font-semibold uppercase tracking-[0.18em] text-[#E2C779]">
                    Cover Story · {leadArticle.category}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{formatPublicationDate(leadArticle.publishedAt)}</span>
                  <span aria-hidden="true">·</span>
                  <span>By {leadArticle.author}</span>
                </div>

                <h1 className="mt-4 font-serif text-4xl font-semibold leading-[1.06] text-white sm:text-5xl lg:text-6xl">
                  {leadArticle.title}
                </h1>

                <p className="mt-5 max-w-2xl text-base leading-relaxed text-neutral-200 sm:text-lg">
                  {leadArticle.description}
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-4">
                  <a
                    href={`/article/${leadArticle.slug}`}
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate(`/article/${leadArticle.slug}`);
                    }}
                    className="inline-flex min-h-[48px] items-center gap-3 bg-[#C9A24D] px-7 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#0A0A0C] transition-colors hover:bg-[#E2C779]"
                  >
                    Read Cover Feature
                    <ArrowRight className="h-4 w-4" />
                  </a>
                  <a
                    href="/supercars"
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate('/supercars');
                    }}
                    className="inline-flex min-h-[48px] items-center gap-2 border border-white/30 px-6 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-white transition-colors hover:border-[#C9A24D] hover:text-[#E2C779]"
                  >
                    Explore Supercars
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      <AdPlacement slot="headerBannerEnabled" settings={settings} cookieConsent={cookieConsent} />

      {/* Featured Supercar Articles */}
      <section className="mx-auto max-w-[1440px] px-4 py-16 sm:px-6 lg:px-10">
        <div className="flex flex-col justify-between gap-4 border-b border-neutral-200 pb-6 sm:flex-row sm:items-end">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#8D6B20]">
              01. Curated Selection
            </p>
            <h2 className="mt-2 font-serif text-3xl font-semibold text-[#0A0A0C] sm:text-4xl">
              Featured Supercar Stories
            </h2>
          </div>
          <a
            href="/supercars"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('/supercars');
            }}
            className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-[#8D6B20] hover:text-[#0A0A0C] transition-colors"
          >
            All Supercars
            <ArrowRight className="h-3.5 w-3.5" />
          </a>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {featuredSupercars.map((article) => (
            <ArticleCard key={article.id} article={article} onNavigate={onNavigate} />
          ))}
        </div>

        {/* Marque & Vehicle Class Directory */}
        <div className="mt-14 border-t border-neutral-200 pt-10">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8D6B20]">
                Supercars &amp; Hypercars
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {['Ferrari', 'Lamborghini', 'Bugatti', 'McLaren', 'Koenigsegg', 'Pagani'].map(
                  (brand) => (
                    <a
                      key={brand}
                      href={`/supercars?brand=${encodeURIComponent(brand)}`}
                      onClick={(e) => {
                        e.preventDefault();
                        onNavigate(`/supercars?brand=${encodeURIComponent(brand)}`);
                      }}
                      className="min-h-[40px] inline-flex items-center border border-neutral-300 bg-white px-4 py-2 text-xs font-semibold tracking-wide text-[#0A0A0C] transition-colors hover:border-[#0A0A0C] hover:bg-[#0A0A0C] hover:text-[#E2C779]"
                    >
                      {brand}
                    </a>
                  )
                )}
              </div>
            </div>

            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8D6B20]">
                Luxury Cars &amp; Grand Tourers
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {['Rolls-Royce', 'Bentley', 'Mercedes-Benz', 'BMW', 'Porsche', 'Aston Martin'].map(
                  (brand) => (
                    <a
                      key={brand}
                      href={`/luxury-cars?brand=${encodeURIComponent(brand)}`}
                      onClick={(e) => {
                        e.preventDefault();
                        onNavigate(`/luxury-cars?brand=${encodeURIComponent(brand)}`);
                      }}
                      className="min-h-[40px] inline-flex items-center border border-neutral-300 bg-white px-4 py-2 text-xs font-semibold tracking-wide text-[#0A0A0C] transition-colors hover:border-[#0A0A0C] hover:bg-[#0A0A0C] hover:text-[#E2C779]"
                    >
                      {brand}
                    </a>
                  )
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Car Comparisons */}
      <section className="bg-[#0A0A0C] py-16 text-[#FAF9F6]">
        <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-10">
          <div className="flex flex-col justify-between gap-4 border-b border-white/15 pb-6 sm:flex-row sm:items-end">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#C9A24D]">
                02. Head-to-Head Analysis
              </p>
              <h2 className="mt-2 font-serif text-3xl font-semibold text-white sm:text-4xl">
                Popular Car Comparisons
              </h2>
            </div>
            <a
              href="/comparisons"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/comparisons');
              }}
              className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-[#E2C779] hover:text-white transition-colors"
            >
              View All Comparisons
              <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </div>

          <div className="mt-10 grid grid-cols-1 gap-8 lg:grid-cols-2">
            {popularComparisons.map((comp) => (
              <article
                key={comp.id}
                className="group flex flex-col border border-white/15 bg-[#121216] transition-colors hover:border-[#C9A24D]/60"
              >
                <a
                  href={`/article/${comp.slug}`}
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate(`/article/${comp.slug}`);
                  }}
                  className="flex h-full flex-col"
                >
                  <EditorialImage
                    src={comp.featuredImage}
                    alt={comp.title}
                    aspectClassName="aspect-[16/9]"
                  />
                  <div className="flex flex-1 flex-col p-6 sm:p-8">
                    <div className="flex items-center gap-2 text-xs text-neutral-400">
                      <span className="font-semibold uppercase tracking-[0.16em] text-[#E2C779]">
                        Comparison Test
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{formatPublicationDate(comp.publishedAt)}</span>
                    </div>

                    <h3 className="mt-3 font-serif text-2xl font-semibold leading-tight text-white group-hover:text-[#E2C779] transition-colors sm:text-3xl">
                      {comp.title}
                    </h3>

                    <p className="mt-3 text-sm leading-relaxed text-neutral-300">
                      {comp.description}
                    </p>

                    {comp.comparisonVehicles.length >= 2 && (
                      <div className="mt-6 grid grid-cols-2 gap-4 border-t border-white/10 pt-5">
                        {comp.comparisonVehicles.slice(0, 2).map((v) => (
                          <div key={v.name}>
                            <p className="text-xs font-semibold text-white">{v.name}</p>
                            <p className="mt-1 font-mono text-xs tabular-nums text-[#E2C779]">
                              {v.horsepower} · {v.zeroToSixty}
                            </p>
                            <p className="mt-0.5 font-mono text-xs tabular-nums text-neutral-400">
                              Top: {v.topSpeed}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Trending Luxury Cars */}
      <section className="mx-auto max-w-[1440px] px-4 py-16 sm:px-6 lg:px-10">
        <div className="flex flex-col justify-between gap-4 border-b border-neutral-200 pb-6 sm:flex-row sm:items-end">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#8D6B20]">
              03. Coachbuilding &amp; Craft
            </p>
            <h2 className="mt-2 font-serif text-3xl font-semibold text-[#0A0A0C] sm:text-4xl">
              Trending Luxury Cars
            </h2>
          </div>
          <a
            href="/luxury-cars"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('/luxury-cars');
            }}
            className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-[#8D6B20] hover:text-[#0A0A0C] transition-colors"
          >
            Explore Luxury Cars
            <ArrowRight className="h-3.5 w-3.5" />
          </a>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {trendingLuxury.map((article) => (
            <ArticleCard key={article.id} article={article} onNavigate={onNavigate} />
          ))}
        </div>
      </section>

      {/* Latest Automotive News & Recently Published Split */}
      <section className="border-t border-neutral-200 bg-white py-16">
        <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-10">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
            {/* Latest Automotive News */}
            <div className="lg:col-span-7">
              <div className="flex items-end justify-between border-b border-neutral-200 pb-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#8D6B20]">
                    04. Industry Dispatches
                  </p>
                  <h2 className="mt-1.5 font-serif text-3xl font-semibold text-[#0A0A0C]">
                    Latest Automotive News
                  </h2>
                </div>
                <a
                  href="/latest-updates"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/latest-updates');
                  }}
                  className="text-xs font-semibold uppercase tracking-[0.16em] text-[#8D6B20] hover:text-[#0A0A0C]"
                >
                  All Updates
                </a>
              </div>

              <div className="mt-2 divide-y divide-neutral-200">
                {latestNews.map((article) => (
                  <ArticleCard
                    key={article.id}
                    article={article}
                    onNavigate={onNavigate}
                    variant="compact"
                  />
                ))}
              </div>
            </div>

            {/* Recently Published Archive & Editorial Highlights */}
            <div className="lg:col-span-5">
              <div className="border border-neutral-200 bg-[#FAF9F6] p-6 sm:p-8">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#8D6B20]">
                  <Gauge className="h-4 w-4" />
                  <span>Recently Published</span>
                </div>
                <h2 className="mt-2 font-serif text-2xl font-semibold text-[#0A0A0C]">
                  From the Editorial Desk
                </h2>

                <ol className="mt-6 divide-y divide-neutral-200">
                  {recentlyPublished.map((item, idx) => (
                    <li key={item.id} className="py-4 first:pt-0 last:pb-0">
                      <a
                        href={`/article/${item.slug}`}
                        onClick={(e) => {
                          e.preventDefault();
                          onNavigate(`/article/${item.slug}`);
                        }}
                        className="group flex items-start gap-4"
                      >
                        <span className="font-mono text-xs font-medium tabular-nums text-[#8D6B20] pt-1">
                          {String(idx + 1).padStart(2, '0')}
                        </span>
                        <div>
                          <p className="font-serif text-lg font-semibold leading-snug text-[#0A0A0C] group-hover:text-[#8D6B20] transition-colors">
                            {item.title}
                          </p>
                          <p className="mt-1 text-xs text-neutral-500">
                            {item.category} <span aria-hidden="true">·</span>{' '}
                            {formatPublicationDate(item.publishedAt)}
                          </p>
                        </div>
                      </a>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          </div>
        </div>
      </section>

      <FollowSection settings={settings} />

      <NewsletterSection
        onNavigate={onNavigate}
        emailServiceConfigured={emailServiceConfigured}
        dark
      />
    </div>
  );
}
