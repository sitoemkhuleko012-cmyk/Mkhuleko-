import { useEffect, useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { unsubscribeNewsletterApi } from '../lib/api';

interface UnsubscribePageProps {
  onNavigate: (path: string) => void;
}

export function UnsubscribePage({ onNavigate }: UnsubscribePageProps) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token');
    if (token) {
      setLoading(true);
      unsubscribeNewsletterApi({ token })
        .then((res) => setStatusMsg(res.message))
        .catch((err) => setError(err instanceof Error ? err.message : 'Unable to unsubscribe.'))
        .finally(() => setLoading(false));
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setStatusMsg(null);
    setLoading(true);
    try {
      const res = await unsubscribeNewsletterApi({ email });
      setStatusMsg(res.message);
      setEmail('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to process unsubscribe request.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#FAF9F6] py-20 text-[#111113]">
      <div className="mx-auto max-w-xl px-4 sm:px-6">
        <div className="border border-neutral-200 bg-white p-8 sm:p-10">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8D6B20]">
            Newsletter Preferences
          </p>
          <h1 className="mt-2 font-serif text-3xl font-semibold text-[#0A0A0C]">
            Unsubscribe from APEX AUTO
          </h1>
          <p className="mt-3 text-sm leading-relaxed text-neutral-600">
            Enter your subscribed email address below to opt out of future APEX AUTO newsletter
            editions.
          </p>

          {statusMsg ? (
            <div className="mt-6 flex items-start gap-2.5 border border-[#C9A24D] bg-[#F3F0E9] p-4 text-sm text-[#0A0A0C]">
              <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[#8D6B20]" />
              <span>{statusMsg}</span>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div>
                <label
                  htmlFor="unsubscribe-email"
                  className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700"
                >
                  Email Address
                </label>
                <input
                  id="unsubscribe-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@domain.com"
                  className="mt-2 min-h-[46px] w-full border border-neutral-300 bg-[#FAF9F6] px-4 py-2.5 text-sm focus:border-[#8D6B20] focus:outline-none"
                />
              </div>
              {error && (
                <div className="border border-red-300 bg-red-50 px-4 py-3 text-xs text-red-800">
                  {error}
                </div>
              )}
              <button
                type="submit"
                disabled={loading}
                className="min-h-[46px] w-full bg-[#0A0A0C] px-6 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#E2C779] hover:bg-[#1E1E24] disabled:opacity-60"
              >
                {loading ? 'Processing...' : 'Confirm Unsubscribe'}
              </button>
            </form>
          )}

          <div className="mt-6 pt-6 border-t border-neutral-200 text-xs">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/');
              }}
              className="text-[#8D6B20] underline underline-offset-4 hover:text-[#0A0A0C]"
            >
              Return to APEX AUTO Homepage
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
