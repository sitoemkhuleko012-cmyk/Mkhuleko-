import { UserRound } from 'lucide-react';
import { NewsletterSection } from '../components/NewsletterSection';
import type { SiteSettings } from '../shared/types';

interface AboutPageProps {
  settings: SiteSettings;
  emailServiceConfigured: boolean;
  onNavigate: (path: string) => void;
}

export function AboutPage({
  settings,
  emailServiceConfigured,
  onNavigate,
}: AboutPageProps) {
  const aboutParagraphs = settings.aboutContent.split(/\n\s*\n/).filter((p) => p.trim());
  const bioParagraphs = settings.publisherBio.split(/\n\s*\n/).filter((p) => p.trim());

  return (
    <div className="bg-[#FAF9F6] text-[#111113]">
      <section className="bg-[#0A0A0C] py-16 text-white sm:py-20">
        <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-10">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#C9A24D]">
            Editorial Masthead
          </p>
          <h1 className="mt-3 font-serif text-4xl font-semibold text-white sm:text-5xl">
            About APEX AUTO
          </h1>
          <p className="mt-4 max-w-2xl text-sm uppercase tracking-[0.18em] text-[#E2C779]">
            THE WORLD OF PERFORMANCE &amp; LUXURY. · Published by {settings.publisherName || 'Sitoe Mkhuleko'}
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1200px] px-4 py-16 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
          {/* Editorial Mission */}
          <div className="lg:col-span-7">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8D6B20]">
              Our Publication
            </p>
            <h2 className="mt-2 font-serif text-3xl font-semibold text-[#0A0A0C]">
              Automotive Journalism with Technical Discipline
            </h2>
            <div className="mt-6 max-w-prose space-y-5 text-base leading-[1.8] text-neutral-700">
              {aboutParagraphs.map((para, i) => (
                <p key={i} className={i === 0 ? 'editorial-drop-cap' : ''}>
                  {para}
                </p>
              ))}
            </div>
          </div>

          {/* Author & Publisher Profile */}
          <div className="lg:col-span-5">
            <div className="border border-neutral-200 bg-white p-6 sm:p-8">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8D6B20]">
                Publisher &amp; Author Profile
              </p>

              <div className="mt-5">
                {settings.publisherPhoto ? (
                  <div className="aspect-[4/5] w-full overflow-hidden bg-[#121215]">
                    <img
                      src={settings.publisherPhoto}
                      alt={settings.publisherName || 'Sitoe Mkhuleko'}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover object-top"
                    />
                  </div>
                ) : (
                  <div className="flex aspect-[4/3] w-full flex-col items-center justify-center border border-dashed border-neutral-300 bg-[#F3F0E9] p-6 text-center">
                    <UserRound className="h-10 w-10 text-[#8D6B20]" strokeWidth={1.3} />
                    <p className="mt-3 font-serif text-lg font-semibold text-[#0A0A0C]">
                      {settings.publisherName || 'Sitoe Mkhuleko'}
                    </p>
                    <p className="mt-1 max-w-xs text-xs leading-relaxed text-neutral-500">
                      Publisher portrait awaiting upload from the secure Administration Dashboard.
                    </p>
                  </div>
                )}
              </div>

              <h3 className="mt-6 font-serif text-2xl font-semibold text-[#0A0A0C]">
                {settings.publisherName || 'Sitoe Mkhuleko'}
              </h3>
              <p className="mt-1 text-xs font-medium uppercase tracking-[0.16em] text-[#8D6B20]">
                Publisher · APEX AUTO
              </p>

              <div className="mt-4 space-y-3 text-sm leading-relaxed text-neutral-700">
                {bioParagraphs.map((para, i) => (
                  <p key={i}>{para}</p>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <NewsletterSection
        onNavigate={onNavigate}
        emailServiceConfigured={emailServiceConfigured}
        dark
      />
    </div>
  );
}
