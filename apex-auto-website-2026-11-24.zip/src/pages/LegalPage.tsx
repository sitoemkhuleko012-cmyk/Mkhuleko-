import { SlidersHorizontal } from 'lucide-react';
import type { SiteSettings } from '../shared/types';

interface LegalPageProps {
  type: 'privacy' | 'cookie' | 'terms';
  settings: SiteSettings;
  onOpenCookieSettings: () => void;
  onNavigate: (path: string) => void;
}

export function LegalPage({
  type,
  settings,
  onOpenCookieSettings,
  onNavigate,
}: LegalPageProps) {
  const titleMap = {
    privacy: 'Privacy Policy',
    cookie: 'Cookie Policy',
    terms: 'Terms and Conditions',
  };

  const subtitleMap = {
    privacy: 'How APEX AUTO collects, protects, and respects your personal information and privacy preferences.',
    cookie: 'Detailed overview of Essential, Analytics, and Advertising cookies used by APEX AUTO.',
    terms: 'Terms governing editorial access, intellectual property, and publication standards.',
  };

  const rawText =
    type === 'privacy'
      ? settings.privacyPolicy
      : type === 'cookie'
      ? settings.cookiePolicy
      : settings.termsContent;

  const blocks = rawText.split(/\n\s*\n/).filter((b) => b.trim());

  return (
    <div className="bg-[#FAF9F6] text-[#111113]">
      <section className="bg-[#0A0A0C] py-14 text-white sm:py-18">
        <div className="mx-auto max-w-[1100px] px-4 sm:px-6 lg:px-10">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#C9A24D]">
            Governance &amp; Compliance
          </p>
          <h1 className="mt-3 font-serif text-4xl font-semibold text-white sm:text-5xl">
            {titleMap[type]}
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-neutral-300 sm:text-base">
            {subtitleMap[type]}
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-[1100px] px-4 py-14 sm:px-6 lg:px-10">
        {type === 'cookie' && (
          <div className="mb-10 flex flex-col justify-between gap-6 border border-[#C9A24D]/40 bg-white p-6 sm:flex-row sm:items-center sm:p-8">
            <div>
              <h2 className="font-serif text-2xl font-semibold text-[#0A0A0C]">
                Manage Your Cookie Preferences
              </h2>
              <p className="mt-1.5 text-sm text-neutral-600">
                You can review, accept, or withdraw optional Analytics and Advertising cookies at
                any time.
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenCookieSettings}
              className="inline-flex min-h-[44px] items-center gap-2 bg-[#0A0A0C] px-6 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#E2C779] hover:bg-[#1C1C22] transition-colors whitespace-nowrap shrink-0"
            >
              <SlidersHorizontal className="h-4 w-4" />
              Cookie Settings
            </button>
          </div>
        )}

        <div className="border border-neutral-200 bg-white p-6 sm:p-10">
          <div className="max-w-prose space-y-5 text-sm leading-[1.85] text-neutral-700 sm:text-[15px]">
            {blocks.map((block, index) => {
              const lines = block.split('\n');
              const firstLine = lines[0].trim();
              const isHeading = /^\d+\.\s+/.test(firstLine) || (lines.length > 1 && firstLine.length < 70 && !firstLine.endsWith('.'));
              if (isHeading && lines.length > 1) {
                return (
                  <div key={index} className="pt-4 first:pt-0">
                    <h2 className="font-serif text-2xl font-semibold text-[#0A0A0C]">
                      {firstLine}
                    </h2>
                    <div className="mt-2.5 space-y-2 whitespace-pre-line">
                      {lines.slice(1).join('\n')}
                    </div>
                  </div>
                );
              }
              return (
                <p key={index} className="whitespace-pre-line">
                  {block}
                </p>
              );
            })}
          </div>

          {type === 'cookie' && (
            <div className="mt-10 border-t border-neutral-200 pt-8 overflow-x-auto">
              <h2 className="font-serif text-2xl font-semibold text-[#0A0A0C]">
                Cookie Categories Summary
              </h2>
              <table className="mt-4 w-full min-w-[540px] border-collapse text-left text-sm">
                <thead>
                  <tr className="border-b border-neutral-200 text-xs uppercase tracking-[0.14em] text-neutral-500">
                    <th className="py-3 pr-4">Category</th>
                    <th className="py-3 px-4">Consent Requirement</th>
                    <th className="py-3 pl-4">Purpose</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  <tr>
                    <td className="py-3.5 pr-4 font-semibold text-[#0A0A0C]">Essential Cookies</td>
                    <td className="py-3.5 px-4 text-[#8D6B20] font-medium">Always Active</td>
                    <td className="py-3.5 pl-4 text-neutral-600">
                      Stores your privacy consent record and maintains core website security and navigation.
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3.5 pr-4 font-semibold text-[#0A0A0C]">Analytics Cookies</td>
                    <td className="py-3.5 px-4 text-neutral-700">Optional (Opt-in)</td>
                    <td className="py-3.5 pl-4 text-neutral-600">
                      Measures aggregate readership patterns across categories to improve editorial coverage.
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3.5 pr-4 font-semibold text-[#0A0A0C]">Advertising Cookies</td>
                    <td className="py-3.5 px-4 text-neutral-700">Optional (Opt-in)</td>
                    <td className="py-3.5 pl-4 text-neutral-600">
                      Enables Google AdSense and advertising partners to serve relevant ads when consented.
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}

          <div className="mt-10 border-t border-neutral-200 pt-6 text-xs text-neutral-500">
            Questions about this policy? Contact the publisher via our{' '}
            <a
              href="/contact-us"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/contact-us');
              }}
              className="text-[#8D6B20] underline underline-offset-4 hover:text-[#0A0A0C]"
            >
              Contact Us
            </a>{' '}
            page.
          </div>
        </div>
      </div>
    </div>
  );
}
