import { useEffect, useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { AdPlacement } from '../components/AdPlacement';
import { ArticleCard } from '../components/ArticleCard';
import { NewsletterSection } from '../components/NewsletterSection';
import type { Article, ArticleCategory, CookiePreferences, SiteSettings } from '../shared/types';

interface CategoryPageProps {
  category: ArticleCategory;
  urlSearch?: string;
  articles: Article[];
  settings: SiteSettings;
  cookieConsent: CookiePreferences | null;
  emailServiceConfigured: boolean;
  onNavigate: (path: string) => void;
}

const CATEGORY_COPY: Record<
  ArticleCategory,
  { kicker: string; title: string; subtitle: string; manufacturers: string[] }
> = {
  Supercars: {
    kicker: 'Extreme Engineering',
    title: 'Supercars & Hypercars',
    subtitle:
      'Dedicated coverage of Ferrari, Lamborghini, Bugatti, McLaren, Koenigsegg, and Pagani machines engineered for pure aerodynamic velocity.',
    manufacturers: ['All', 'Ferrari', 'Lamborghini', 'Bugatti', 'McLaren', 'Koenigsegg', 'Pagani'],
  },
  'Luxury Cars': {
    kicker: 'Bespoke Coachbuilding',
    title: 'Luxury Cars & Grand Tourers',
    subtitle:
      'Featuring Rolls-Royce, Bentley, Mercedes-Benz, BMW, Porsche, and Aston Martin models crafted for effortless continental refinement.',
    manufacturers: ['All', 'Rolls-Royce', 'Bentley', 'Mercedes-Benz', 'BMW', 'Porsche', 'Aston Martin'],
  },
  Comparisons: {
    kicker: 'Head-to-Head Specification Matrix',
    title: 'Car Comparisons',
    subtitle:
      'Data-driven performance comparisons examining horsepower, torque, 0–60 mph acceleration, top speed, curb weight, and real-world pricing.',
    manufacturers: [],
  },
  'Car Reviews': {
    kicker: 'Road Tests & Verdicts',
    title: 'Car Reviews',
    subtitle:
      'Comprehensive road tests presenting photography, full technical specifications, advantages, disadvantages, and candid editorial verdicts.',
    manufacturers: [],
  },
  'Latest Updates': {
    kicker: 'International Dispatches',
    title: 'Latest Automotive Updates',
    subtitle:
      'Recently published dispatches, industry analyses, supercar unveils, and luxury motoring reports authored for APEX AUTO.',
    manufacturers: ['All', 'Supercars', 'Luxury Cars', 'Comparisons', 'Car Reviews'],
  },
};

export function CategoryPage({
  category,
  urlSearch = '',
  articles,
  settings,
  cookieConsent,
  emailServiceConfigured,
  onNavigate,
}: CategoryPageProps) {
  const [selectedBrand, setSelectedBrand] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const meta = CATEGORY_COPY[category];

  useEffect(() => {
    const params = new URLSearchParams(urlSearch);
    const brandParam = params.get('brand');
    if (brandParam && meta.manufacturers.includes(brandParam)) {
      setSelectedBrand(brandParam);
    } else {
      setSelectedBrand('All');
    }
    setSearchQuery('');
  }, [category, urlSearch, meta.manufacturers]);

  const categoryArticles = useMemo(() => {
    const base =
      category === 'Latest Updates'
        ? articles
        : articles.filter((a) => a.category === category);

    return base.filter((a) => {
      const brandMatch =
        selectedBrand === 'All' ||
        (category === 'Latest Updates'
          ? a.category === selectedBrand
          : a.manufacturer.toLowerCase() === selectedBrand.toLowerCase() ||
            a.title.toLowerCase().includes(selectedBrand.toLowerCase()) ||
            a.content.toLowerCase().includes(selectedBrand.toLowerCase()));

      const q = searchQuery.trim().toLowerCase();
      const queryMatch =
        !q ||
        a.title.toLowerCase().includes(q) ||
        a.description.toLowerCase().includes(q) ||
        a.manufacturer.toLowerCase().includes(q);

      return brandMatch && queryMatch;
    });
  }, [articles, category, selectedBrand, searchQuery]);

  return (
    <div className="bg-[#FAF9F6] text-[#111113]">
      {/* Section Masthead */}
      <section className="bg-[#0A0A0C] py-14 text-white sm:py-20">
        <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-10">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#C9A24D]">
            {meta.kicker}
          </p>
          <h1 className="mt-3 font-serif text-4xl font-semibold text-white sm:text-5xl">
            {meta.title}
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-neutral-300 sm:text-base">
            {meta.subtitle}
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-[1440px] px-4 py-12 sm:px-6 lg:px-10">
        {/* Filter / Search Controls */}
        {(meta.manufacturers.length > 0 || category === 'Latest Updates') && (
          <div className="mb-10 flex flex-col gap-4 border-b border-neutral-200 pb-6 lg:flex-row lg:items-center lg:justify-between">
            {meta.manufacturers.length > 0 && (
              <div className="flex flex-wrap items-center gap-2">
                {meta.manufacturers.map((brand) => {
                  const active = selectedBrand === brand;
                  return (
                    <button
                      key={brand}
                      type="button"
                      onClick={() => setSelectedBrand(brand)}
                      className={`min-h-[40px] border px-4 py-2 text-xs font-medium transition-colors whitespace-nowrap ${
                        active
                          ? 'border-[#0A0A0C] bg-[#0A0A0C] text-[#E2C779]'
                          : 'border-neutral-300 bg-white text-neutral-700 hover:border-[#C9A24D] hover:text-[#0A0A0C]'
                      }`}
                    >
                      {brand}
                    </button>
                  );
                })}
              </div>
            )}

            <div className="relative w-full lg:max-w-xs">
              <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={`Filter ${category.toLowerCase()}...`}
                aria-label={`Search ${category}`}
                className="min-h-[42px] w-full border border-neutral-300 bg-white pl-10 pr-4 text-sm text-[#111113] placeholder:text-neutral-500 focus:border-[#8D6B20] focus:outline-none"
              />
            </div>
          </div>
        )}

        <AdPlacement slot="headerBannerEnabled" settings={settings} cookieConsent={cookieConsent} />

        {/* Special Comparison Spec Snapshot Strip when on Comparisons */}
        {category === 'Comparisons' && categoryArticles.length > 0 && (
          <div className="mb-12 space-y-8">
            {categoryArticles
              .filter((a) => a.comparisonVehicles.length >= 2)
              .slice(0, 1)
              .map((comp) => (
                <div key={comp.id} className="border border-neutral-200 bg-white p-6 sm:p-8">
                  <div className="flex flex-col justify-between gap-4 border-b border-neutral-200 pb-5 sm:flex-row sm:items-end">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8D6B20]">
                        Featured Specification Duel
                      </p>
                      <h2 className="mt-1.5 font-serif text-2xl font-semibold text-[#0A0A0C] sm:text-3xl">
                        {comp.title}
                      </h2>
                    </div>
                    <button
                      type="button"
                      onClick={() => onNavigate(`/article/${comp.slug}`)}
                      className="min-h-[42px] bg-[#0A0A0C] px-5 py-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779] hover:bg-[#1E1E24] transition-colors whitespace-nowrap shrink-0"
                    >
                      Read Full Comparison
                    </button>
                  </div>

                  <div className="mt-6 overflow-x-auto">
                    <table className="w-full min-w-[600px] border-collapse text-left text-sm">
                      <thead>
                        <tr className="border-b border-neutral-200 text-xs uppercase tracking-[0.14em] text-neutral-500">
                          <th className="py-3 pr-4 font-semibold">Metric</th>
                          {comp.comparisonVehicles.map((v) => (
                            <th key={v.name} className="py-3 px-4 font-semibold text-[#0A0A0C]">
                              {v.name}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-100">
                        <tr>
                          <td className="py-3 pr-4 font-medium text-neutral-600">Powertrain</td>
                          {comp.comparisonVehicles.map((v) => (
                            <td key={v.name} className="py-3 px-4 text-[#111113]">{v.engine}</td>
                          ))}
                        </tr>
                        <tr>
                          <td className="py-3 pr-4 font-medium text-neutral-600">Horsepower</td>
                          {comp.comparisonVehicles.map((v) => (
                            <td key={v.name} className="py-3 px-4 font-mono tabular-nums font-medium text-[#8D6B20]">
                              {v.horsepower}
                            </td>
                          ))}
                        </tr>
                        <tr>
                          <td className="py-3 pr-4 font-medium text-neutral-600">0–60 mph</td>
                          {comp.comparisonVehicles.map((v) => (
                            <td key={v.name} className="py-3 px-4 font-mono tabular-nums text-[#111113]">
                              {v.zeroToSixty}
                            </td>
                          ))}
                        </tr>
                        <tr>
                          <td className="py-3 pr-4 font-medium text-neutral-600">Top Speed</td>
                          {comp.comparisonVehicles.map((v) => (
                            <td key={v.name} className="py-3 px-4 font-mono tabular-nums text-[#111113]">
                              {v.topSpeed}
                            </td>
                          ))}
                        </tr>
                        <tr>
                          <td className="py-3 pr-4 font-medium text-neutral-600">Starting Price</td>
                          {comp.comparisonVehicles.map((v) => (
                            <td key={v.name} className="py-3 px-4 font-mono tabular-nums font-semibold text-[#0A0A0C]">
                              {v.price}
                            </td>
                          ))}
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
          </div>
        )}

        {/* Articles Grid */}
        {categoryArticles.length === 0 ? (
          <div className="border border-neutral-200 bg-white p-12 text-center">
            <p className="font-serif text-2xl font-semibold text-[#0A0A0C]">
              No matching articles found
            </p>
            <p className="mt-2 text-sm text-neutral-600">
              Try clearing your manufacturer filter or search term to view all {category} stories.
            </p>
            <button
              type="button"
              onClick={() => {
                setSelectedBrand('All');
                setSearchQuery('');
              }}
              className="mt-6 min-h-[42px] border border-[#0A0A0C] px-5 py-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#0A0A0C] hover:bg-[#0A0A0C] hover:text-white transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {categoryArticles.map((article) => (
              <ArticleCard key={article.id} article={article} onNavigate={onNavigate} />
            ))}
          </div>
        )}
      </div>

      <NewsletterSection
        onNavigate={onNavigate}
        emailServiceConfigured={emailServiceConfigured}
        dark
      />
    </div>
  );
}
