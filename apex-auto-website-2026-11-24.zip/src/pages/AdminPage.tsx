import { useEffect, useState } from 'react';
import {
  Check,
  CheckCircle2,
  Copy,
  Download,
  Edit3,
  Globe,
  Lock,
  LogOut,
  Mail,
  Plus,
  Shield,
  Trash2,
  Upload,
  UserRound,
} from 'lucide-react';
import {
  claimAdminPasswordApi,
  createArticleApi,
  deleteArticleApi,
  deleteMessageApi,
  deleteSubscriberApi,
  downloadAdminWebsiteZipApi,
  fetchAdminAuthStatus,
  fetchAdminDashboard,
  getAdminToken,
  loginAdminApi,
  logoutAdminApi,
  updateArticleApi,
  updateMessageStatusApi,
  updateSiteSettingsApi,
  uploadAdminImageApi,
} from '../lib/api';
import {
  downloadAllArticlesHtml,
  downloadAllArticlesJson,
  downloadSingleArticleHtml,
} from '../lib/articleExport';
import { formatPublicationDate } from '../lib/format';
import type {
  Article,
  ArticleCategory,
  ComparisonVehicle,
  ContactMessageRecord,
  EmailServiceStatus,
  SiteSettings,
  SubscriberRecord,
} from '../shared/types';

interface AdminPageProps {
  onDataMutated: () => void;
  onNavigate: (path: string) => void;
}

type AdminTab = 'articles' | 'about' | 'policies' | 'seo' | 'audience' | 'deployment';

const CATEGORIES: ArticleCategory[] = [
  'Supercars',
  'Luxury Cars',
  'Comparisons',
  'Car Reviews',
  'Latest Updates',
];

const STOCK_IMAGE_CHOICES = [
  { label: 'Hero Carbon V12 Hypercar', url: '/src/assets/images/hero_hypercar_showcase_1795508612490.jpg' },
  { label: 'Bugatti Hypercar at Chateau', url: '/src/assets/images/bugatti_tourbillon_hypercar_1795511035955.jpg' },
  { label: 'Koenigsegg Jesko Attack (Track Aero)', url: '/src/assets/images/koenigsegg_jesko_attack_1795511035843.jpg' },
  { label: 'Porsche Panamera Turbo E-Hybrid', url: '/src/assets/images/porsche_panamera_turbo_1795511037008.jpg' },
  { label: 'Porsche 911 GT3 RS Alpine Pass', url: '/src/assets/images/porsche_911_gt3_rs_1795511037234.jpg' },
  { label: 'Alpine Mid-Engine Supercar', url: '/src/assets/images/supercar_track_action_1795508612145.jpg' },
  { label: 'BMW 7 Series & M8 Competition', url: '/src/assets/images/bmw_luxury_flagship_1795511361397.jpg' },
  { label: 'Rolls-Royce Phantom Manor Drive', url: '/src/assets/images/rolls_royce_phantom_1795511361017.jpg' },
  { label: 'Mercedes-Maybach S 680 Two-Tone', url: '/src/assets/images/mercedes_maybach_s680_1795511361985.jpg' },
  { label: 'Bentley Flying Spur Speed Mulliner', url: '/src/assets/images/bentley_flying_spur_speed_1795511600969.jpg' },
  { label: 'Bentley Continental GT Speed', url: '/src/assets/images/bentley_continental_gt_speed_1795511600687.jpg' },
  { label: 'British Luxury Grand Tourer', url: '/src/assets/images/luxury_grand_tourer_1795508613372.jpg' },
  { label: 'Airstrip Comparison Duo', url: '/src/assets/images/gt_comparison_duo_1795508613436.jpg' },
  { label: 'Bespoke Gold & Leather Cockpit', url: '/src/assets/images/cockpit_bespoke_interior_1795508613019.jpg' },
  { label: 'Electric Hyper-GT Gallery', url: '/src/assets/images/electric_hyper_gt_1795508613763.jpg' },
];

function emptyArticleForm(): Partial<Article> {
  return {
    title: '',
    slug: '',
    description: '',
    category: 'Supercars',
    manufacturer: '',
    author: 'Sitoe Mkhuleko',
    publishedAt: new Date().toISOString().split('T')[0],
    featuredImage: STOCK_IMAGE_CHOICES[0].url,
    imageCaption: '',
    content: '',
    isFeatured: false,
    isTrending: false,
    readTime: '6 min read',
    specs: {},
    pros: [],
    cons: [],
    verdict: '',
    rating: 0,
    comparisonVehicles: [],
    seoTitle: '',
    seoDescription: '',
  };
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Failed to read selected file.'));
    reader.readAsDataURL(file);
  });
}

export function AdminPage({ onDataMutated, onNavigate }: AdminPageProps) {
  const [authStatus, setAuthStatus] = useState<{
    loading: boolean;
    needsSetup: boolean;
    usesEnvPasscode: boolean;
  }>({ loading: true, needsSetup: false, usesEnvPasscode: false });
  const [authenticated, setAuthenticated] = useState(Boolean(getAdminToken()));

  const [passwordInput, setPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSubmitting, setAuthSubmitting] = useState(false);

  const [tab, setTab] = useState<AdminTab>('articles');
  const [loadingDash, setLoadingDash] = useState(false);
  const [articles, setArticles] = useState<Article[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [subscribers, setSubscribers] = useState<SubscriberRecord[]>([]);
  const [messages, setMessages] = useState<ContactMessageRecord[]>([]);
  const [emailService, setEmailService] = useState<EmailServiceStatus>({
    configured: false,
    providerLabel: '',
  });

  const [editingArticleId, setEditingArticleId] = useState<number | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [articleForm, setArticleForm] = useState<Partial<Article>>(emptyArticleForm());
  const [prosText, setProsText] = useState('');
  const [consText, setConsText] = useState('');

  const [toast, setToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [saving, setSaving] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const showToast = (type: 'success' | 'error', text: string) => {
    setToast({ type, text });
    window.setTimeout(() => setToast(null), 4500);
  };

  const loadDashboard = async () => {
    setLoadingDash(true);
    try {
      const data = await fetchAdminDashboard();
      setArticles(data.articles);
      setSettings(data.settings);
      setSubscribers(data.subscribers);
      setMessages(data.messages);
      setEmailService(data.emailService);
      setAuthenticated(true);
    } catch {
      setAuthenticated(false);
    } finally {
      setLoadingDash(false);
    }
  };

  useEffect(() => {
    fetchAdminAuthStatus()
      .then((res) => {
        setAuthStatus({
          loading: false,
          needsSetup: res.needsSetup,
          usesEnvPasscode: res.usesEnvPasscode,
        });
        if (getAdminToken()) {
          loadDashboard();
        }
      })
      .catch(() => {
        setAuthStatus({ loading: false, needsSetup: false, usesEnvPasscode: false });
      });
  }, []);

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSubmitting(true);

    try {
      if (authStatus.needsSetup) {
        if (passwordInput.length < 8) {
          throw new Error('Administrator password must be at least 8 characters.');
        }
        if (passwordInput !== confirmPasswordInput) {
          throw new Error('Passwords do not match.');
        }
        await claimAdminPasswordApi(passwordInput);
        setAuthStatus((prev) => ({ ...prev, needsSetup: false }));
      } else {
        await loginAdminApi(passwordInput);
      }
      setPasswordInput('');
      setConfirmPasswordInput('');
      await loadDashboard();
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleLogout = async () => {
    await logoutAdminApi();
    setAuthenticated(false);
    setSettings(null);
  };

  const openNewArticle = () => {
    setEditingArticleId(null);
    setArticleForm(emptyArticleForm());
    setProsText('');
    setConsText('');
    setShowEditor(true);
  };

  const openEditArticle = (art: Article) => {
    setEditingArticleId(art.id);
    setArticleForm({ ...art });
    setProsText((art.pros || []).join('\n'));
    setConsText((art.cons || []).join('\n'));
    setShowEditor(true);
  };

  const handleArticleImageUpload = async (file: File | undefined) => {
    if (!file) return;
    setUploadingPhoto(true);
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const res = await uploadAdminImageApi(dataUrl);
      setArticleForm((prev) => ({ ...prev, featuredImage: res.url }));
      showToast('success', 'Article photograph uploaded.');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Upload failed.');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handlePublisherPhotoUpload = async (file: File | undefined) => {
    if (!file || !settings) return;
    setUploadingPhoto(true);
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const res = await uploadAdminImageApi(dataUrl);
      const updated = await updateSiteSettingsApi({ publisherPhoto: res.url });
      setSettings(updated.settings);
      onDataMutated();
      showToast('success', 'Publisher photograph updated.');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Upload failed.');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSaveArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload: Partial<Article> = {
        ...articleForm,
        pros: prosText
          .split('\n')
          .map((l) => l.trim())
          .filter(Boolean),
        cons: consText
          .split('\n')
          .map((l) => l.trim())
          .filter(Boolean),
      };

      if (editingArticleId) {
        await updateArticleApi(editingArticleId, payload);
        showToast('success', 'Article updated and published.');
      } else {
        await createArticleApi(payload);
        showToast('success', 'New article created and published.');
      }

      setShowEditor(false);
      await loadDashboard();
      onDataMutated();
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Failed to save article.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteArticle = async (id: number, title: string) => {
    if (!window.confirm(`Delete "${title}" permanently?`)) return;
    try {
      await deleteArticleApi(id);
      await loadDashboard();
      onDataMutated();
      showToast('success', 'Article deleted.');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Delete failed.');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    try {
      const res = await updateSiteSettingsApi(settings);
      setSettings(res.settings);
      onDataMutated();
      showToast('success', 'Site settings saved.');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Failed to save settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleExportSubscribersCsv = () => {
    const header = 'email,status,subscribed_at,unsubscribed_at\n';
    const rows = subscribers
      .map(
        (s) =>
          `"${s.email.replace(/"/g, '""')}","${s.status}","${s.subscribedAt}","${
            s.unsubscribedAt || ''
          }"`
      )
      .join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `apex-auto-subscribers-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const handleDownloadWebsiteZip = async () => {
    setDownloadingZip(true);
    try {
      const { blob, filename } = await downloadAdminWebsiteZipApi();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      showToast('success', 'Full APEX AUTO website ZIP downloaded to your device.');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Unable to download ZIP.');
    } finally {
      setDownloadingZip(false);
    }
  };

  const handleCopyCommand = async (key: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedCmd(key);
      window.setTimeout(() => setCopiedCmd(null), 2000);
    } catch {
      // Ignore clipboard failures
    }
  };

  if (authStatus.loading) {
    return (
      <div className="py-24 text-center text-sm text-neutral-600">
        Verifying editorial session...
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="min-h-[75vh] bg-[#0A0A0C] py-20 text-white">
        <div className="mx-auto max-w-md px-4">
          <div className="border border-[#C9A24D]/40 bg-[#121216] p-8 sm:p-10">
            <div className="flex items-center gap-2.5 text-[#E2C779]">
              <Lock className="h-5 w-5" />
              <span className="text-xs font-semibold uppercase tracking-[0.2em]">
                Protected Editorial Desk
              </span>
            </div>

            <h1 className="mt-4 font-serif text-3xl font-semibold text-white">
              {authStatus.needsSetup
                ? 'Claim Administrator Access'
                : 'Administrator Sign-In'}
            </h1>

            <p className="mt-2.5 text-sm leading-relaxed text-neutral-400">
              {authStatus.needsSetup
                ? 'Set the initial administrator password for APEX AUTO. This one-time setup locks automatically once claimed.'
                : 'Enter your administrator credentials to manage articles, publisher media, policies, SEO, and subscribers.'}
            </p>

            <form onSubmit={handleAuthSubmit} className="mt-6 space-y-4">
              <div>
                <label
                  htmlFor="admin-password"
                  className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-300"
                >
                  {authStatus.needsSetup ? 'Create Password (min. 8 characters)' : 'Password'}
                </label>
                <input
                  id="admin-password"
                  type="password"
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="mt-2 min-h-[46px] w-full border border-white/20 bg-[#0A0A0C] px-4 py-2.5 text-sm text-white focus:border-[#C9A24D] focus:outline-none"
                />
              </div>

              {authStatus.needsSetup && (
                <div>
                  <label
                    htmlFor="admin-password-confirm"
                    className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-300"
                  >
                    Confirm Password
                  </label>
                  <input
                    id="admin-password-confirm"
                    type="password"
                    required
                    value={confirmPasswordInput}
                    onChange={(e) => setConfirmPasswordInput(e.target.value)}
                    className="mt-2 min-h-[46px] w-full border border-white/20 bg-[#0A0A0C] px-4 py-2.5 text-sm text-white focus:border-[#C9A24D] focus:outline-none"
                  />
                </div>
              )}

              {authError && (
                <div className="border border-red-500/40 bg-red-950/40 px-4 py-3 text-xs text-red-200">
                  {authError}
                </div>
              )}

              <button
                type="submit"
                disabled={authSubmitting}
                className="min-h-[46px] w-full bg-[#C9A24D] px-6 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#0A0A0C] hover:bg-[#E2C779] transition-colors disabled:opacity-60"
              >
                {authSubmitting
                  ? 'Verifying...'
                  : authStatus.needsSetup
                  ? 'Set Password & Enter Dashboard'
                  : 'Sign In'}
              </button>
            </form>

            <div className="mt-6 border-t border-white/10 pt-5 text-xs text-neutral-500">
              <a
                href="/"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('/');
                }}
                className="hover:text-[#E2C779]"
              >
                ← Return to APEX AUTO Magazine
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-[#111113]">
      {/* Admin Top Header */}
      <div className="border-b border-white/10 bg-[#0A0A0C] py-8 text-white">
        <div className="mx-auto flex max-w-[1440px] flex-col justify-between gap-4 px-4 sm:flex-row sm:items-center sm:px-6 lg:px-10">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#C9A24D]">
              APEX AUTO CMS
            </p>
            <h1 className="mt-1 font-serif text-3xl font-semibold text-white">
              Administrator Dashboard
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleDownloadWebsiteZip}
              disabled={downloadingZip}
              className="inline-flex min-h-[42px] items-center gap-2 bg-[#C9A24D] px-4 py-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#0A0A0C] hover:bg-[#E2C779] transition-colors disabled:opacity-60 whitespace-nowrap"
            >
              <Download className="h-3.5 w-3.5" />
              {downloadingZip ? 'Packaging ZIP...' : 'Download Website (.zip)'}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('/')}
              className="min-h-[42px] border border-white/25 px-4 py-2 text-xs font-semibold uppercase tracking-[0.14em] text-white hover:border-[#C9A24D] whitespace-nowrap"
            >
              View Live Site
            </button>
            <button
              type="button"
              onClick={handleLogout}
              className="inline-flex min-h-[42px] items-center gap-2 border border-[#C9A24D]/50 px-4 py-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779] hover:bg-[#C9A24D]/15 whitespace-nowrap"
            >
              <LogOut className="h-3.5 w-3.5" />
              Sign Out
            </button>
          </div>
        </div>
      </div>

      {toast && (
        <div className="mx-auto mt-6 max-w-[1440px] px-4 sm:px-6 lg:px-10">
          <div
            className={`flex items-center gap-2.5 border px-4 py-3 text-sm ${
              toast.type === 'success'
                ? 'border-[#C9A24D] bg-white text-[#0A0A0C]'
                : 'border-red-300 bg-red-50 text-red-900'
            }`}
          >
            <CheckCircle2 className="h-4 w-4 text-[#8D6B20]" />
            <span>{toast.text}</span>
          </div>
        </div>
      )}

      <div className="mx-auto max-w-[1440px] px-4 py-10 sm:px-6 lg:px-10">
        {/* Tab Bar */}
        <div className="mb-8 flex flex-wrap gap-2 border-b border-neutral-200 pb-4">
          {[
            { id: 'articles', label: 'Articles & Reviews' },
            { id: 'about', label: 'Publisher & About Us' },
            { id: 'policies', label: 'Privacy & Cookie Policies' },
            { id: 'seo', label: 'Social, SEO & AdSense' },
            { id: 'audience', label: `Newsletter (${subscribers.length}) & Inbox (${messages.length})` },
            { id: 'deployment', label: 'Export & Hosting' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id as AdminTab)}
              className={`min-h-[42px] border px-4 py-2 text-xs font-semibold uppercase tracking-[0.12em] transition-colors whitespace-nowrap ${
                tab === item.id
                  ? 'border-[#0A0A0C] bg-[#0A0A0C] text-[#E2C779]'
                  : 'border-neutral-300 bg-white text-neutral-700 hover:border-[#C9A24D]'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {loadingDash && !settings ? (
          <p className="py-12 text-sm text-neutral-600">Loading dashboard records...</p>
        ) : (
          <>
            {/* TAB 1: ARTICLES */}
            {tab === 'articles' && (
              <div>
                {!showEditor ? (
                  <div>
                    <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
                      <h2 className="font-serif text-2xl font-semibold text-[#0A0A0C]">
                        Published Editorial Catalogue ({articles.length})
                      </h2>
                      <div className="flex flex-wrap items-center gap-2.5">
                        <button
                          type="button"
                          onClick={() => {
                            downloadAllArticlesHtml(articles);
                            showToast('success', 'All articles downloaded as a readable HTML file.');
                          }}
                          disabled={articles.length === 0}
                          className="inline-flex min-h-[44px] items-center gap-2 border border-[#0A0A0C] bg-white px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.12em] text-[#0A0A0C] hover:border-[#8D6B20] hover:text-[#8D6B20] disabled:opacity-40 whitespace-nowrap"
                        >
                          <Download className="h-4 w-4" />
                          Download All (HTML)
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            downloadAllArticlesJson(articles);
                            showToast('success', 'All articles downloaded as a JSON file.');
                          }}
                          disabled={articles.length === 0}
                          className="inline-flex min-h-[44px] items-center gap-2 border border-neutral-300 bg-white px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.12em] text-[#111113] hover:border-[#0A0A0C] disabled:opacity-40 whitespace-nowrap"
                        >
                          <Download className="h-4 w-4" />
                          Download All (JSON)
                        </button>
                        <button
                          type="button"
                          onClick={openNewArticle}
                          className="inline-flex min-h-[44px] items-center gap-2 bg-[#0A0A0C] px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779] hover:bg-[#1E1E24] whitespace-nowrap"
                        >
                          <Plus className="h-4 w-4" />
                          Add New Article
                        </button>
                      </div>
                    </div>

                    <div className="overflow-x-auto border border-neutral-200 bg-white">
                      <table className="w-full min-w-[760px] border-collapse text-left text-sm">
                        <thead>
                          <tr className="border-b border-neutral-200 bg-[#F3F0E9] text-xs uppercase tracking-[0.12em] text-neutral-600">
                            <th className="py-3.5 px-4">Title</th>
                            <th className="py-3.5 px-4">Category</th>
                            <th className="py-3.5 px-4">Date</th>
                            <th className="py-3.5 px-4">Placement</th>
                            <th className="py-3.5 px-4 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-neutral-200">
                          {articles.map((art) => (
                            <tr key={art.id} className="hover:bg-[#FAF9F6]">
                              <td className="py-4 px-4">
                                <div className="flex items-center gap-3">
                                  <img
                                    src={art.featuredImage}
                                    alt={art.title}
                                    className="h-12 w-16 shrink-0 object-cover bg-neutral-900"
                                  />
                                  <div>
                                    <p className="font-semibold text-[#0A0A0C] line-clamp-1">
                                      {art.title}
                                    </p>
                                    <p className="text-xs text-neutral-500">
                                      /article/{art.slug}
                                    </p>
                                  </div>
                                </div>
                              </td>
                              <td className="py-4 px-4 text-xs font-medium text-[#8D6B20]">
                                {art.category}
                              </td>
                              <td className="py-4 px-4 font-mono text-xs tabular-nums text-neutral-600">
                                {formatPublicationDate(art.publishedAt)}
                              </td>
                              <td className="py-4 px-4 text-xs text-neutral-600">
                                {[
                                  art.isFeatured ? 'Featured' : null,
                                  art.isTrending ? 'Trending' : null,
                                ]
                                  .filter(Boolean)
                                  .join(' · ') || 'Standard'}
                              </td>
                              <td className="py-4 px-4 text-right">
                                <div className="inline-flex items-center gap-2">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      downloadSingleArticleHtml(art);
                                      showToast('success', `Downloaded "${art.title}".`);
                                    }}
                                    className="inline-flex min-h-[36px] items-center gap-1.5 border border-neutral-300 px-3 py-1.5 text-xs font-medium hover:border-[#8D6B20] hover:text-[#8D6B20]"
                                  >
                                    <Download className="h-3.5 w-3.5" />
                                    Download
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => openEditArticle(art)}
                                    className="inline-flex min-h-[36px] items-center gap-1.5 border border-neutral-300 px-3 py-1.5 text-xs font-medium hover:border-[#0A0A0C]"
                                  >
                                    <Edit3 className="h-3.5 w-3.5" />
                                    Edit
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteArticle(art.id, art.title)}
                                    className="inline-flex min-h-[36px] items-center gap-1.5 border border-red-200 px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                    Delete
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  <form
                    onSubmit={handleSaveArticle}
                    className="border border-neutral-200 bg-white p-6 sm:p-8 space-y-6"
                  >
                    <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
                      <h2 className="font-serif text-2xl font-semibold text-[#0A0A0C]">
                        {editingArticleId ? 'Edit Article' : 'Create New Article'}
                      </h2>
                      <button
                        type="button"
                        onClick={() => setShowEditor(false)}
                        className="text-xs font-semibold uppercase tracking-[0.14em] text-neutral-600 hover:text-[#0A0A0C]"
                      >
                        Cancel
                      </button>
                    </div>

                    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                          Article Title
                        </label>
                        <input
                          type="text"
                          required
                          value={articleForm.title || ''}
                          onChange={(e) =>
                            setArticleForm((p) => ({ ...p, title: e.target.value }))
                          }
                          className="mt-2 min-h-[44px] w-full border border-neutral-300 px-3.5 py-2 text-sm focus:border-[#8D6B20] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                          SEO URL Slug (optional)
                        </label>
                        <input
                          type="text"
                          value={articleForm.slug || ''}
                          onChange={(e) =>
                            setArticleForm((p) => ({ ...p, slug: e.target.value }))
                          }
                          placeholder="auto-generated-from-title"
                          className="mt-2 min-h-[44px] w-full border border-neutral-300 px-3.5 py-2 text-sm focus:border-[#8D6B20] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                          Category
                        </label>
                        <select
                          value={articleForm.category || 'Supercars'}
                          onChange={(e) =>
                            setArticleForm((p) => ({
                              ...p,
                              category: e.target.value as ArticleCategory,
                            }))
                          }
                          className="mt-2 min-h-[44px] w-full border border-neutral-300 bg-white px-3.5 py-2 text-sm focus:border-[#8D6B20] focus:outline-none"
                        >
                          {CATEGORIES.map((c) => (
                            <option key={c} value={c}>
                              {c}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                          Manufacturer
                        </label>
                        <input
                          type="text"
                          value={articleForm.manufacturer || ''}
                          onChange={(e) =>
                            setArticleForm((p) => ({ ...p, manufacturer: e.target.value }))
                          }
                          placeholder="Ferrari, Rolls-Royce, Porsche..."
                          className="mt-2 min-h-[44px] w-full border border-neutral-300 px-3.5 py-2 text-sm focus:border-[#8D6B20] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                          Publication Date
                        </label>
                        <input
                          type="date"
                          required
                          value={articleForm.publishedAt || ''}
                          onChange={(e) =>
                            setArticleForm((p) => ({ ...p, publishedAt: e.target.value }))
                          }
                          className="mt-2 min-h-[44px] w-full border border-neutral-300 px-3.5 py-2 text-sm focus:border-[#8D6B20] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                          Author
                        </label>
                        <input
                          type="text"
                          value={articleForm.author || 'Sitoe Mkhuleko'}
                          onChange={(e) =>
                            setArticleForm((p) => ({ ...p, author: e.target.value }))
                          }
                          className="mt-2 min-h-[44px] w-full border border-neutral-300 px-3.5 py-2 text-sm focus:border-[#8D6B20] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                        Short Description / Standfirst
                      </label>
                      <textarea
                        rows={2}
                        required
                        value={articleForm.description || ''}
                        onChange={(e) =>
                          setArticleForm((p) => ({ ...p, description: e.target.value }))
                        }
                        className="mt-2 w-full border border-neutral-300 px-3.5 py-2 text-sm focus:border-[#8D6B20] focus:outline-none"
                      />
                    </div>

                    {/* Featured Image Upload & Selection */}
                    <div className="border border-neutral-200 bg-[#FAF9F6] p-5">
                      <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                        Featured Photograph
                      </label>
                      <div className="mt-3 grid grid-cols-1 gap-4 md:grid-cols-12 items-center">
                        <div className="md:col-span-4">
                          {articleForm.featuredImage && (
                            <img
                              src={articleForm.featuredImage}
                              alt="Selected preview"
                              className="aspect-[16/10] w-full object-cover bg-neutral-900"
                            />
                          )}
                        </div>
                        <div className="md:col-span-8 space-y-3">
                          <div className="flex flex-wrap items-center gap-3">
                            <label className="inline-flex min-h-[40px] cursor-pointer items-center gap-2 bg-[#0A0A0C] px-4 py-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779] hover:bg-[#1E1E24]">
                              <Upload className="h-3.5 w-3.5" />
                              {uploadingPhoto ? 'Uploading...' : 'Upload Photograph'}
                              <input
                                type="file"
                                accept="image/jpeg,image/png,image/webp"
                                className="hidden"
                                onChange={(e) =>
                                  handleArticleImageUpload(e.target.files?.[0])
                                }
                              />
                            </label>
                            <select
                              value={articleForm.featuredImage || ''}
                              onChange={(e) =>
                                setArticleForm((p) => ({ ...p, featuredImage: e.target.value }))
                              }
                              className="min-h-[40px] border border-neutral-300 bg-white px-3 py-2 text-xs"
                            >
                              <option value="">Choose library image...</option>
                              {STOCK_IMAGE_CHOICES.map((img) => (
                                <option key={img.url} value={img.url}>
                                  {img.label}
                                </option>
                              ))}
                            </select>
                          </div>
                          <input
                            type="text"
                            value={articleForm.featuredImage || ''}
                            onChange={(e) =>
                              setArticleForm((p) => ({ ...p, featuredImage: e.target.value }))
                            }
                            placeholder="Image URL or /uploads/..."
                            className="min-h-[40px] w-full border border-neutral-300 bg-white px-3 py-2 text-xs"
                          />
                          <input
                            type="text"
                            value={articleForm.imageCaption || ''}
                            onChange={(e) =>
                              setArticleForm((p) => ({ ...p, imageCaption: e.target.value }))
                            }
                            placeholder="Figure caption (e.g. Fig. 1 — Alpine descent at dawn)"
                            className="min-h-[40px] w-full border border-neutral-300 bg-white px-3 py-2 text-xs"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                        Full Article Content (separate paragraphs with a blank line)
                      </label>
                      <textarea
                        rows={10}
                        required
                        value={articleForm.content || ''}
                        onChange={(e) =>
                          setArticleForm((p) => ({ ...p, content: e.target.value }))
                        }
                        className="mt-2 w-full border border-neutral-300 px-3.5 py-2.5 text-sm leading-relaxed focus:border-[#8D6B20] focus:outline-none"
                      />
                    </div>

                    <div className="flex flex-wrap gap-6">
                      <label className="inline-flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={Boolean(articleForm.isFeatured)}
                          onChange={(e) =>
                            setArticleForm((p) => ({ ...p, isFeatured: e.target.checked }))
                          }
                          className="h-4 w-4 accent-[#C9A24D]"
                        />
                        Featured on Homepage
                      </label>
                      <label className="inline-flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={Boolean(articleForm.isTrending)}
                          onChange={(e) =>
                            setArticleForm((p) => ({ ...p, isTrending: e.target.checked }))
                          }
                          className="h-4 w-4 accent-[#C9A24D]"
                        />
                        Trending Story
                      </label>
                    </div>

                    {/* Specifications & Review Fields */}
                    <div className="border-t border-neutral-200 pt-6">
                      <h3 className="font-serif text-xl font-semibold text-[#0A0A0C]">
                        Vehicle Specifications &amp; Editorial Review
                      </h3>
                      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
                        {(
                          [
                            ['engine', 'Engine'],
                            ['horsepower', 'Horsepower'],
                            ['torque', 'Torque'],
                            ['zeroToSixty', '0–60 mph'],
                            ['topSpeed', 'Top Speed'],
                            ['price', 'Estimated Price'],
                          ] as const
                        ).map(([key, label]) => (
                          <div key={key}>
                            <label className="block text-xs font-medium text-neutral-600">
                              {label}
                            </label>
                            <input
                              type="text"
                              value={articleForm.specs?.[key] || ''}
                              onChange={(e) =>
                                setArticleForm((p) => ({
                                  ...p,
                                  specs: { ...(p.specs || {}), [key]: e.target.value },
                                }))
                              }
                              className="mt-1 min-h-[40px] w-full border border-neutral-300 px-3 py-1.5 text-xs"
                            />
                          </div>
                        ))}
                      </div>

                      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <div>
                          <label className="block text-xs font-medium text-neutral-600">
                            Advantages (one per line)
                          </label>
                          <textarea
                            rows={3}
                            value={prosText}
                            onChange={(e) => setProsText(e.target.value)}
                            className="mt-1 w-full border border-neutral-300 p-2.5 text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-neutral-600">
                            Disadvantages (one per line)
                          </label>
                          <textarea
                            rows={3}
                            value={consText}
                            onChange={(e) => setConsText(e.target.value)}
                            className="mt-1 w-full border border-neutral-300 p-2.5 text-xs"
                          />
                        </div>
                      </div>

                      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-4">
                        <div className="sm:col-span-3">
                          <label className="block text-xs font-medium text-neutral-600">
                            Editorial Verdict
                          </label>
                          <input
                            type="text"
                            value={articleForm.verdict || ''}
                            onChange={(e) =>
                              setArticleForm((p) => ({ ...p, verdict: e.target.value }))
                            }
                            className="mt-1 min-h-[40px] w-full border border-neutral-300 px-3 py-1.5 text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-neutral-600">
                            Rating (0–10)
                          </label>
                          <input
                            type="number"
                            step="0.1"
                            min="0"
                            max="10"
                            value={articleForm.rating || 0}
                            onChange={(e) =>
                              setArticleForm((p) => ({
                                ...p,
                                rating: Number.parseFloat(e.target.value) || 0,
                              }))
                            }
                            className="mt-1 min-h-[40px] w-full border border-neutral-300 px-3 py-1.5 text-xs"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Comparison Vehicles Editor */}
                    {articleForm.category === 'Comparisons' && (
                      <div className="border-t border-neutral-200 pt-6">
                        <div className="flex items-center justify-between">
                          <h3 className="font-serif text-xl font-semibold text-[#0A0A0C]">
                            Comparison Vehicles
                          </h3>
                          <button
                            type="button"
                            onClick={() =>
                              setArticleForm((p) => ({
                                ...p,
                                comparisonVehicles: [
                                  ...(p.comparisonVehicles || []),
                                  {
                                    name: '',
                                    manufacturer: '',
                                    engine: '',
                                    horsepower: '',
                                    torque: '',
                                    zeroToSixty: '',
                                    topSpeed: '',
                                    weight: '',
                                    price: '',
                                    drivetrain: '',
                                  },
                                ],
                              }))
                            }
                            className="border border-[#0A0A0C] px-3 py-1.5 text-xs font-medium"
                          >
                            + Add Vehicle
                          </button>
                        </div>

                        <div className="mt-4 space-y-4">
                          {(articleForm.comparisonVehicles || []).map((veh, idx) => (
                            <div
                              key={idx}
                              className="grid grid-cols-2 gap-3 border border-neutral-200 bg-[#FAF9F6] p-4 sm:grid-cols-5"
                            >
                              {(
                                [
                                  ['name', 'Model Name'],
                                  ['manufacturer', 'Brand'],
                                  ['engine', 'Engine'],
                                  ['horsepower', 'Horsepower'],
                                  ['torque', 'Torque'],
                                  ['zeroToSixty', '0–60 mph'],
                                  ['topSpeed', 'Top Speed'],
                                  ['weight', 'Weight'],
                                  ['drivetrain', 'Drivetrain'],
                                  ['price', 'Price'],
                                ] as Array<[keyof ComparisonVehicle, string]>
                              ).map(([field, label]) => (
                                <input
                                  key={field}
                                  type="text"
                                  placeholder={label}
                                  value={veh[field]}
                                  onChange={(e) => {
                                    const copy = [...(articleForm.comparisonVehicles || [])];
                                    copy[idx] = { ...copy[idx], [field]: e.target.value };
                                    setArticleForm((p) => ({ ...p, comparisonVehicles: copy }));
                                  }}
                                  className="min-h-[38px] border border-neutral-300 bg-white px-2.5 py-1 text-xs"
                                />
                              ))}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Per-Article SEO */}
                    <div className="border-t border-neutral-200 pt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                          Custom SEO Title
                        </label>
                        <input
                          type="text"
                          value={articleForm.seoTitle || ''}
                          onChange={(e) =>
                            setArticleForm((p) => ({ ...p, seoTitle: e.target.value }))
                          }
                          className="mt-2 min-h-[42px] w-full border border-neutral-300 px-3 py-2 text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                          Custom SEO Meta Description
                        </label>
                        <input
                          type="text"
                          value={articleForm.seoDescription || ''}
                          onChange={(e) =>
                            setArticleForm((p) => ({ ...p, seoDescription: e.target.value }))
                          }
                          className="mt-2 min-h-[42px] w-full border border-neutral-300 px-3 py-2 text-xs"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-3 pt-4">
                      <button
                        type="button"
                        onClick={() => setShowEditor(false)}
                        className="min-h-[44px] border border-neutral-300 px-6 py-2.5 text-xs font-semibold uppercase tracking-[0.14em]"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={saving}
                        className="min-h-[44px] bg-[#0A0A0C] px-7 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779] hover:bg-[#1E1E24] disabled:opacity-60"
                      >
                        {saving ? 'Saving...' : editingArticleId ? 'Save Changes' : 'Publish Article'}
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}

            {/* TAB 2: PUBLISHER & ABOUT US */}
            {tab === 'about' && settings && (
              <form
                onSubmit={handleSaveSettings}
                className="border border-neutral-200 bg-white p-6 sm:p-8 space-y-8"
              >
                <div>
                  <h2 className="font-serif text-2xl font-semibold text-[#0A0A0C]">
                    Publisher Photograph &amp; Biography
                  </h2>
                  <p className="mt-1 text-sm text-neutral-600">
                    Upload an authentic photograph of publisher Sitoe Mkhuleko to display on the
                    About Us page and article bylines.
                  </p>

                  <div className="mt-6 flex flex-col gap-6 sm:flex-row sm:items-center">
                    {settings.publisherPhoto ? (
                      <img
                        src={settings.publisherPhoto}
                        alt={settings.publisherName}
                        className="h-36 w-36 object-cover border border-[#C9A24D]/50"
                      />
                    ) : (
                      <div className="flex h-36 w-36 flex-col items-center justify-center border border-dashed border-neutral-300 bg-[#FAF9F6] text-center p-3">
                        <UserRound className="h-8 w-8 text-[#8D6B20]" />
                        <span className="mt-1 text-[11px] text-neutral-500">No photo uploaded</span>
                      </div>
                    )}

                    <div className="space-y-3">
                      <div className="flex flex-wrap gap-3">
                        <label className="inline-flex min-h-[42px] cursor-pointer items-center gap-2 bg-[#0A0A0C] px-5 py-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779] hover:bg-[#1E1E24]">
                          <Upload className="h-4 w-4" />
                          {uploadingPhoto ? 'Uploading...' : 'Upload Publisher Photo'}
                          <input
                            type="file"
                            accept="image/jpeg,image/png,image/webp"
                            className="hidden"
                            onChange={(e) => handlePublisherPhotoUpload(e.target.files?.[0])}
                          />
                        </label>

                        {settings.publisherPhoto && (
                          <button
                            type="button"
                            onClick={() =>
                              setSettings((s) => (s ? { ...s, publisherPhoto: '' } : s))
                            }
                            className="min-h-[42px] border border-red-300 px-4 py-2 text-xs font-medium text-red-700 hover:bg-red-50"
                          >
                            Remove Photo
                          </button>
                        )}
                      </div>
                      <p className="text-xs text-neutral-500">
                        Accepts JPEG, PNG, or WebP up to 5 MB.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-6">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                      Publisher Name
                    </label>
                    <input
                      type="text"
                      value={settings.publisherName}
                      onChange={(e) =>
                        setSettings({ ...settings, publisherName: e.target.value })
                      }
                      className="mt-2 min-h-[44px] w-full max-w-md border border-neutral-300 px-3.5 py-2 text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                      Publisher Short Biography
                    </label>
                    <textarea
                      rows={4}
                      value={settings.publisherBio}
                      onChange={(e) =>
                        setSettings({ ...settings, publisherBio: e.target.value })
                      }
                      className="mt-2 w-full border border-neutral-300 p-3.5 text-sm leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                      About Us Page Content
                    </label>
                    <textarea
                      rows={8}
                      value={settings.aboutContent}
                      onChange={(e) =>
                        setSettings({ ...settings, aboutContent: e.target.value })
                      }
                      className="mt-2 w-full border border-neutral-300 p-3.5 text-sm leading-relaxed"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={saving}
                  className="min-h-[44px] bg-[#0A0A0C] px-7 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779]"
                >
                  {saving ? 'Saving...' : 'Save About & Publisher Details'}
                </button>
              </form>
            )}

            {/* TAB 3: LEGAL POLICIES */}
            {tab === 'policies' && settings && (
              <form
                onSubmit={handleSaveSettings}
                className="border border-neutral-200 bg-white p-6 sm:p-8 space-y-6"
              >
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                    Privacy Policy Content
                  </label>
                  <textarea
                    rows={12}
                    value={settings.privacyPolicy}
                    onChange={(e) =>
                      setSettings({ ...settings, privacyPolicy: e.target.value })
                    }
                    className="mt-2 w-full border border-neutral-300 p-3.5 text-sm leading-relaxed"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                    Cookie Policy Content
                  </label>
                  <textarea
                    rows={10}
                    value={settings.cookiePolicy}
                    onChange={(e) =>
                      setSettings({ ...settings, cookiePolicy: e.target.value })
                    }
                    className="mt-2 w-full border border-neutral-300 p-3.5 text-sm leading-relaxed"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                    Terms and Conditions Content
                  </label>
                  <textarea
                    rows={8}
                    value={settings.termsContent}
                    onChange={(e) =>
                      setSettings({ ...settings, termsContent: e.target.value })
                    }
                    className="mt-2 w-full border border-neutral-300 p-3.5 text-sm leading-relaxed"
                  />
                </div>

                <button
                  type="submit"
                  disabled={saving}
                  className="min-h-[44px] bg-[#0A0A0C] px-7 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779]"
                >
                  {saving ? 'Saving...' : 'Save Policy Documents'}
                </button>
              </form>
            )}

            {/* TAB 4: SOCIAL, SEO & ADSENSE */}
            {tab === 'seo' && settings && (
              <form
                onSubmit={handleSaveSettings}
                className="border border-neutral-200 bg-white p-6 sm:p-8 space-y-8"
              >
                <div>
                  <h2 className="font-serif text-2xl font-semibold text-[#0A0A0C]">
                    Social Media Channels
                  </h2>
                  <p className="mt-1 text-xs text-neutral-600">
                    Configure official profile URLs for header, footer, and community sections.
                    Leave blank if a profile is not yet active.
                  </p>
                  <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                        Instagram Profile URL
                      </label>
                      <input
                        type="url"
                        value={settings.instagramUrl}
                        onChange={(e) =>
                          setSettings({ ...settings, instagramUrl: e.target.value })
                        }
                        placeholder="https://www.instagram.com/yourhandle"
                        className="mt-2 min-h-[44px] w-full border border-neutral-300 px-3.5 py-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                        Facebook Page URL
                      </label>
                      <input
                        type="url"
                        value={settings.facebookUrl}
                        onChange={(e) =>
                          setSettings({ ...settings, facebookUrl: e.target.value })
                        }
                        placeholder="https://www.facebook.com/yourpage"
                        className="mt-2 min-h-[44px] w-full border border-neutral-300 px-3.5 py-2 text-sm"
                      />
                    </div>
                  </div>
                </div>

                <div className="border-t border-neutral-200 pt-6">
                  <h2 className="font-serif text-2xl font-semibold text-[#0A0A0C]">
                    Search Engine Optimization &amp; Verification
                  </h2>
                  <div className="mt-4 grid grid-cols-1 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                        Global SEO Site Title
                      </label>
                      <input
                        type="text"
                        value={settings.seoSiteTitle}
                        onChange={(e) =>
                          setSettings({ ...settings, seoSiteTitle: e.target.value })
                        }
                        className="mt-2 min-h-[44px] w-full border border-neutral-300 px-3.5 py-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                        Global Meta Description
                      </label>
                      <textarea
                        rows={2}
                        value={settings.seoSiteDescription}
                        onChange={(e) =>
                          setSettings({ ...settings, seoSiteDescription: e.target.value })
                        }
                        className="mt-2 w-full border border-neutral-300 p-3 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                        Google Search Console Verification Code
                      </label>
                      <input
                        type="text"
                        value={settings.googleSiteVerification}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            googleSiteVerification: e.target.value,
                          })
                        }
                        placeholder="Paste the content token from Google Search Console HTML tag"
                        className="mt-2 min-h-[44px] w-full border border-neutral-300 px-3.5 py-2 text-sm"
                      />
                    </div>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-4 text-xs">
                    <a
                      href="/sitemap.xml"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="underline text-[#8D6B20]"
                    >
                      Inspect Live XML Sitemap (/sitemap.xml)
                    </a>
                    <a
                      href="/robots.txt"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="underline text-[#8D6B20]"
                    >
                      Inspect robots.txt (/robots.txt)
                    </a>
                  </div>
                </div>

                <div className="border-t border-neutral-200 pt-6">
                  <h2 className="font-serif text-2xl font-semibold text-[#0A0A0C]">
                    Google AdSense &amp; Advertising Placements
                  </h2>
                  <p className="mt-1 text-xs leading-relaxed text-neutral-600">
                    Ad slots remain dormant until your Google AdSense application is reviewed and
                    approved by Google and a valid Publisher ID is saved below. Scripts only load
                    for visitors who consent to Advertising cookies.
                  </p>

                  <div className="mt-4">
                    <label className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700">
                      Google AdSense Publisher ID
                    </label>
                    <input
                      type="text"
                      value={settings.adsensePublisherId}
                      onChange={(e) =>
                        setSettings({ ...settings, adsensePublisherId: e.target.value })
                      }
                      placeholder="ca-pub-0000000000000000"
                      className="mt-2 min-h-[44px] w-full max-w-md border border-neutral-300 px-3.5 py-2 font-mono text-sm"
                    />
                  </div>

                  <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {(
                      [
                        ['headerBannerEnabled', 'Header Leaderboard Placement'],
                        ['inArticleEnabled', 'In-Article Editorial Placement'],
                        ['sidebarEnabled', 'Article Sidebar Placement'],
                        ['footerBannerEnabled', 'Footer Placement'],
                      ] as const
                    ).map(([key, label]) => (
                      <label
                        key={key}
                        className="flex items-center gap-3 border border-neutral-200 p-3.5 text-sm"
                      >
                        <input
                          type="checkbox"
                          checked={settings.adPlacements[key]}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              adPlacements: {
                                ...settings.adPlacements,
                                [key]: e.target.checked,
                              },
                            })
                          }
                          className="h-4 w-4 accent-[#C9A24D]"
                        />
                        <span>{label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={saving}
                  className="min-h-[44px] bg-[#0A0A0C] px-7 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779]"
                >
                  {saving ? 'Saving...' : 'Save Social, SEO & Ad Settings'}
                </button>
              </form>
            )}

            {/* TAB 5: NEWSLETTER & CONTACT INBOX */}
            {tab === 'audience' && (
              <div className="space-y-10">
                {/* Email Delivery Status Card */}
                <div className="border border-neutral-200 bg-white p-6">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <Mail className="h-5 w-5 text-[#8D6B20]" />
                      <div>
                        <h2 className="font-serif text-xl font-semibold text-[#0A0A0C]">
                          Email Service Status: {emailService.providerLabel}
                        </h2>
                        <p className="text-xs text-neutral-600">
                          {emailService.configured
                            ? 'Outbound SMTP delivery is active for welcome emails and contact alerts.'
                            : 'Configure SMTP_HOST, SMTP_PORT, SMTP_USER, and SMTP_PASS in server secrets to dispatch live welcome emails.'}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleExportSubscribersCsv}
                      disabled={subscribers.length === 0}
                      className="inline-flex min-h-[40px] items-center gap-2 border border-[#0A0A0C] px-4 py-2 text-xs font-semibold uppercase tracking-[0.14em] disabled:opacity-40"
                    >
                      <Download className="h-3.5 w-3.5" />
                      Export Subscribers CSV
                    </button>
                  </div>
                </div>

                {/* Subscribers Table */}
                <div className="border border-neutral-200 bg-white p-6">
                  <h2 className="font-serif text-2xl font-semibold text-[#0A0A0C]">
                    Newsletter Subscribers ({subscribers.length})
                  </h2>
                  {subscribers.length === 0 ? (
                    <p className="mt-4 text-sm text-neutral-500">No subscribers recorded yet.</p>
                  ) : (
                    <div className="mt-4 overflow-x-auto">
                      <table className="w-full min-w-[560px] border-collapse text-left text-sm">
                        <thead>
                          <tr className="border-b border-neutral-200 text-xs uppercase tracking-[0.12em] text-neutral-500">
                            <th className="py-3 pr-4">Email</th>
                            <th className="py-3 px-4">Status</th>
                            <th className="py-3 px-4">Subscribed</th>
                            <th className="py-3 pl-4 text-right">Remove</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-neutral-100">
                          {subscribers.map((sub) => (
                            <tr key={sub.id}>
                              <td className="py-3 pr-4 font-medium">{sub.email}</td>
                              <td className="py-3 px-4 text-xs uppercase tracking-wider">
                                {sub.status}
                              </td>
                              <td className="py-3 px-4 font-mono text-xs tabular-nums text-neutral-500">
                                {formatPublicationDate(sub.subscribedAt)}
                              </td>
                              <td className="py-3 pl-4 text-right">
                                <button
                                  type="button"
                                  onClick={async () => {
                                    await deleteSubscriberApi(sub.id);
                                    await loadDashboard();
                                  }}
                                  className="text-xs text-red-700 hover:underline"
                                >
                                  Delete
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Contact Messages */}
                <div className="border border-neutral-200 bg-white p-6">
                  <h2 className="font-serif text-2xl font-semibold text-[#0A0A0C]">
                    Contact Us Messages ({messages.length})
                  </h2>
                  {messages.length === 0 ? (
                    <p className="mt-4 text-sm text-neutral-500">No contact inquiries yet.</p>
                  ) : (
                    <div className="mt-4 divide-y divide-neutral-200">
                      {messages.map((msg) => (
                        <div key={msg.id} className="py-5">
                          <div className="flex flex-wrap items-start justify-between gap-4">
                            <div>
                              <p className="text-sm font-semibold text-[#0A0A0C]">
                                {msg.subject}{' '}
                                <span className="ml-2 text-xs font-normal text-[#8D6B20]">
                                  ({msg.status})
                                </span>
                              </p>
                              <p className="mt-1 text-xs text-neutral-500">
                                From {msg.name} &lt;{msg.email}&gt; ·{' '}
                                {formatPublicationDate(msg.createdAt)}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={async () => {
                                  await updateMessageStatusApi(
                                    msg.id,
                                    msg.status === 'read' ? 'unread' : 'read'
                                  );
                                  await loadDashboard();
                                }}
                                className="border border-neutral-300 px-3 py-1 text-xs"
                              >
                                Mark {msg.status === 'read' ? 'Unread' : 'Read'}
                              </button>
                              <button
                                type="button"
                                onClick={async () => {
                                  await deleteMessageApi(msg.id);
                                  await loadDashboard();
                                }}
                                className="border border-red-200 px-3 py-1 text-xs text-red-700"
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                          <p className="mt-3 whitespace-pre-line text-sm text-neutral-700">
                            {msg.message}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB 6: EXPORT & HOSTING HUB */}
            {tab === 'deployment' && (
              <div className="space-y-8">
                <div className="border border-[#C9A24D]/40 bg-white p-6 sm:p-10 space-y-6">
                  <div className="flex items-center gap-2.5 text-[#8D6B20]">
                    <Download className="h-5 w-5" />
                    <span className="text-xs font-semibold uppercase tracking-[0.2em]">
                      Mobile Website Export
                    </span>
                  </div>
                  <h2 className="font-serif text-3xl font-semibold text-[#0A0A0C]">
                    Download APEX AUTO Website &amp; Articles
                  </h2>
                  <p className="max-w-2xl text-sm leading-relaxed text-neutral-600">
                    Download the complete deployable website package straight to your phone—including the homepage, all 10 pages, vehicle photography, your portrait, and backend server—ready to upload to a Node.js hosting platform.
                  </p>

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    <button
                      type="button"
                      onClick={handleDownloadWebsiteZip}
                      disabled={downloadingZip}
                      className="flex min-h-[52px] items-center justify-center gap-2.5 bg-[#0A0A0C] px-5 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#E2C779] hover:bg-[#1E1E24] transition-colors disabled:opacity-60"
                    >
                      <Download className="h-4 w-4" />
                      {downloadingZip ? 'Packaging Website ZIP...' : 'Download Full Website (.zip)'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        downloadAllArticlesHtml(articles);
                        showToast('success', 'All articles downloaded as HTML.');
                      }}
                      disabled={articles.length === 0}
                      className="flex min-h-[52px] items-center justify-center gap-2.5 border border-[#0A0A0C] bg-white px-5 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#0A0A0C] hover:border-[#8D6B20] hover:text-[#8D6B20] disabled:opacity-40"
                    >
                      <Download className="h-4 w-4" />
                      Download All Articles (HTML)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        downloadAllArticlesJson(articles);
                        showToast('success', 'All articles downloaded as JSON.');
                      }}
                      disabled={articles.length === 0}
                      className="flex min-h-[52px] items-center justify-center gap-2.5 border border-neutral-300 bg-white px-5 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#111113] hover:border-[#0A0A0C] disabled:opacity-40"
                    >
                      <Download className="h-4 w-4" />
                      Download All Articles (JSON)
                    </button>
                  </div>
                </div>

                <div className="border border-neutral-200 bg-white p-6 sm:p-10 space-y-6">
                  <div className="flex items-center gap-2.5 text-[#8D6B20]">
                    <Globe className="h-5 w-5" />
                    <span className="text-xs font-semibold uppercase tracking-[0.2em]">
                      Recommended Hosting Guide
                    </span>
                  </div>
                  <h2 className="font-serif text-3xl font-semibold text-[#0A0A0C]">
                    Where &amp; How to Host APEX AUTO
                  </h2>

                  <div className="max-w-3xl space-y-6 text-sm leading-relaxed text-neutral-700">
                    <div>
                      <h3 className="font-serif text-xl font-semibold text-[#0A0A0C]">
                        1. Best Hosting Platforms (Node.js 22+)
                      </h3>
                      <p className="mt-2">
                        Because APEX AUTO includes a live Express server, SQLite database, photo uploads, and the Admin Dashboard, choose a host that runs <strong>Node.js 22+</strong> rather than a static HTML-only host:
                      </p>
                      <ul className="mt-2.5 list-disc pl-5 space-y-1.5 text-neutral-700">
                        <li><strong>Render (Recommended):</strong> Create a Web Service, connect your code, and attach a Persistent Disk for <code className="bg-neutral-100 px-1 font-mono text-xs">data</code> and <code className="bg-neutral-100 px-1 font-mono text-xs">uploads</code>.</li>
                        <li><strong>Railway:</strong> Deploy directly with a persistent Volume mounted for saved articles and uploaded portraits.</li>
                        <li><strong>Google Cloud Run or Node.js VPS:</strong> Ideal if connecting a custom <code className="bg-neutral-100 px-1 font-mono text-xs">.com</code> domain with automated HTTPS.</li>
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-serif text-xl font-semibold text-[#0A0A0C]">
                        2. Build &amp; Start Commands
                      </h3>
                      <div className="mt-3 space-y-3">
                        {[
                          { key: 'build', label: 'Build Command', cmd: 'npm install && npm run build' },
                          { key: 'start', label: 'Start Command', cmd: 'NODE_ENV=production npm start' },
                        ].map((item) => (
                          <div
                            key={item.key}
                            className="flex flex-wrap items-center justify-between gap-3 border border-neutral-200 bg-[#FAF9F6] px-4 py-3"
                          >
                            <div>
                              <p className="text-xs font-semibold uppercase tracking-[0.12em] text-neutral-500">
                                {item.label}
                              </p>
                              <code className="font-mono text-xs text-[#0A0A0C]">{item.cmd}</code>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleCopyCommand(item.key, item.cmd)}
                              className="inline-flex min-h-[38px] items-center gap-1.5 border border-neutral-300 bg-white px-3 py-1.5 text-xs font-medium hover:border-[#0A0A0C]"
                            >
                              {copiedCmd === item.key ? (
                                <>
                                  <Check className="h-3.5 w-3.5 text-[#8D6B20]" />
                                  Copied
                                </>
                              ) : (
                                <>
                                  <Copy className="h-3.5 w-3.5" />
                                  Copy
                                </>
                              )}
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="font-serif text-xl font-semibold text-[#0A0A0C]">
                        3. Environment Variables
                      </h3>
                      <ul className="mt-2 list-disc pl-5 space-y-1.5 font-mono text-xs text-neutral-800">
                        <li>NODE_ENV=production</li>
                        <li>APP_URL=https://www.yourdomain.com</li>
                        <li>ADMIN_PASSCODE=your-strong-secret-passphrase</li>
                        <li>SMTP_HOST / SMTP_PORT / SMTP_USER / SMTP_PASS / SMTP_FROM (optional for live emails)</li>
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-serif text-xl font-semibold text-[#0A0A0C]">
                        4. Google Search Console &amp; AdSense Review Checklist
                      </h3>
                      <p className="mt-2">
                        Once live on HTTPS, paste your Google Search Console verification token in the{' '}
                        <strong>Social, SEO &amp; AdSense</strong> tab, submit{' '}
                        <code className="font-mono text-xs">https://www.yourdomain.com/sitemap.xml</code>,
                        and ensure original high-resolution articles, About Us, Contact Us, Privacy
                        Policy, and Cookie Policy pages are all accessible before submitting for
                        Google AdSense review.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
