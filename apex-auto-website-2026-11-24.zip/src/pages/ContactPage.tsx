import { useState } from 'react';
import { CheckCircle2, Mail, Send } from 'lucide-react';
import { NewsletterSection } from '../components/NewsletterSection';
import { submitContactApi } from '../lib/api';
import type { SiteSettings } from '../shared/types';

interface ContactPageProps {
  settings: SiteSettings;
  emailServiceConfigured: boolean;
  onNavigate: (path: string) => void;
}

export function ContactPage({
  settings,
  emailServiceConfigured,
  onNavigate,
}: ContactPageProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setSubmitting(true);

    try {
      const res = await submitContactApi({ name, email, subject, message });
      setSuccess(res.message);
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to submit inquiry.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-[#FAF9F6] text-[#111113]">
      <section className="bg-[#0A0A0C] py-16 text-white">
        <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-10">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#C9A24D]">
            Editorial Correspondence
          </p>
          <h1 className="mt-3 font-serif text-4xl font-semibold text-white sm:text-5xl">
            Contact APEX AUTO
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-neutral-300 sm:text-base">
            Reach our editorial desk regarding press invitations, vehicle loan requests,
            advertising partnerships, or privacy inquiries.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-[1200px] px-4 py-16 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
          {/* Contact Information Sidebar */}
          <div className="lg:col-span-4 space-y-6">
            <div className="border border-neutral-200 bg-white p-6 sm:p-8">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-[#8D6B20]">
                <Mail className="h-4 w-4" />
                <span>Editorial Desk</span>
              </div>
              <h2 className="mt-3 font-serif text-2xl font-semibold text-[#0A0A0C]">
                Direct Inquiries
              </h2>
              <p className="mt-3 text-sm leading-relaxed text-neutral-600">
                APEX AUTO is published by{' '}
                <strong className="font-semibold text-[#0A0A0C]">
                  {settings.publisherName || 'Sitoe Mkhuleko'}
                </strong>
                . All inquiries submitted via this form are recorded securely for editorial review.
              </p>

              <dl className="mt-6 space-y-4 border-t border-neutral-200 pt-5 text-sm">
                <div>
                  <dt className="text-xs font-semibold uppercase tracking-[0.14em] text-neutral-500">
                    Press &amp; Road Tests
                  </dt>
                  <dd className="mt-1 text-neutral-700">
                    Manufacturer embargoes, track invitations, and specification briefings.
                  </dd>
                </div>
                <div>
                  <dt className="text-xs font-semibold uppercase tracking-[0.14em] text-neutral-500">
                    Privacy &amp; Data Requests
                  </dt>
                  <dd className="mt-1 text-neutral-700">
                    Access, correction, or deletion requests regarding personal information.
                  </dd>
                </div>
              </dl>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-8">
            <form
              onSubmit={handleSubmit}
              className="border border-neutral-200 bg-white p-6 sm:p-10"
            >
              <h2 className="font-serif text-3xl font-semibold text-[#0A0A0C]">
                Send a Message
              </h2>
              <p className="mt-2 text-sm text-neutral-600">
                Complete all fields below and our editorial team will respond promptly.
              </p>

              <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="contact-name"
                    className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700"
                  >
                    Name
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your full name"
                    className="mt-2 min-h-[46px] w-full border border-neutral-300 bg-[#FAF9F6] px-4 py-2.5 text-sm text-[#111113] focus:border-[#8D6B20] focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label
                    htmlFor="contact-email"
                    className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700"
                  >
                    Email
                  </label>
                  <input
                    id="contact-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@domain.com"
                    className="mt-2 min-h-[46px] w-full border border-neutral-300 bg-[#FAF9F6] px-4 py-2.5 text-sm text-[#111113] focus:border-[#8D6B20] focus:bg-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="mt-6">
                <label
                  htmlFor="contact-subject"
                  className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700"
                >
                  Subject
                </label>
                <input
                  id="contact-subject"
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Editorial, Press Loan, Advertising, or Privacy Inquiry"
                  className="mt-2 min-h-[46px] w-full border border-neutral-300 bg-[#FAF9F6] px-4 py-2.5 text-sm text-[#111113] focus:border-[#8D6B20] focus:bg-white focus:outline-none"
                />
              </div>

              <div className="mt-6">
                <label
                  htmlFor="contact-message"
                  className="block text-xs font-semibold uppercase tracking-[0.14em] text-neutral-700"
                >
                  Message
                </label>
                <textarea
                  id="contact-message"
                  required
                  rows={6}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Write your message here..."
                  className="mt-2 w-full border border-neutral-300 bg-[#FAF9F6] px-4 py-3 text-sm text-[#111113] focus:border-[#8D6B20] focus:bg-white focus:outline-none"
                />
              </div>

              {error && (
                <div
                  role="alert"
                  className="mt-6 border border-red-300 bg-red-50 px-4 py-3 text-xs text-red-800"
                >
                  {error}
                </div>
              )}

              {success && (
                <div
                  role="status"
                  className="mt-6 flex items-start gap-2.5 border border-[#C9A24D] bg-[#F3F0E9] px-4 py-3 text-xs text-[#0A0A0C]"
                >
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#8D6B20]" />
                  <span>{success}</span>
                </div>
              )}

              <div className="mt-8">
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex min-h-[48px] items-center gap-2.5 bg-[#0A0A0C] px-8 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#E2C779] transition-colors hover:bg-[#1E1E24] disabled:opacity-60"
                >
                  <Send className="h-4 w-4" />
                  {submitting ? 'Submitting...' : 'Submit Message'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <NewsletterSection
        onNavigate={onNavigate}
        emailServiceConfigured={emailServiceConfigured}
        dark
      />
    </div>
  );
}
