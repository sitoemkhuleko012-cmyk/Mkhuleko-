import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import type {
  AdPlacements,
  Article,
  ArticleCategory,
  ComparisonVehicle,
  ContactMessageRecord,
  SiteSettings,
  SubscriberRecord,
  VehicleSpecs,
} from '../shared/types.ts';

const dataDir = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'apex_auto.sqlite');
export const db = new DatabaseSync(dbPath);

db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

db.exec(`
  CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    manufacturer TEXT NOT NULL DEFAULT '',
    author TEXT NOT NULL DEFAULT 'Sitoe Mkhuleko',
    published_at TEXT NOT NULL,
    featured_image TEXT NOT NULL,
    image_caption TEXT NOT NULL DEFAULT '',
    content TEXT NOT NULL,
    is_featured INTEGER NOT NULL DEFAULT 0,
    is_trending INTEGER NOT NULL DEFAULT 0,
    read_time TEXT NOT NULL DEFAULT '6 min read',
    specs_json TEXT NOT NULL DEFAULT '{}',
    pros_json TEXT NOT NULL DEFAULT '[]',
    cons_json TEXT NOT NULL DEFAULT '[]',
    verdict TEXT NOT NULL DEFAULT '',
    rating REAL NOT NULL DEFAULT 0,
    comparison_json TEXT NOT NULL DEFAULT '[]',
    seo_title TEXT NOT NULL DEFAULT '',
    seo_description TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS site_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    consent_given INTEGER NOT NULL DEFAULT 1,
    unsubscribe_token TEXT UNIQUE NOT NULL,
    subscribed_at TEXT NOT NULL,
    unsubscribed_at TEXT
  );

  CREATE TABLE IF NOT EXISTS contact_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'unread',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS admin_credentials (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS admin_sessions (
    token TEXT PRIMARY KEY,
    expires_at INTEGER NOT NULL
  );
`);

const DEFAULT_AD_PLACEMENTS: AdPlacements = {
  headerBannerEnabled: true,
  inArticleEnabled: true,
  sidebarEnabled: true,
  footerBannerEnabled: true,
};

const DEFAULT_ABOUT_CONTENT = `APEX AUTO is an independent international automotive magazine dedicated to the pinnacle of automotive engineering, coachbuilding, and contemporary grand touring. Founded and published by Sitoe Mkhuleko, the publication examines the machines, designers, and technological breakthroughs shaping the highest tier of global mobility.

From naturally aspirated V12 hypercars and track-bred mid-engine supercars to whisper-quiet bespoke luxury saloons and next-generation electric grand tourers, every feature on APEX AUTO is written with technical precision and editorial restraint. Our coverage spans first-drive road tests, rigorous multi-vehicle specification comparisons, powertrain analysis, and authoritative automotive industry reporting.

Rather than chasing fleeting hype, APEX AUTO approaches every vehicle as a work of mechanical sculpture and purposeful engineering—evaluating chassis balance, material craft, aerodynamic efficiency, and real-world composure across alpine passes, proving grounds, and continental highways.`;

const DEFAULT_PUBLISHER_BIO = `Sitoe Mkhuleko is the Founder and Publisher of APEX AUTO. Dedicated to chronicling the intersection of high-output powertrain engineering and artisanal luxury coachbuilding, his editorial direction emphasizes technical clarity, disciplined design journalism, and long-form automotive storytelling.`;

const DEFAULT_PRIVACY_POLICY = `1. Introduction and Scope
APEX AUTO ("we", "our", or "the Publication"), published by Sitoe Mkhuleko, respects the privacy of every reader and visitor. This Privacy Policy explains what personal information we collect, how we use and protect it, how cookies and advertising technologies operate on this website, and the rights available to you regarding your information.

2. Personal Information We Collect
We collect only the personal information you voluntarily provide and limited technical information necessary for website operation and security:
- Contact Inquiries: When you submit a message through our Contact Us page, we collect your name, email address, subject line, and message content in order to respond to your inquiry.
- Newsletter Subscriptions: When you subscribe to the APEX AUTO editorial newsletter, we collect your email address and record your explicit consent timestamp and subscription status.
- Technical & Security Logs: Our web server processes standard request metadata (such as requested URLs, browser user-agent strings, and timestamps) to maintain uptime, prevent abuse, and serve pages reliably.

3. How Email Addresses Are Collected and Used
Email addresses submitted via our newsletter form are used exclusively to deliver APEX AUTO automotive updates, feature stories, comparisons, and publication announcements. Email addresses submitted via the Contact Us form are used solely to respond to your inquiry. We never sell, rent, trade, or publicly expose subscriber or reader email addresses. Every editorial newsletter message includes a direct, working unsubscribe link so you may opt out at any time.

4. How Cookies Are Used
Cookies are small text files stored in your browser to remember preferences and support essential site functionality. Essential cookies store your privacy consent selection so the website remembers whether you accepted or declined optional cookies. Optional analytics and advertising cookies are never activated until you provide explicit consent through our Cookie Consent banner or Cookie Settings control.

5. How Analytics Data Is Collected
If you choose to enable Analytics cookies, APEX AUTO may collect aggregated, non-identifying readership metrics—such as page views, article reading patterns, device viewport dimensions, and referral sources—to understand which automotive categories and reviews serve our international audience best.

6. Google AdSense Advertising and Third-Party Providers
APEX AUTO prepares its advertising placements in accordance with Google AdSense publisher policies. When Advertising cookies are enabled by your consent and Google AdSense is active on the publication, third-party vendors, including Google, may use cookies and similar technologies to serve advertisements based on a visitor's prior visits to this website or other websites on the Internet.
Google's use of advertising cookies enables it and its partners to serve ads to visitors based on their visit to APEX AUTO and/or other sites on the Internet. You may opt out of personalized advertising by visiting Google Ads Settings (https://adssettings.google.com) or by visiting www.aboutads.info/choices, or by declining Advertising cookies at any time via the Cookie Settings link in our footer.

7. Managing Your Privacy Preferences
You remain in full control of your cookie and communication preferences:
- Use the permanent "Cookie Settings" link in the APEX AUTO footer at any time to enable or disable Analytics and Advertising cookies.
- Adjust your browser settings to block or clear cookies stored on your device.
- Use the unsubscribe link included in newsletter communications—or visit our Unsubscribe page—to withdraw newsletter consent immediately.

8. Data Protection and Retention
We implement industry-standard administrative and technical safeguards—including encrypted HTTPS transport in production, parameterized database queries, strict server-side access controls for editorial administration, and restricted database access—to protect personal data against unauthorized access or disclosure.
- Newsletter subscriber records are retained only while your subscription remains active or as required to honor an unsubscribe request.
- Contact form inquiries are retained only as long as necessary to address your correspondence and maintain editorial records.

9. Your Rights (Access, Correction, and Deletion)
Where applicable under data protection laws (including GDPR, UK GDPR, POPIA, and CCPA/CPRA), you may request access to the personal information we hold about you, request correction of inaccurate information, withdraw consent, or request permanent deletion of your email address and inquiry records.

10. Contact Us About Privacy Concerns
If you have questions regarding this Privacy Policy or wish to submit a data access, correction, or deletion request, please reach out directly through our Contact Us page and select "Privacy Inquiry" as your subject.`;

const DEFAULT_COOKIE_POLICY = `1. What Are Cookies?
Cookies are small data files placed on your computer, tablet, or smartphone when you browse websites. They allow a publication to remember your privacy choices, maintain secure sessions, measure editorial readership, and support advertising where consented.

2. Cookie Categories Used by APEX AUTO

Essential Cookies (Always Active)
Purpose: Required for core website operation, security integrity, and remembering your explicit cookie consent preferences ("apex_cookie_consent"). Because the website cannot remember your privacy choices or operate securely without these mechanisms, Essential cookies remain active and do not collect marketing profiles.

Analytics Cookies (Optional — Requires Consent)
Purpose: Help our editorial team understand how visitors navigate between Supercars, Luxury Cars, Comparisons, and Car Reviews, which stories resonate most, and how our pages perform across desktop, tablet, and mobile viewports. Analytics cookies remain inactive unless you explicitly opt in.

Advertising Cookies (Optional — Requires Consent)
Purpose: Support publication sustainability through advertising partners such as Google AdSense. When consented, advertising cookies help deliver relevant advertisements, measure campaign performance, and limit repetitive ad impressions. Advertising cookies remain disabled until you explicitly grant permission.

3. Consent Management and Withdrawal
When you visit APEX AUTO for the first time, our privacy banner invites you to Accept All Cookies, Reject Optional Cookies, or Customize My Preferences. Reading APEX AUTO never requires accepting optional cookies. You may update or withdraw your consent at any time by clicking "Cookie Settings" in the website footer.

4. Browser-Level Cookie Controls
Most modern browsers allow you to view, manage, delete, or block cookies through their privacy settings. Please note that clearing browser storage will reset your saved preferences and cause the consent dialog to reappear on your next visit so you can reconfirm your choices.`;

const DEFAULT_TERMS_CONTENT = `1. Editorial Content and Intellectual Property
All articles, photography, specification tables, comparison analyses, and brand assets published on APEX AUTO are protected by international copyright law. Unless otherwise stated, editorial materials are published by Sitoe Mkhuleko for APEX AUTO. Reproduction, republication, or commercial redistribution without prior written permission is prohibited.

2. Editorial Accuracy and Vehicle Specifications
APEX AUTO strives to present accurate manufacturer performance figures, curb weights, pricing estimates, and road-test observations at the time of publication. Automotive specifications, regional equipment availability, and manufacturer pricing are subject to change without notice.

3. External Links and Third-Party Services
Articles and navigation elements may link to official manufacturer portals, social media channels, or third-party advertising networks. APEX AUTO is not responsible for the content or privacy practices of external websites.

4. Acceptable Use
Visitors agree not to attempt unauthorized access to administrative endpoints, scrape subscriber data, or disrupt server availability.`;

const DEFAULT_SETTINGS: SiteSettings = {
  publisherName: 'Sitoe Mkhuleko',
  publisherBio: DEFAULT_PUBLISHER_BIO,
  publisherPhoto: '/assets/aistudio/IMG_20250922_202212_153_748d0b24.jpg',
  aboutContent: DEFAULT_ABOUT_CONTENT,
  privacyPolicy: DEFAULT_PRIVACY_POLICY,
  cookiePolicy: DEFAULT_COOKIE_POLICY,
  termsContent: DEFAULT_TERMS_CONTENT,
  instagramUrl: 'https://www.instagram.com/sitoemkhule',
  facebookUrl: 'https://www.facebook.com/sitoemkhule',
  seoSiteTitle: 'APEX AUTO — The World of Performance & Luxury',
  seoSiteDescription:
    'International automotive magazine published by Sitoe Mkhuleko. Featuring supercars, bespoke luxury vehicles, road tests, specifications comparisons, and industry updates.',
  googleSiteVerification: '',
  adsensePublisherId: '',
  adPlacements: DEFAULT_AD_PLACEMENTS,
};

function seedDefaults() {
  const upsertSetting = db.prepare(
    'INSERT OR IGNORE INTO site_settings (key, value) VALUES (?, ?)'
  );

  const settingsEntries: Array<[string, string]> = [
    ['publisher_name', DEFAULT_SETTINGS.publisherName],
    ['publisher_bio', DEFAULT_SETTINGS.publisherBio],
    ['publisher_photo', DEFAULT_SETTINGS.publisherPhoto],
    ['about_content', DEFAULT_SETTINGS.aboutContent],
    ['privacy_policy', DEFAULT_SETTINGS.privacyPolicy],
    ['cookie_policy', DEFAULT_SETTINGS.cookiePolicy],
    ['terms_content', DEFAULT_SETTINGS.termsContent],
    ['instagram_url', DEFAULT_SETTINGS.instagramUrl],
    ['facebook_url', DEFAULT_SETTINGS.facebookUrl],
    ['seo_site_title', DEFAULT_SETTINGS.seoSiteTitle],
    ['seo_site_description', DEFAULT_SETTINGS.seoSiteDescription],
    ['google_site_verification', DEFAULT_SETTINGS.googleSiteVerification],
    ['adsense_publisher_id', DEFAULT_SETTINGS.adsensePublisherId],
    ['ad_placements_json', JSON.stringify(DEFAULT_SETTINGS.adPlacements)],
  ];

  for (const [k, v] of settingsEntries) {
    upsertSetting.run(k, v);
  }

  // Ensure empty social URLs and publisher photo created during initial seed are populated
  db.prepare(
    "UPDATE site_settings SET value = ? WHERE key = 'instagram_url' AND value = ''"
  ).run(DEFAULT_SETTINGS.instagramUrl);
  db.prepare(
    "UPDATE site_settings SET value = ? WHERE key = 'facebook_url' AND value = ''"
  ).run(DEFAULT_SETTINGS.facebookUrl);
  db.prepare(
    "UPDATE site_settings SET value = ? WHERE key = 'publisher_photo' AND value = ''"
  ).run(DEFAULT_SETTINGS.publisherPhoto);

  const now = new Date().toISOString();
  const insertArticle = db.prepare(`
    INSERT OR IGNORE INTO articles (
      slug, title, description, category, manufacturer, author, published_at,
      featured_image, image_caption, content, is_featured, is_trending, read_time,
      specs_json, pros_json, cons_json, verdict, rating, comparison_json,
      seo_title, seo_description, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const seedArticles: Array<{
    slug: string;
    title: string;
    description: string;
    category: ArticleCategory;
    manufacturer: string;
    publishedAt: string;
    featuredImage: string;
    imageCaption: string;
    isFeatured: number;
    isTrending: number;
    readTime: string;
    specs: VehicleSpecs;
    pros: string[];
    cons: string[];
    verdict: string;
    rating: number;
    comparisonVehicles: ComparisonVehicle[];
    content: string;
  }> = [
    {
      slug: 'pagani-utopia-carbon-v12-anatomy-of-mechanical-purity',
      title: 'The Carbon-Weave Symphony: Inside Modern V12 Hypercar Architecture',
      description:
        'Why bespoke titanium fasteners, analog telemetry, and twin-turbocharged twelve-cylinder engineering continue to define the upper echelon of hypercar collecting.',
      category: 'Supercars',
      manufacturer: 'Pagani',
      publishedAt: '2026-11-18',
      featuredImage: '/src/assets/images/hero_hypercar_showcase_1795508612490.jpg',
      imageCaption: 'Fig. 1 — Exposed carbo-titanium weave catching late dusk light over dark architectural slate.',
      isFeatured: 1,
      isTrending: 1,
      readTime: '7 min read',
      specs: {
        engine: '6.0L Twin-Turbocharged V12',
        horsepower: '852 hp @ 6,000 rpm',
        torque: '811 lb-ft @ 2,800 rpm',
        zeroToSixty: '2.8 sec',
        topSpeed: '217 mph (350 km/h)',
        transmission: '7-Speed Gated Manual / Xtrac AMT',
        drivetrain: 'Rear-Wheel Drive',
        curbWeight: '2,822 lb (1,280 kg)',
        price: '$2,500,000',
      },
      pros: [
        'Carbo-titanium monocoque delivers extraordinary torsional rigidity at 1,280 kg dry',
        'Available true gated seven-speed manual transmission in an era of dual-clutch ubiquity',
        'Zero oversized touchscreens; timeless machined aluminum instrumentation',
      ],
      cons: [
        'Strictly limited production allocation sold out prior to public unveiling',
        'Minimal luggage volume suited strictly to weekend bespoke luggage sets',
      ],
      verdict:
        'A masterclass in tactile engineering that prioritizes mechanical intimacy and weight reduction over lap-time theatrics.',
      rating: 9.7,
      comparisonVehicles: [],
      content: `In an automotive landscape increasingly governed by multi-motor battery packs and software-defined torque vectoring, the modern boutique V12 hypercar stands as an intentional rebellion. Parked against rain-darkened basalt and brushed concrete, its silhouette rejects gratuitous wings in favor of active, near-invisible underbody aerodynamics.

At the structural heart of this philosophy lies a monocoque woven from Carbo-Titanium HP62 G2 and Carbo-Triax HP62—composite laminates originally conceived for aerospace structures where every gram carries an acoustic and dynamic consequence. Keeping dry mass below 1,300 kilograms fundamentally alters how springs, forged double-wishbone suspension arms, and carbon-ceramic rotors behave over undulating tarmac.

Step inside and the deliberate rejection of disposable electronics is unmistakable. Instead of sprawling glass panels destined to look dated within five years, every switch, column stalk, and climate dial is CNC-milled from solid blocks of aerospace-grade aluminum. The instrument cluster pairs Swiss watchmaking tolerances with crisp mechanical needles that sweep cleanly to redline.

Out on an open mountain ribbon, the twin-turbocharged twelve-cylinder engine builds velocity with an effortless, linear tide of torque rather than sudden boost spikes. Paired with an open-gate seven-speed manual gearbox, each shift becomes a deliberate physical dialogue between driver, linkage, and flywheel—proving that ultimate performance is still measured by sensation as much as velocity.`,
    },
    {
      slug: 'ferrari-alpine-ascension-mid-engine-v8-dynamics',
      title: 'Alpine Ascension: Mastering the Mid-Engine V8 on High-Altitude Hairpins',
      description:
        'At 2,400 meters above sea level, Ferrari’s sculpted mid-engine berlinetta demonstrates why aerodynamic balance outweighs brute horsepower on real mountain roads.',
      category: 'Supercars',
      manufacturer: 'Ferrari',
      publishedAt: '2026-11-14',
      featuredImage: '/src/assets/images/supercar_track_action_1795508612145.jpg',
      imageCaption: 'Fig. 2 — Climbing into thin alpine air where chassis feedback and brake modulation govern every apex.',
      isFeatured: 1,
      isTrending: 0,
      readTime: '6 min read',
      specs: {
        engine: '3.9L Twin-Turbo Flat-Plane V8',
        horsepower: '710 hp @ 8,000 rpm',
        torque: '568 lb-ft @ 3,000 rpm',
        zeroToSixty: '2.7 sec',
        topSpeed: '211 mph (340 km/h)',
        transmission: '7-Speed F1 Dual-Clutch',
        drivetrain: 'Rear-Wheel Drive',
        curbWeight: '3,054 lb (1,385 kg)',
        price: '$345,000',
      },
      pros: [
        'Telepathic steering ratio and instantaneous front-axle bite',
        'S-Duct front aerodynamics generate meaningful downforce without drag penalties',
        'Flat-plane V8 surges eagerly all the way to 8,000 rpm',
      ],
      cons: [
        'Firm track-biased damper calibration demands smoothness on broken secondary roads',
        'Carbon bucket seats offer limited lumbar adjustment on multi-hour transits',
      ],
      verdict:
        'Arguably the purest expression of modern Maranello chassis dynamics—razor-sharp yet remarkably approachable at eight-tenths.',
      rating: 9.5,
      comparisonVehicles: [],
      content: `Dawn arrives slowly across the high passes of the Dolomites, turning wet granite to slate before the sun clears the ridge. This is unforgiving terrain for an ill-balanced supercar: cold tires, off-camber hairpins, and steep elevation changes expose every flaw in suspension geometry and throttle calibration.

Yet from the first third-gear sweep, the mid-engine Italian berlinetta shrinks around its driver. Maranello’s front S-Duct channels high-pressure airflow from the lower splitter smoothly across the hood, anchoring the nose into fast third-gear corners with startling certainty. Where older mid-engine exotics demanded caution on lift-off, Side Slip Control software works imperceptibly alongside magnetorheological dampers to preserve poise without dulling steering feel.

The flat-plane-crank V8 remains a marvel of turbocharged responsiveness. Variable Torque Management shapes boost curves in lower gears so traction remains cohesive even over damp tarmac, while higher ratios unleash an uninterrupted metallic crescendo up to 8,000 rpm.

More impressive still is brake modulation. Carbon-ceramic discs paired with high-pressure hydraulic calibration allow millimeter-accurate trail braking right down to the painted apex, turning every switchback into an exercise in precision rather than survival.`,
    },
    {
      slug: 'rolls-royce-bentley-bespoke-coachbuilding-sovereign-grand-tourer',
      title: 'Quiet Authority: Inside the Renaissance of Bespoke British Luxury Saloons',
      description:
        'Hand-rubbed twelve-layer lacquer, lambswool carpets, and acoustic glass isolation define the new benchmark for effortless transcontinental travel.',
      category: 'Luxury Cars',
      manufacturer: 'Rolls-Royce',
      publishedAt: '2026-11-11',
      featuredImage: '/src/assets/images/rolls_royce_phantom_1795511361017.jpg',
      imageCaption: 'Fig. 3 — Two-tone Rolls-Royce Phantom with stainless-steel Pantheon grille and Spirit of Ecstasy on a private manor driveway.',
      isFeatured: 1,
      isTrending: 1,
      readTime: '8 min read',
      specs: {
        engine: '6.75L Twin-Turbocharged V12',
        horsepower: '563 hp @ 5,000 rpm',
        torque: '664 lb-ft @ 1,600 rpm',
        zeroToSixty: '4.4 sec',
        topSpeed: '155 mph (Electronically Limited)',
        transmission: '8-Speed Satellite-Aided Automatic',
        drivetrain: 'All-Wheel Drive',
        curbWeight: '5,644 lb (2,560 kg)',
        price: '$485,000',
      },
      pros: [
        'Extraordinary cabin silence verified across coarse motorway surfaces',
        'Satellite-aided transmission pre-selects gears before corners and gradients',
        'Unrivaled bespoke material curation across veneers, leather, and embroidery',
      ],
      cons: [
        'Substantial 2.5-ton footprint requires deliberate placement in historic European town centers',
        'Bespoke commissioning options quickly elevate final invoice prices beyond $600,000',
      ],
      verdict:
        'True automotive luxury is measured not by ambient LED gimmicks, but by complete serenity at 120 mph.',
      rating: 9.6,
      comparisonVehicles: [],
      content: `Walk across gravel toward a full-size British luxury saloon at golden hour and the first sensation is architectural proportion. Long bonnet, sweeping roofline, and upright stainless-steel brightwork communicate permanence before a single door handle is lifted.

Open the coach-hinged door and the external world vanishes. More than one hundred kilograms of acoustic insulation, double-glazed laminated glass, and foam-filled tire cavities filter out wind shear and road roar, creating an interior hush closer to a private study than a motor vehicle.

Rather than chasing stiff sporting pretensions, the Planar suspension system utilizes camera-guided road scanning to soften damper rates milliseconds before the front axle encounters expansion joints or cobblestones. Meanwhile, the satellite-aided eight-speed transmission reads upcoming topography via GPS so downshifts never interrupt passenger conversation.

Inside, natural-grain bull hides—sourced exclusively from high-altitude herds free of barbed-wire scarring—are paired with open-pore walnut veneers matched sequentially from a single tree. Every organ-stop air vent and knurled rotary control operates with weighted mechanical resistance, reminding occupants that genuine luxury is built to endure decades.`,
    },
    {
      slug: 'mclaren-750s-vs-lamborghini-revuelto-flagship-comparison',
      title: 'McLaren vs Lamborghini: Twin-Turbo Carbon Agility Meets Naturally Aspirated V12 Hybrid Fury',
      description:
        'A comprehensive track and road comparison pitting lightweight Woking carbon-tub precision against Sant’Agata’s 1,001-horsepower V12 plug-in hybrid flagship.',
      category: 'Comparisons',
      manufacturer: 'McLaren',
      publishedAt: '2026-11-08',
      featuredImage: '/src/assets/images/gt_comparison_duo_1795508613436.jpg',
      imageCaption: 'Fig. 4 — Two diametrically opposed philosophies of flagship velocity on coastal tarmac at dawn.',
      isFeatured: 1,
      isTrending: 1,
      readTime: '9 min read',
      specs: {
        engine: '4.0L Twin-Turbo V8 vs 6.5L NA V12 + 3 E-Motors',
        horsepower: '740 hp vs 1,001 hp',
        torque: '590 lb-ft vs 783 lb-ft',
        zeroToSixty: '2.7 sec vs 2.5 sec',
        topSpeed: '206 mph vs 217 mph',
        price: '$324,000 vs $608,000',
      },
      pros: [
        'Woking chassis remains nearly 500 kg lighter with unmatched electro-hydraulic steering feel',
        'Sant’Agata V12 hybrid delivers theatrical 9,500 rpm acoustics and ferocious all-wheel traction',
      ],
      cons: [
        'Hybrid complexity significantly increases curb weight under heavy threshold braking',
        'Twin-turbo V8 acoustic character remains muted next to a twelve-cylinder screaming past 9,000 rpm',
      ],
      verdict:
        'Choose McLaren for pure, featherweight steering fidelity; choose Lamborghini for unmistakable V12 drama and hybrid thrust.',
      rating: 9.4,
      comparisonVehicles: [
        {
          name: 'McLaren 750S Coupe',
          manufacturer: 'McLaren',
          engine: '4.0L Twin-Turbocharged V8',
          horsepower: '740 hp',
          torque: '590 lb-ft',
          zeroToSixty: '2.7 sec',
          topSpeed: '206 mph (332 km/h)',
          weight: '3,062 lb (1,389 kg)',
          price: '$324,000',
          drivetrain: 'Rear-Wheel Drive',
        },
        {
          name: 'Lamborghini Revuelto',
          manufacturer: 'Lamborghini',
          engine: '6.5L NA V12 + Tri-Motor Hybrid',
          horsepower: '1,001 hp',
          torque: '783 lb-ft (Combined)',
          zeroToSixty: '2.5 sec',
          topSpeed: '217 mph (350 km/h)',
          weight: '3,907 lb (1,772 kg)',
          price: '$608,358',
          drivetrain: 'All-Wheel Drive (e-AWD)',
        },
      ],
      content: `Few rivalries in modern supercar history illustrate a philosophical fork in the road as clearly as Woking’s lightweight twin-turbo V8 champion meeting Sant’Agata’s thousand-horsepower electrified V12 flagship. Parked side by side on a windswept coastal runway, the contrast is immediate: fluid, wind-tunnel-carved efficiency opposite razor-edged Italian aggression.

On paper, Lamborghini’s 1,001-horsepower hybrid powertrain commands the headline figures. Three axial-flux electric motors—two driving the front axle independently for active torque vectoring, one integrated into the new eight-speed transverse dual-clutch transmission—fill every torque valley below 4,000 rpm. Then the 6.5-liter naturally aspirated V12 takes command, howling cleanly to an extraordinary 9,500 rpm cutoff.

Yet numbers alone never win a driver’s heart. Step into the McLaren and you are immediately struck by low cowl visibility, slender A-pillars, and an electro-hydraulic steering rack that communicates every pebble and camber change through your fingertips. Weighing nearly 400 kilograms less than its Italian rival, the rear-drive coupe changes direction with effortless, dart-like immediacy and stops from 150 mph with noticeably less thermal load on its rotors.

Ultimately, both machines justify their status at the summit of the segment. Lamborghini has engineered the most theatrical hybrid supercar on earth—one that preserves the twelve-cylinder soul while leaping from 0–60 mph in 2.5 seconds. McLaren proves that subtracting mass remains the purest performance upgrade money can buy.`,
    },
    {
      slug: 'aston-martin-bespoke-cockpit-craftsmanship-review',
      title: 'Tactile Renaissance: Road Testing the New British V12 Grand Tourer Interior & Chassis',
      description:
        'A detailed review evaluating cockpit ergonomics, brushed gold switchgear, forged carbon craftsmanship, and continental grand touring composure.',
      category: 'Car Reviews',
      manufacturer: 'Aston Martin',
      publishedAt: '2026-11-05',
      featuredImage: '/src/assets/images/cockpit_bespoke_interior_1795508613019.jpg',
      imageCaption: 'Fig. 5 — Hand-quilted obsidian hide paired with knurled champagne-gold metal controls.',
      isFeatured: 0,
      isTrending: 1,
      readTime: '7 min read',
      specs: {
        engine: '5.2L Twin-Turbocharged V12',
        horsepower: '824 hp @ 6,500 rpm',
        torque: '738 lb-ft @ 2,500 rpm',
        zeroToSixty: '3.2 sec',
        topSpeed: '214 mph (344 km/h)',
        transmission: '8-Speed Rear-Mounted Automatic',
        drivetrain: 'Rear-Wheel Drive',
        curbWeight: '3,910 lb (1,774 kg)',
        price: '$435,000',
      },
      pros: [
        'Physical rotary dials and toggle switches restore eyes-on-the-road ergonomics',
        'Front-mid V12 layout balances long-distance compliance with genuine rear-drive poise',
        'Bespoke quilted hides and forged carbon inlays feel genuinely bespoke',
      ],
      cons: [
        'Rear luggage shelf handles soft duffels better than rigid cabin cases',
        'High-speed wind rustle around frameless mirrors above 130 mph',
      ],
      verdict:
        'By returning tactile metal controls to the center console while unleashing 824 horsepower, British grand touring reclaims its golden era.',
      rating: 9.3,
      comparisonVehicles: [],
      content: `For nearly a decade, luxury carmakers mistook capacitive black glass for progress—burying climate adjustments, drive modes, and chassis settings inside multi-layered submenus. Our latest 900-mile continental test proves how transformative it is when a manufacturer restores physical craft to the cabin.

Seated low behind a sculpted Alcantara rim, your fingertips fall naturally onto solid-milled champagne-gold rotaries and knurled drive-mode dials. Each click carries calibrated mechanical detent, allowing damper stiffness or exhaust valve mapping to be adjusted without once glancing away from the horizon. Surrounding the center spine, forged carbon composite flakes catch natural daylight against deep diamond-quilted obsidian leather.

On the road, the 5.2-liter twin-turbocharged V12 settles into an almost effortless murmur at 80 mph, turning barely 1,800 rpm in eighth gear. Yet squeeze the throttle past halfway and the rear-mounted transaxle drops three ratios smoothly, summoning 738 lb-ft of torque with authoritative, traction-rich surge.

Electronic Bilstein DTX dampers span an impressive bandwidth between GT suppleness over cobbled village squares and crisp body control across sweeping A-roads. For drivers seeking a genuine cross-continental express that rewards both mechanical engagement and bespoke craftsmanship, few interiors—or powertrains—equal this standard.`,
    },
    {
      slug: 'pininfarina-rimac-electric-hyper-gt-design-evolution',
      title: 'Silent Velocity: How Electric Hyper-GTs Are Redefining Aerodynamic Sculpture',
      description:
        'Without radiator grilles or exhaust routing constraints, flagship electric grand tourers unlock radical airflow channels and 1,900-horsepower quad-motor precision.',
      category: 'Latest Updates',
      manufacturer: 'Pininfarina',
      publishedAt: '2026-11-02',
      featuredImage: '/src/assets/images/electric_hyper_gt_1795508613763.jpg',
      imageCaption: 'Fig. 6 — Pure uninterrupted surfacing inside a concrete design studio reveals zero-drag proportions.',
      isFeatured: 0,
      isTrending: 1,
      readTime: '5 min read',
      specs: {
        engine: 'Quad Permanent-Magnet Electric Motors',
        horsepower: '1,900 hp',
        torque: '1,740 lb-ft',
        zeroToSixty: '1.8 sec',
        topSpeed: '217 mph (350 km/h)',
        transmission: 'Four Independent Single-Speed Gearboxes',
        drivetrain: 'All-Wheel Drive (Individual Wheel Vectoring)',
        curbWeight: '4,850 lb (2,200 kg)',
        price: '$2,200,000',
      },
      pros: [
        'Instantaneous per-wheel torque vectoring adjusts grip 100 times per second',
        'Uncluttered body sculpture free of oversized cooling apertures',
      ],
      cons: [
        '2.2-ton battery mass limits sustained multi-lap track endurance compared to lighter ICE peers',
        'Requires high-output 350 kW DC infrastructure for rapid touring top-ups',
      ],
      verdict:
        'Electric hyper-GTs do not replace internal combustion emotion—they establish an entirely new discipline of silent aerodynamic velocity.',
      rating: 9.1,
      comparisonVehicles: [],
      content: `Walk into a dimly lit concrete design studio and study a modern electric hyper-GT in profile, and the absence of conventional mechanical packaging rules becomes immediately clear. Freed from towering front radiator cores and bulky longitudinal transmissions, coachbuilders can drop the hood line dramatically and sculpt continuous airflow tunnels directly through the front fenders.

Beneath the liquid-silver carbon bodywork sits a 120 kWh T-shaped structural battery pack feeding four independent electric motors—one at each wheel. That architecture eliminates mechanical differentials altogether, allowing software to apply positive drive torque to an outer wheel while simultaneously regenerating braking energy on an inner wheel mid-corner.

Industry executives confirmed this week that next-generation solid-state chemistry prototypes are already trimming pack weight by 22 percent while doubling thermal stability under repeated high-speed accelerations. As charging networks mature along major European and North American touring corridors, ultra-luxury electric grand touring is rapidly shifting from technological showcase to viable continental transport.`,
    },
    {
      slug: 'koenigsegg-jesko-absolut-high-speed-aerodynamics-analysis',
      title: 'Koenigsegg Jesko Attack & Absolut: Swan-Neck Downforce Meets 300+ MPH Aerodynamics',
      description:
        'A technical briefing on the track-focused Koenigsegg Jesko Attack and low-drag Absolut—examining 1,600 horsepower and the nine-speed Light Speed Transmission.',
      category: 'Supercars',
      manufacturer: 'Koenigsegg',
      publishedAt: '2026-10-28',
      featuredImage: '/src/assets/images/koenigsegg_jesko_attack_1795511035843.jpg',
      imageCaption: 'Fig. 7 — Koenigsegg Jesko Attack in Spa-Francorchamps pit lane showcasing its active boomerang rear wing and front dive planes.',
      isFeatured: 0,
      isTrending: 1,
      readTime: '6 min read',
      specs: {
        engine: '5.0L Twin-Turbo V8 (E85)',
        horsepower: '1,600 hp @ 8,500 rpm',
        torque: '1,106 lb-ft @ 5,100 rpm',
        zeroToSixty: '2.5 sec',
        topSpeed: '310+ mph (Absolut) / Track Aero (Attack)',
        transmission: '9-Speed Light Speed Transmission',
        drivetrain: 'Rear-Wheel Drive',
        curbWeight: '3,064 lb (1,390 kg)',
        price: '$3,400,000',
      },
      pros: [
        'Multi-clutch 9-speed transmission shifts directly between non-adjacent gears in milliseconds',
        'Jesko Attack generates up to 1,400 kg of peak aerodynamic downforce for circuit supremacy',
      ],
      cons: [
        'Ultra-long gearing and extreme track aero demand closed circuits or runways to explore fully',
      ],
      verdict:
        'Swedish engineering pushed to theoretical aerodynamic limits—whether sculpted for maximum track downforce in Attack guise or laminar top speed as the Absolut.',
      rating: 9.8,
      comparisonVehicles: [],
      content: `Breaking past 250 miles per hour is rarely an engine problem alone; aerodynamic drag rises with the square of velocity, while power required to overcome it climbs with the cube. From Ängelholm, Koenigsegg engineered two distinct aerodynamic interpretations of the same 1,600-horsepower platform: the high-downforce Jesko Attack and the low-drag Jesko Absolut.

In Jesko Attack specification, a towering top-mounted carbon-fiber boomerang rear wing, deep front splitter, and aggressive fender louvers generate up to 1,400 kilograms of peak downforce—gluing the car to fast circuit sweepers at Spa-Francorchamps and Laguna Seca. Meanwhile, the Absolut strips away the rear wing in favor of twin vertical stabilizer fins inspired by supersonic fighter jets, lowering drag to 0.278 Cd.

Equally revolutionary is the nine-speed Light Speed Transmission, which weighs just 90 kilograms with fluids included and utilizes seven wet multi-disc clutches to jump instantaneously from seventh gear straight to fourth without stepping sequentially through intermediate ratios.`,
    },
    {
      slug: 'porsche-911-gt3-vs-mercedes-amg-gt63-pro-comparison',
      title: 'Precision vs Muscle: Porsche 911 GT3 RS vs Mercedes-AMG GT 63 PRO Compared',
      description:
        'Comparing naturally aspirated 9,000-rpm German track focus against handcrafted twin-turbo V8 grand touring versatility.',
      category: 'Comparisons',
      manufacturer: 'Porsche',
      publishedAt: '2026-10-22',
      featuredImage: '/src/assets/images/porsche_911_gt3_rs_1795511037234.jpg',
      imageCaption: 'Fig. 8 — Weissach-equipped Porsche 911 GT3 RS carving through high-altitude alpine switchbacks.',
      isFeatured: 0,
      isTrending: 0,
      readTime: '8 min read',
      specs: {
        engine: '4.0L Flat-6 vs 4.0L Twin-Turbo V8',
        horsepower: '518 hp vs 603 hp',
        torque: '342 lb-ft vs 627 lb-ft',
        zeroToSixty: '3.0 sec vs 3.1 sec',
        topSpeed: '184 mph vs 197 mph',
        price: '$241,300 vs $195,900',
      },
      pros: [
        'Weissach flat-six delivers unmatched naturally aspirated throttle immediacy and DRS aerodynamics',
        'Affalterbach V8 offers vast real-world usability, cargo space, and all-weather traction',
      ],
      cons: [
        'Track-focused aero setup compromises highway ride comfort and luggage capacity',
      ],
      verdict:
        'Both wear German crests, yet serve entirely different driving rituals—one built for Sunday circuit supremacy, the other for transcontinental pace.',
      rating: 9.2,
      comparisonVehicles: [
        {
          name: 'Porsche 911 GT3 RS',
          manufacturer: 'Porsche',
          engine: '4.0L Naturally Aspirated Flat-6',
          horsepower: '518 hp',
          torque: '342 lb-ft',
          zeroToSixty: '3.0 sec',
          topSpeed: '184 mph (296 km/h)',
          weight: '3,268 lb (1,482 kg)',
          price: '$241,300',
          drivetrain: 'Rear-Wheel Drive',
        },
        {
          name: 'Mercedes-AMG GT 63 PRO',
          manufacturer: 'Mercedes-Benz',
          engine: '4.0L Handcrafted Twin-Turbo V8',
          horsepower: '603 hp',
          torque: '627 lb-ft',
          zeroToSixty: '3.1 sec',
          topSpeed: '197 mph (317 km/h)',
          weight: '4,343 lb (1,970 kg)',
          price: '$195,900',
          drivetrain: '4MATIC+ All-Wheel Drive',
        },
      ],
      content: `Place Stuttgart’s track-honed naturally aspirated icon beside Affalterbach’s thunderous front-mid V8 coupe and you witness the breadth of modern German performance engineering.

On a smooth racing circuit, the Porsche operates on an almost telepathic plane. Active front diffuser blades and a hydraulic Drag Reduction System wing generate 860 kilograms of peak downforce at 177 mph—more than double its predecessor—allowing astonishing apex speeds while the 4.0-liter flat-six sings past 9,000 rpm.

Switch seats to the Mercedes-AMG GT 63 PRO for a 400-mile cross-country journey and the appeal shifts immediately. With nearly twice the low-end torque, a spacious hatchback cargo bay, and active ride stabilization that absorbs rough tarmac, Affalterbach delivers relentless all-weather pace without demanding racing-driver compromises.`,
    },
    {
      slug: 'bentley-continental-gt-speed-hybrid-luxury-review',
      title: 'Bentley Continental GT Speed Review: Effortless V8 Hybrid Grand Touring Tested',
      description:
        'With 771 horsepower and 50 miles of silent electric range, Crewe’s flagship coupe blends whisper-quiet city poise with 208-mph autobahn authority.',
      category: 'Car Reviews',
      manufacturer: 'Bentley',
      publishedAt: '2026-10-18',
      featuredImage: '/src/assets/images/bentley_continental_gt_speed_1795511600687.jpg',
      imageCaption: 'Fig. 9 — Metallic tungsten-gray Bentley Continental GT Speed poised along a coastal mountain overlook.',
      isFeatured: 0,
      isTrending: 0,
      readTime: '7 min read',
      specs: {
        engine: '4.0L Twin-Turbo V8 + Electric Motor',
        horsepower: '771 hp',
        torque: '738 lb-ft',
        zeroToSixty: '3.1 sec',
        topSpeed: '208 mph (335 km/h)',
        transmission: '8-Speed Dual-Clutch Automatic',
        drivetrain: 'All-Wheel Drive',
        curbWeight: '5,421 lb (2,459 kg)',
        price: '$305,000',
      },
      pros: [
        'Seamless transition between pure EV city refinement and thunderous V8 pace',
        'Active 48V anti-roll bars keep body lean remarkably flat in fast sweepers',
        'Rotating dashboard display merges analog chronometers with digital navigation',
      ],
      cons: [
        'Substantial 2.4-ton curb weight felt under repeated late braking on tight circuits',
        'Rear seats remain best suited to children or tailored weekend luggage',
      ],
      verdict:
        'The definitive modern grand tourer—equally composed gliding silently through Zurich or crossing Germany at 180 mph.',
      rating: 9.4,
      comparisonVehicles: [],
      content: `Replacing Crewe’s storied W12 engine was never going to be an easy task, yet the Ultra Performance Hybrid V8 architecture achieves something arguably superior: deeper low-speed refinement paired with sharper front-end agility.

Around town, the 187-horsepower electric motor glides effortlessly up to 87 mph without waking the eight-cylinder engine, delivering near-limousine serenity. Select Sport mode on an unrestricted highway, however, and both power sources unite to deliver 771 horsepower and 738 lb-ft of instantaneous torque.

Inside, Bentley’s three-sided Rotating Display remains one of automotive design’s most satisfying flourishes—allowing drivers to rotate away the 12.3-inch navigation screen in favor of three classic analog dials or uninterrupted book-matched veneer.`,
    },
    {
      slug: 'bugatti-bmw-bespoke-atelier-trends-2026',
      title: '2026 Luxury & Performance Outlook: Why Coachbuilt Commissions Are Surging Globally',
      description:
        'From Munich’s bespoke M divisions to Molsheim’s one-of-one ateliers, flagship buyers are increasingly commissioning tailored materials over standard option lists.',
      category: 'Latest Updates',
      manufacturer: 'Bugatti',
      publishedAt: '2026-10-12',
      featuredImage: '/src/assets/images/cockpit_bespoke_interior_1795508613019.jpg',
      imageCaption: 'Fig. 10 — Individualized stitching, custom anodised metals, and curated carbon weaves dominate atelier order books.',
      isFeatured: 0,
      isTrending: 0,
      readTime: '5 min read',
      specs: {
        engine: 'Bespoke Atelier & Coachbuilding Programs',
        price: '$250,000 – $5,000,000+',
      },
      pros: [
        'Unprecedented personalization across paint chemistry, woven textiles, and acoustic tuning',
      ],
      cons: [
        'Extended 14-to-24-month commissioning lead times for one-off material development',
      ],
      verdict:
        'The modern luxury buyer no longer measures exclusivity by badge alone—provenance and individual craft now define the market.',
      rating: 9.0,
      comparisonVehicles: [],
      content: `Across Munich, Molsheim, Goodwood, and Maranello, bespoke commissioning divisions are reporting record multi-year backlogs. Rather than ticking familiar factory options, collectors are collaborating directly with color-and-trim architects to formulate proprietary pigments, woven wool upholstery, and custom-anodized metal switchgear.

This shift reflects a broader maturation in international luxury motoring. With top-tier performance thresholds now broadly accessible across flagship models, true differentiation resides in tactile execution—hand-painted coachlines, bespoke watch-grade instrument bezels, and heritage acoustic tuning tailored to a collector’s exact aesthetic vision.

Meanwhile, Mercedes-Benz, BMW, and Porsche are expanding dedicated heritage restoration and individualization lounges globally, ensuring today’s flagship grand tourers are preserved as enduring mechanical artifacts.`,
    },
    {
      slug: 'lamborghini-revuelto-v12-hybrid-supercar-blueprint',
      title: 'Lamborghini Revuelto: Sant’Agata’s 1,001-HP V12 Plug-In Hybrid Revolution',
      description:
        'Combining a roaring 6.5-liter naturally aspirated twelve-cylinder engine with three axial-flux electric motors and an all-carbon monofuselage chassis.',
      category: 'Supercars',
      manufacturer: 'Lamborghini',
      publishedAt: '2026-11-16',
      featuredImage: '/src/assets/images/gt_comparison_duo_1795508613436.jpg',
      imageCaption: 'Fig. 11 — Angular Y-signature aerodynamics sculpted around Sant’Agata’s first V12 HPEV architecture.',
      isFeatured: 1,
      isTrending: 1,
      readTime: '7 min read',
      specs: {
        engine: '6.5L NA V12 + Tri-Motor Plug-In Hybrid',
        horsepower: '1,001 hp @ 9,250 rpm',
        torque: '783 lb-ft (Combined)',
        zeroToSixty: '2.5 sec',
        topSpeed: '217 mph (350 km/h)',
        transmission: '8-Speed Transverse Dual-Clutch',
        drivetrain: 'Electronic All-Wheel Drive',
        curbWeight: '3,907 lb (1,772 kg)',
        price: '$608,358',
      },
      pros: [
        '9,500 rpm naturally aspirated V12 soundtrack amplified by instant front-axle electric torque vectoring',
        'Monofuselage carbon-fiber front structure improves torsional stiffness by 25 percent over the Aventador',
      ],
      cons: [
        'Hybrid battery packaging raises dry mass compared with pure rear-drive V8 rivals',
      ],
      verdict:
        'Lamborghini proves electrification can sharpen V12 theatricality rather than dilute it.',
      rating: 9.6,
      comparisonVehicles: [],
      content: `Rather than retiring its signature sixty-five-degree V12 in the face of global emissions mandates, Sant’Agata Bolognese reimagined the twelve-cylinder layout from the crankshaft outward. Turned 180 degrees relative to its predecessor and paired with a compact transverse eight-speed dual-clutch gearbox, the central tunnel now houses a 3.8 kWh lithium-ion battery feeding two independent front e-motors and a third rear motor.

The result is dual-personality engineering. At dawn in silent Città mode, the Revuelto glides cleanly on front-wheel electric drive without waking a neighborhood. Switch the steering-wheel rotor to Corsa, however, and all 1,001 horsepower converge simultaneously, rocketing the wedge-shaped flagship past 60 mph in 2.5 seconds while shrieking toward 9,500 rpm.`,
    },
    {
      slug: 'bugatti-tourbillon-naturally-aspirated-v16-hypercar',
      title: 'Bugatti Tourbillon: Horological Precision Meets an 8.3-Liter Naturally Aspirated V16',
      description:
        'Molsheim abandons quad-turbocharging for a bespoke Cosworth-developed V16 screaming to 9,000 rpm behind Swiss-watch mechanical instrumentation.',
      category: 'Supercars',
      manufacturer: 'Bugatti',
      publishedAt: '2026-11-12',
      featuredImage: '/src/assets/images/bugatti_tourbillon_hypercar_1795511035955.jpg',
      imageCaption: 'Fig. 12 — Two-tone exposed carbon and deep midnight blue Bugatti on cobblestones outside a French chateau.',
      isFeatured: 0,
      isTrending: 1,
      readTime: '8 min read',
      specs: {
        engine: '8.3L NA V16 + Tri-Motor Hybrid',
        horsepower: '1,775 hp (Combined)',
        torque: '664 lb-ft (V16) + E-Motors',
        zeroToSixty: '2.0 sec',
        topSpeed: '276 mph (445 km/h)',
        transmission: '8-Speed Longitudinal Dual-Clutch',
        drivetrain: 'All-Wheel Drive',
        curbWeight: '4,398 lb (1,995 kg)',
        price: '$4,100,000',
      },
      pros: [
        'One-meter-long naturally aspirated V16 delivers pure mechanical throttle response',
        'Skeletonized Swiss watchmaker gauge cluster fixed to a stationary steering hub',
      ],
      cons: [
        '250-unit global production allocation requires multi-million-dollar collector commissioning',
      ],
      verdict:
        'An epochal achievement in hypercar horology and sixteen-cylinder acoustic theater.',
      rating: 9.9,
      comparisonVehicles: [],
      content: `Few announcements in modern automotive history stunned collectors like Molsheim’s decision to succeed the quad-turbocharged W16 Chiron with an atmospheric 8.3-liter V16. Engineered alongside Cosworth, the sixteen-cylinder block weighs just 252 kilograms yet revs freely to 9,000 rpm while three electric motors elevate total system output to 1,775 horsepower.

Inside the cabin, Bugatti eliminated conventional infotainment screens from primary view. Instead, over 600 hand-assembled titanium, sapphire, and ruby components form a skeletonized mechanical instrument cluster crafted by Swiss watchmakers—ensuring the cockpit remains timeless a century from now.`,
    },
    {
      slug: 'mclaren-750s-w1-carbon-monocell-engineering',
      title: 'McLaren 750S & W1: Why Featherweight Carbon Tubs Still Rule Steering Feel',
      description:
        'Examining Woking’s relentless weight-saving discipline, electro-hydraulic steering purity, and active ground-effect aerodynamics.',
      category: 'Supercars',
      manufacturer: 'McLaren',
      publishedAt: '2026-11-09',
      featuredImage: '/src/assets/images/supercar_track_action_1795508612145.jpg',
      imageCaption: 'Fig. 13 — Lightweight carbon-tub composure across rapid elevation transitions.',
      isFeatured: 0,
      isTrending: 0,
      readTime: '6 min read',
      specs: {
        engine: '4.0L Twin-Turbocharged V8',
        horsepower: '740 hp @ 7,500 rpm',
        torque: '590 lb-ft @ 5,500 rpm',
        zeroToSixty: '2.7 sec',
        topSpeed: '206 mph (332 km/h)',
        transmission: '7-Speed Seamless Shift Dual-Clutch',
        drivetrain: 'Rear-Wheel Drive',
        curbWeight: '3,062 lb (1,389 kg)',
        price: '$324,000',
      },
      pros: [
        'Unrivaled electro-hydraulic steering feedback and panoramic forward visibility',
        'Proactive Chassis Control III blends supercar agility with genuine highway compliance',
      ],
      cons: [
        'Cabin switch layout remains purposefully spartan compared with GT rivals',
      ],
      verdict:
        'The benchmark for drivers who prize steering transparency and lightweight balance above all else.',
      rating: 9.5,
      comparisonVehicles: [],
      content: `While competitors continue adding weight in pursuit of headline power figures, McLaren’s engineering team in Woking treats every extra kilogram as an enemy of cornering fidelity. Built around the carbon-fiber Monocage II structure, the 750S tips the scales hundreds of kilograms lighter than its hybrid rivals—allowing softer spring rates, crisper turn-in, and extraordinary braking stamina.

Retaining electro-hydraulic steering assistance rather than switching to electric racks preserves the tactile road texture that separates great supercars from merely fast ones.`,
    },
    {
      slug: 'bentley-flying-spur-speed-mulliner-luxury-tourer',
      title: 'Bentley Flying Spur Speed: Mulliner Bespoke Craft Meets 771-HP V8 Hybrid Poise',
      description:
        'Crewe’s four-door flagship pairs 48-volt active roll control and hand-quilted hides with effortless all-weather grand touring velocity.',
      category: 'Luxury Cars',
      manufacturer: 'Bentley',
      publishedAt: '2026-11-10',
      featuredImage: '/src/assets/images/bentley_flying_spur_speed_1795511600969.jpg',
      imageCaption: 'Fig. 14 — Deep emerald Bentley Flying Spur Speed Mulliner outside an English stone estate at golden hour.',
      isFeatured: 0,
      isTrending: 1,
      readTime: '7 min read',
      specs: {
        engine: '4.0L Twin-Turbo V8 + Electric Motor',
        horsepower: '771 hp',
        torque: '738 lb-ft',
        zeroToSixty: '3.3 sec',
        topSpeed: '177 mph (285 km/h)',
        transmission: '8-Speed Dual-Clutch Automatic',
        drivetrain: 'All-Wheel Drive',
        curbWeight: '5,833 lb (2,646 kg)',
        price: '$272,000',
      },
      pros: [
        '47 miles of whisper-quiet pure electric urban cruising paired with 771-hp hybrid surge',
        'Rear-axle steering shrinks urban turning circles effortlessly',
      ],
      cons: [
        'Bespoke Mulliner veneers and audio upgrades add considerably to base MSRP',
      ],
      verdict:
        'A rare four-door luxury saloon that rewards chauffeur-driven passengers and enthusiastic drivers equally.',
      rating: 9.5,
      comparisonVehicles: [],
      content: `Positioned at the intersection of aristocratic limousine and continental express, the Bentley Flying Spur Speed replaces twelve-cylinder heritage with an Ultra Performance Hybrid V8 that is both cleaner and noticeably livelier.

Through winding alpine valleys, rear-wheel steering and 48-volt active anti-roll bars disguise the saloon’s 5.3-meter footprint with uncanny composure, while Wellness Seating and Mulliner diamond-quilted hides coddle rear passengers across continents.`,
    },
    {
      slug: 'mercedes-benz-maybach-s680-executive-flagship',
      title: 'Mercedes-Benz & Maybach S 680: First-Class Acoustic Serenity and V12 Authority',
      description:
        'Exploring how active road-noise cancellation, rear-cabin champagne flutes, and twelve-cylinder smoothness anchor Stuttgart’s luxury pinnacle.',
      category: 'Luxury Cars',
      manufacturer: 'Mercedes-Benz',
      publishedAt: '2026-11-06',
      featuredImage: '/src/assets/images/mercedes_maybach_s680_1795511361985.jpg',
      imageCaption: 'Fig. 15 — Two-tone obsidian and champagne gold Mercedes-Maybach S 680 arriving at dusk.',
      isFeatured: 0,
      isTrending: 1,
      readTime: '6 min read',
      specs: {
        engine: '6.0L Twin-Turbocharged V12',
        horsepower: '621 hp @ 5,250 rpm',
        torque: '664 lb-ft @ 2,000 rpm',
        zeroToSixty: '4.4 sec',
        topSpeed: '155 mph (Limited)',
        transmission: '9G-TRONIC 9-Speed Automatic',
        drivetrain: '4MATIC All-Wheel Drive',
        curbWeight: '5,291 lb (2,400 kg)',
        price: '$240,500',
      },
      pros: [
        'Active road-noise cancellation and E-ACTIVE BODY CONTROL deliver magic-carpet motorway glide',
        'Executive rear seats recline 43.5 degrees with heated calf rests and motorized doors',
      ],
      cons: [
        'Touch-capacitive steering wheel controls feel less tactile than traditional switchgear',
      ],
      verdict:
        'Mercedes-Benz continues to set the technological benchmark for rear-seat executive comfort.',
      rating: 9.4,
      comparisonVehicles: [],
      content: `For heads of state and frequent long-distance travelers, the Mercedes-Maybach S 680 remains one of the finest mobile sanctuaries ever engineered. Beneath its elongated wheelbase, stereo cameras scan tarmac imperfections ahead, adjusting hydro-pneumatic suspension struts at each corner in real time.

Inside, Burmester 4D surround speakers double as active noise-canceling transducers, neutralizing low-frequency tire resonance so rear passengers converse effortlessly at triple-digit autobahn speeds.`,
    },
    {
      slug: 'bmw-7-series-m8-competition-munich-luxury',
      title: 'BMW 7 Series & M8 Competition: Munich’s Dual Approach to Executive Luxury',
      description:
        'From cashmere-wool rear lounges with 31-inch Theatre Screens to twin-turbocharged V8 M-division grand touring performance.',
      category: 'Luxury Cars',
      manufacturer: 'BMW',
      publishedAt: '2026-11-03',
      featuredImage: '/src/assets/images/bmw_luxury_flagship_1795511361397.jpg',
      imageCaption: 'Fig. 16 — Sapphire black BMW M8 Competition and BMW 7 Series outside a modern Munich museum plaza.',
      isFeatured: 0,
      isTrending: 0,
      readTime: '6 min read',
      specs: {
        engine: '4.4L Twin-Turbo V8 (Mild Hybrid / M)',
        horsepower: '536 hp – 617 hp',
        torque: '553 lb-ft',
        zeroToSixty: '3.0 sec – 4.1 sec',
        topSpeed: '155 mph – 190 mph',
        transmission: '8-Speed M Steptronic',
        drivetrain: 'xDrive All-Wheel Drive',
        curbWeight: '4,480 lb – 5,020 lb',
        price: '$121,300 – $140,000',
      },
      pros: [
        'Available cashmere wool upholstery brings refreshing warmth over conventional hides',
        'M8 Competition delivers astonishing point-to-point pace in all weather conditions',
      ],
      cons: [
        'Polarizing exterior front-end styling divides traditional BMW purists',
      ],
      verdict:
        'Whether riding in the 7 Series executive lounge or piloting an M8 Gran Coupé, Munich balances digital innovation with sharp chassis discipline.',
      rating: 9.1,
      comparisonVehicles: [],
      content: `BMW’s flagship lineup demonstrates two distinct expressions of contemporary German luxury. In the long-wheelbase 7 Series, cashmere-wool seats, crystalline Interaction Bar lighting, and an automated 31.3-inch 8K ceiling display transform the rear compartment into a private screening lounge.

Meanwhile, the M8 Competition Gran Coupé preserves Munich’s driver-centric heritage—pairing 617 twin-turbo V8 horsepower with rear-biased M xDrive traction that devours mountain passes with sports-car precision.`,
    },
    {
      slug: 'porsche-panamera-turbo-e-hybrid-executive-gt',
      title: 'Porsche Panamera Turbo E-Hybrid: Zuffenhausen’s 670-HP Active-Ride Executive Express',
      description:
        'With Porsche Active Ride hydraulic suspension eliminating body roll and pitch, the flagship luxury fastback corners like a 911.',
      category: 'Luxury Cars',
      manufacturer: 'Porsche',
      publishedAt: '2026-10-30',
      featuredImage: '/src/assets/images/porsche_panamera_turbo_1795511037008.jpg',
      imageCaption: 'Fig. 17 — Porsche Panamera Turbo E-Hybrid overlooking an alpine lake with Turbonite accents and ceramic brakes.',
      isFeatured: 0,
      isTrending: 1,
      readTime: '6 min read',
      specs: {
        engine: '4.0L Twin-Turbo V8 + Electric Motor',
        horsepower: '670 hp',
        torque: '685 lb-ft',
        zeroToSixty: '3.0 sec',
        topSpeed: '196 mph (315 km/h)',
        transmission: '8-Speed PDK Dual-Clutch',
        drivetrain: 'All-Wheel Drive',
        curbWeight: '5,203 lb (2,360 kg)',
        price: '$191,000',
      },
      pros: [
        'Porsche Active Ride actively leans into corners like a superbike and lifts chassis height on entry',
        'Authentic sports-car steering precision rarely found in four-door luxury saloons',
      ],
      cons: [
        'Rear center seating remains strictly for occasional short trips',
      ],
      verdict:
        'The definitive four-door luxury car for enthusiasts who refuse to surrender sports-car steering feedback.',
      rating: 9.4,
      comparisonVehicles: [],
      content: `No luxury saloon bridges the divide between four-seat executive comfort and genuine circuit-bred composure like the Porsche Panamera Turbo E-Hybrid. Its breakthrough 400-volt Active Ride system employs electrically driven hydraulic pumps at every damper—allowing the car to counter pitch under hard braking and lean imperceptibly into fast sweepers.

Matched to an 8-speed PDK transmission and 670 hybrid horsepower, the Panamera covers ground across Europe with uncanny poise.`,
    },
    {
      slug: 'aston-martin-db12-volante-super-tourer',
      title: 'Aston Martin DB12 Volante: Open-Air British Super Tourer Craftsmanship',
      description:
        'Eight-layer acoustic fabric roofing and 671 twin-turbo V8 horsepower deliver coastal elegance without structural compromise.',
      category: 'Luxury Cars',
      manufacturer: 'Aston Martin',
      publishedAt: '2026-10-25',
      featuredImage: '/src/assets/images/cockpit_bespoke_interior_1795508613019.jpg',
      imageCaption: 'Fig. 18 — Hand-stitched Bridge of Weir leather paired with brushed gold rotary switchgear.',
      isFeatured: 0,
      isTrending: 0,
      readTime: '6 min read',
      specs: {
        engine: '4.0L Twin-Turbocharged V8',
        horsepower: '671 hp @ 6,000 rpm',
        torque: '590 lb-ft @ 2,750 rpm',
        zeroToSixty: '3.6 sec',
        topSpeed: '202 mph (325 km/h)',
        transmission: '8-Speed Rear-Mounted Automatic',
        drivetrain: 'Rear-Wheel Drive',
        curbWeight: '4,230 lb (1,919 kg)',
        price: '$265,000',
      },
      pros: [
        'In-house infotainment paired cleanly with solid-knurled physical climate and chassis dials',
        'Broad-shouldered proportions remain timeless from every angle',
      ],
      cons: [
        'Compact rear seats suited primarily to tailored weekend luggage',
      ],
      verdict:
        'Gaydon’s finest modern grand tourer—effortlessly glamorous and deeply rewarding down a coastal road.',
      rating: 9.3,
      comparisonVehicles: [],
      content: `Coined a "Super Tourer" by Gaydon, the DB12 Volante elevates Aston Martin’s grand touring formula with a 671-horsepower hand-built V8 and an all-new cabin architecture that pairs crisp modern displays with substantial physical metal controls.

With its eight-layer insulated roof raised, cabin refinement rivals fixed-head coupes; lowered in fourteen seconds, the twin-turbo soundtrack fills mountain canyons with unmistakable British charisma.`,
    },
  ];

  for (const item of seedArticles) {
    insertArticle.run(
      item.slug,
      item.title,
      item.description,
      item.category,
      item.manufacturer,
      'Sitoe Mkhuleko',
      item.publishedAt,
      item.featuredImage,
      item.imageCaption,
      item.content,
      item.isFeatured,
      item.isTrending,
      item.readTime,
      JSON.stringify(item.specs),
      JSON.stringify(item.pros),
      JSON.stringify(item.cons),
      item.verdict,
      item.rating,
      JSON.stringify(item.comparisonVehicles),
      `${item.title} | APEX AUTO`,
      item.description,
      now,
      now
    );
  }

  // Upgrade earlier generic placeholder image assignments on dedicated marque articles if unchanged
  const imageUpgrades: Array<{
    slug: string;
    oldImage: string;
    newImage: string;
    newCaption: string;
    newTitle?: string;
  }> = [
    {
      slug: 'bugatti-tourbillon-naturally-aspirated-v16-hypercar',
      oldImage: '/src/assets/images/hero_hypercar_showcase_1795508612490.jpg',
      newImage: '/src/assets/images/bugatti_tourbillon_hypercar_1795511035955.jpg',
      newCaption:
        'Fig. 12 — Two-tone exposed carbon and deep midnight blue Bugatti on cobblestones outside a French chateau.',
    },
    {
      slug: 'koenigsegg-jesko-absolut-high-speed-aerodynamics-analysis',
      oldImage: '/src/assets/images/hero_hypercar_showcase_1795508612490.jpg',
      newImage: '/src/assets/images/koenigsegg_jesko_attack_1795511035843.jpg',
      newCaption:
        'Fig. 7 — Koenigsegg Jesko Attack in Spa-Francorchamps pit lane showcasing its active boomerang rear wing and front dive planes.',
      newTitle:
        'Koenigsegg Jesko Attack & Absolut: Swan-Neck Downforce Meets 300+ MPH Aerodynamics',
    },
    {
      slug: 'porsche-panamera-turbo-e-hybrid-executive-gt',
      oldImage: '/src/assets/images/cockpit_bespoke_interior_1795508613019.jpg',
      newImage: '/src/assets/images/porsche_panamera_turbo_1795511037008.jpg',
      newCaption:
        'Fig. 17 — Porsche Panamera Turbo E-Hybrid overlooking an alpine lake with Turbonite accents and ceramic brakes.',
    },
    {
      slug: 'porsche-911-gt3-vs-mercedes-amg-gt63-pro-comparison',
      oldImage: '/src/assets/images/supercar_track_action_1795508612145.jpg',
      newImage: '/src/assets/images/porsche_911_gt3_rs_1795511037234.jpg',
      newCaption:
        'Fig. 8 — Weissach-equipped Porsche 911 GT3 RS carving through high-altitude alpine switchbacks.',
    },
    {
      slug: 'rolls-royce-bentley-bespoke-coachbuilding-sovereign-grand-tourer',
      oldImage: '/src/assets/images/luxury_grand_tourer_1795508613372.jpg',
      newImage: '/src/assets/images/rolls_royce_phantom_1795511361017.jpg',
      newCaption:
        'Fig. 3 — Two-tone Rolls-Royce Phantom with stainless-steel Pantheon grille and Spirit of Ecstasy on a private manor driveway.',
    },
    {
      slug: 'mercedes-benz-maybach-s680-executive-flagship',
      oldImage: '/src/assets/images/luxury_grand_tourer_1795508613372.jpg',
      newImage: '/src/assets/images/mercedes_maybach_s680_1795511361985.jpg',
      newCaption:
        'Fig. 15 — Two-tone obsidian and champagne gold Mercedes-Maybach S 680 arriving at dusk.',
    },
    {
      slug: 'bmw-7-series-m8-competition-munich-luxury',
      oldImage: '/src/assets/images/electric_hyper_gt_1795508613763.jpg',
      newImage: '/src/assets/images/bmw_luxury_flagship_1795511361397.jpg',
      newCaption:
        'Fig. 16 — Sapphire black BMW M8 Competition and BMW 7 Series outside a modern Munich museum plaza.',
    },
    {
      slug: 'bentley-flying-spur-speed-mulliner-luxury-tourer',
      oldImage: '/src/assets/images/luxury_grand_tourer_1795508613372.jpg',
      newImage: '/src/assets/images/bentley_flying_spur_speed_1795511600969.jpg',
      newCaption:
        'Fig. 14 — Deep emerald Bentley Flying Spur Speed Mulliner outside an English stone estate at golden hour.',
    },
    {
      slug: 'bentley-continental-gt-speed-hybrid-luxury-review',
      oldImage: '/src/assets/images/luxury_grand_tourer_1795508613372.jpg',
      newImage: '/src/assets/images/bentley_continental_gt_speed_1795511600687.jpg',
      newCaption:
        'Fig. 9 — Metallic tungsten-gray Bentley Continental GT Speed poised along a coastal mountain overlook.',
    },
  ];

  for (const upg of imageUpgrades) {
    if (upg.newTitle) {
      db.prepare(
        'UPDATE articles SET featured_image = ?, image_caption = ?, title = ? WHERE slug = ? AND featured_image = ?'
      ).run(upg.newImage, upg.newCaption, upg.newTitle, upg.slug, upg.oldImage);
    } else {
      db.prepare(
        'UPDATE articles SET featured_image = ?, image_caption = ? WHERE slug = ? AND featured_image = ?'
      ).run(upg.newImage, upg.newCaption, upg.slug, upg.oldImage);
    }
  }
}

seedDefaults();

function safeJsonParse<T>(raw: string | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function mapArticleRow(row: Record<string, unknown>): Article {
  return {
    id: Number(row.id),
    slug: String(row.slug),
    title: String(row.title),
    description: String(row.description),
    category: String(row.category) as ArticleCategory,
    manufacturer: String(row.manufacturer || ''),
    author: String(row.author || 'Sitoe Mkhuleko'),
    publishedAt: String(row.published_at),
    featuredImage: String(row.featured_image),
    imageCaption: String(row.image_caption || ''),
    content: String(row.content),
    isFeatured: Boolean(row.is_featured),
    isTrending: Boolean(row.is_trending),
    readTime: String(row.read_time || '5 min read'),
    specs: safeJsonParse<VehicleSpecs>(row.specs_json as string, {}),
    pros: safeJsonParse<string[]>(row.pros_json as string, []),
    cons: safeJsonParse<string[]>(row.cons_json as string, []),
    verdict: String(row.verdict || ''),
    rating: Number(row.rating || 0),
    comparisonVehicles: safeJsonParse<ComparisonVehicle[]>(row.comparison_json as string, []),
    seoTitle: String(row.seo_title || ''),
    seoDescription: String(row.seo_description || ''),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export function getAllArticles(category?: string, query?: string): Article[] {
  let sql = 'SELECT * FROM articles';
  const conditions: string[] = [];
  const params: string[] = [];

  if (category && category !== 'All') {
    conditions.push('category = ?');
    params.push(category);
  }
  if (query && query.trim()) {
    conditions.push('(title LIKE ? OR description LIKE ? OR manufacturer LIKE ? OR content LIKE ?)');
    const like = `%${query.trim()}%`;
    params.push(like, like, like, like);
  }

  if (conditions.length > 0) {
    sql += ' WHERE ' + conditions.join(' AND ');
  }

  sql += ' ORDER BY published_at DESC, id DESC';
  const rows = db.prepare(sql).all(...params) as Array<Record<string, unknown>>;
  return rows.map(mapArticleRow);
}

export function getArticleBySlug(slug: string): Article | null {
  const row = db.prepare('SELECT * FROM articles WHERE slug = ?').get(slug) as
    | Record<string, unknown>
    | undefined;
  return row ? mapArticleRow(row) : null;
}

export function getArticleById(id: number): Article | null {
  const row = db.prepare('SELECT * FROM articles WHERE id = ?').get(id) as
    | Record<string, unknown>
    | undefined;
  return row ? mapArticleRow(row) : null;
}

export function createArticle(input: Omit<Article, 'id' | 'createdAt' | 'updatedAt'>): Article {
  const now = new Date().toISOString();
  const stmt = db.prepare(`
    INSERT INTO articles (
      slug, title, description, category, manufacturer, author, published_at,
      featured_image, image_caption, content, is_featured, is_trending, read_time,
      specs_json, pros_json, cons_json, verdict, rating, comparison_json,
      seo_title, seo_description, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const result = stmt.run(
    input.slug,
    input.title,
    input.description,
    input.category,
    input.manufacturer || '',
    input.author || 'Sitoe Mkhuleko',
    input.publishedAt,
    input.featuredImage,
    input.imageCaption || '',
    input.content,
    input.isFeatured ? 1 : 0,
    input.isTrending ? 1 : 0,
    input.readTime || '5 min read',
    JSON.stringify(input.specs || {}),
    JSON.stringify(input.pros || []),
    JSON.stringify(input.cons || []),
    input.verdict || '',
    Number(input.rating || 0),
    JSON.stringify(input.comparisonVehicles || []),
    input.seoTitle || input.title,
    input.seoDescription || input.description,
    now,
    now
  );

  return getArticleById(Number(result.lastInsertRowid))!;
}

export function updateArticle(
  id: number,
  input: Partial<Omit<Article, 'id' | 'createdAt' | 'updatedAt'>>
): Article | null {
  const existing = getArticleById(id);
  if (!existing) return null;

  const now = new Date().toISOString();
  const merged = {
    ...existing,
    ...input,
  };

  db.prepare(`
    UPDATE articles SET
      slug = ?, title = ?, description = ?, category = ?, manufacturer = ?,
      author = ?, published_at = ?, featured_image = ?, image_caption = ?,
      content = ?, is_featured = ?, is_trending = ?, read_time = ?,
      specs_json = ?, pros_json = ?, cons_json = ?, verdict = ?, rating = ?,
      comparison_json = ?, seo_title = ?, seo_description = ?, updated_at = ?
    WHERE id = ?
  `).run(
    merged.slug,
    merged.title,
    merged.description,
    merged.category,
    merged.manufacturer,
    merged.author,
    merged.publishedAt,
    merged.featuredImage,
    merged.imageCaption,
    merged.content,
    merged.isFeatured ? 1 : 0,
    merged.isTrending ? 1 : 0,
    merged.readTime,
    JSON.stringify(merged.specs),
    JSON.stringify(merged.pros),
    JSON.stringify(merged.cons),
    merged.verdict,
    Number(merged.rating || 0),
    JSON.stringify(merged.comparisonVehicles),
    merged.seoTitle || merged.title,
    merged.seoDescription || merged.description,
    now,
    id
  );

  return getArticleById(id);
}

export function deleteArticle(id: number): boolean {
  const result = db.prepare('DELETE FROM articles WHERE id = ?').run(id);
  return result.changes > 0;
}

export function getSiteSettings(): SiteSettings {
  const rows = db.prepare('SELECT key, value FROM site_settings').all() as Array<{
    key: string;
    value: string;
  }>;
  const map = new Map<string, string>(rows.map((r) => [r.key, r.value]));

  return {
    publisherName: map.get('publisher_name') ?? DEFAULT_SETTINGS.publisherName,
    publisherBio: map.get('publisher_bio') ?? DEFAULT_SETTINGS.publisherBio,
    publisherPhoto: map.get('publisher_photo') ?? DEFAULT_SETTINGS.publisherPhoto,
    aboutContent: map.get('about_content') ?? DEFAULT_SETTINGS.aboutContent,
    privacyPolicy: map.get('privacy_policy') ?? DEFAULT_SETTINGS.privacyPolicy,
    cookiePolicy: map.get('cookie_policy') ?? DEFAULT_SETTINGS.cookiePolicy,
    termsContent: map.get('terms_content') ?? DEFAULT_SETTINGS.termsContent,
    instagramUrl: map.get('instagram_url') ?? DEFAULT_SETTINGS.instagramUrl,
    facebookUrl: map.get('facebook_url') ?? DEFAULT_SETTINGS.facebookUrl,
    seoSiteTitle: map.get('seo_site_title') ?? DEFAULT_SETTINGS.seoSiteTitle,
    seoSiteDescription: map.get('seo_site_description') ?? DEFAULT_SETTINGS.seoSiteDescription,
    googleSiteVerification: map.get('google_site_verification') ?? '',
    adsensePublisherId: map.get('adsense_publisher_id') ?? '',
    adPlacements: safeJsonParse<AdPlacements>(
      map.get('ad_placements_json'),
      DEFAULT_AD_PLACEMENTS
    ),
  };
}

export function updateSiteSettings(partial: Partial<SiteSettings>): SiteSettings {
  const upsert = db.prepare(
    'INSERT INTO site_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
  );

  const pairs: Array<[string, string | undefined]> = [
    ['publisher_name', partial.publisherName],
    ['publisher_bio', partial.publisherBio],
    ['publisher_photo', partial.publisherPhoto],
    ['about_content', partial.aboutContent],
    ['privacy_policy', partial.privacyPolicy],
    ['cookie_policy', partial.cookiePolicy],
    ['terms_content', partial.termsContent],
    ['instagram_url', partial.instagramUrl],
    ['facebook_url', partial.facebookUrl],
    ['seo_site_title', partial.seoSiteTitle],
    ['seo_site_description', partial.seoSiteDescription],
    ['google_site_verification', partial.googleSiteVerification],
    ['adsense_publisher_id', partial.adsensePublisherId],
    [
      'ad_placements_json',
      partial.adPlacements ? JSON.stringify(partial.adPlacements) : undefined,
    ],
  ];

  for (const [k, v] of pairs) {
    if (v !== undefined) {
      upsert.run(k, v);
    }
  }

  return getSiteSettings();
}

export function subscribeNewsletter(emailRaw: string): {
  alreadySubscribed: boolean;
  unsubscribeToken: string;
} {
  const email = emailRaw.trim().toLowerCase();
  const now = new Date().toISOString();

  const existing = db
    .prepare('SELECT id, status, unsubscribe_token FROM newsletter_subscribers WHERE email = ?')
    .get(email) as { id: number; status: string; unsubscribe_token: string } | undefined;

  if (existing) {
    if (existing.status === 'active') {
      return { alreadySubscribed: true, unsubscribeToken: existing.unsubscribe_token };
    }
    const newToken = crypto.randomBytes(24).toString('hex');
    db.prepare(
      'UPDATE newsletter_subscribers SET status = ?, consent_given = 1, unsubscribe_token = ?, subscribed_at = ?, unsubscribed_at = NULL WHERE id = ?'
    ).run('active', newToken, now, existing.id);
    return { alreadySubscribed: false, unsubscribeToken: newToken };
  }

  const token = crypto.randomBytes(24).toString('hex');
  db.prepare(
    'INSERT INTO newsletter_subscribers (email, status, consent_given, unsubscribe_token, subscribed_at) VALUES (?, ?, 1, ?, ?)'
  ).run(email, 'active', token, now);

  return { alreadySubscribed: false, unsubscribeToken: token };
}

export function unsubscribeNewsletter(params: { token?: string; email?: string }): boolean {
  const now = new Date().toISOString();
  if (params.token) {
    const res = db
      .prepare(
        'UPDATE newsletter_subscribers SET status = ?, unsubscribed_at = ? WHERE unsubscribe_token = ? AND status = ?'
      )
      .run('unsubscribed', now, params.token.trim(), 'active');
    return res.changes > 0;
  }
  if (params.email) {
    const res = db
      .prepare(
        'UPDATE newsletter_subscribers SET status = ?, unsubscribed_at = ? WHERE email = ? AND status = ?'
      )
      .run('unsubscribed', now, params.email.trim().toLowerCase(), 'active');
    return res.changes > 0;
  }
  return false;
}

export function listSubscribersForAdmin(): SubscriberRecord[] {
  const rows = db
    .prepare(
      'SELECT id, email, status, subscribed_at, unsubscribed_at FROM newsletter_subscribers ORDER BY subscribed_at DESC'
    )
    .all() as Array<Record<string, unknown>>;

  return rows.map((r) => ({
    id: Number(r.id),
    email: String(r.email),
    status: String(r.status) as 'active' | 'unsubscribed',
    subscribedAt: String(r.subscribed_at),
    unsubscribedAt: r.unsubscribed_at ? String(r.unsubscribed_at) : null,
  }));
}

export function deleteSubscriberById(id: number): boolean {
  const res = db.prepare('DELETE FROM newsletter_subscribers WHERE id = ?').run(id);
  return res.changes > 0;
}

export function createContactMessage(payload: {
  name: string;
  email: string;
  subject: string;
  message: string;
}): number {
  const now = new Date().toISOString();
  const res = db
    .prepare(
      'INSERT INTO contact_messages (name, email, subject, message, status, created_at) VALUES (?, ?, ?, ?, ?, ?)'
    )
    .run(payload.name, payload.email, payload.subject, payload.message, 'unread', now);
  return Number(res.lastInsertRowid);
}

export function listContactMessagesForAdmin(): ContactMessageRecord[] {
  const rows = db
    .prepare('SELECT * FROM contact_messages ORDER BY created_at DESC')
    .all() as Array<Record<string, unknown>>;
  return rows.map((r) => ({
    id: Number(r.id),
    name: String(r.name),
    email: String(r.email),
    subject: String(r.subject),
    message: String(r.message),
    status: String(r.status) as 'unread' | 'read',
    createdAt: String(r.created_at),
  }));
}

export function markContactMessageStatus(id: number, status: 'read' | 'unread'): boolean {
  const res = db.prepare('UPDATE contact_messages SET status = ? WHERE id = ?').run(status, id);
  return res.changes > 0;
}

export function deleteContactMessage(id: number): boolean {
  const res = db.prepare('DELETE FROM contact_messages WHERE id = ?').run(id);
  return res.changes > 0;
}

// --- Admin Credentials & Sessions ---

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPasswordHash(password: string, stored: string): boolean {
  const parts = stored.split(':');
  if (parts.length !== 2) return false;
  const [salt, hashHex] = parts;
  const derived = crypto.scryptSync(password, salt, 64);
  const target = Buffer.from(hashHex, 'hex');
  if (derived.length !== target.length) return false;
  return crypto.timingSafeEqual(derived, target);
}

function timingSafeStringMatch(a: string, b: string): boolean {
  const hashA = crypto.createHash('sha256').update(a).digest();
  const hashB = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(hashA, hashB);
}

export function getAdminAuthStatus(): { needsSetup: boolean; usesEnvPasscode: boolean } {
  const envPass = (process.env.ADMIN_PASSCODE || '').trim();
  if (envPass.length > 0) {
    return { needsSetup: false, usesEnvPasscode: true };
  }
  const row = db.prepare('SELECT id FROM admin_credentials WHERE id = 1').get();
  return { needsSetup: !row, usesEnvPasscode: false };
}

export function claimInitialAdminPassword(password: string): { ok: boolean; error?: string } {
  const status = getAdminAuthStatus();
  if (!status.needsSetup) {
    return { ok: false, error: 'Administrator credentials are already configured.' };
  }
  if (password.length < 8) {
    return { ok: false, error: 'Administrator password must be at least 8 characters long.' };
  }
  const hashed = hashPassword(password);
  db.prepare(
    'INSERT INTO admin_credentials (id, password_hash, created_at) VALUES (1, ?, ?)'
  ).run(hashed, new Date().toISOString());
  return { ok: true };
}

export function verifyAdminPasscode(password: string): boolean {
  const envPass = (process.env.ADMIN_PASSCODE || '').trim();
  if (envPass.length > 0) {
    return timingSafeStringMatch(password, envPass);
  }
  const row = db
    .prepare('SELECT password_hash FROM admin_credentials WHERE id = 1')
    .get() as { password_hash: string } | undefined;
  if (!row) return false;
  return verifyPasswordHash(password, row.password_hash);
}

export function createAdminSession(): string {
  const now = Date.now();
  db.prepare('DELETE FROM admin_sessions WHERE expires_at < ?').run(now);
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = now + 24 * 60 * 60 * 1000;
  db.prepare('INSERT INTO admin_sessions (token, expires_at) VALUES (?, ?)').run(token, expiresAt);
  return token;
}

export function validateAdminSession(token: string): boolean {
  if (!token) return false;
  const row = db
    .prepare('SELECT expires_at FROM admin_sessions WHERE token = ?')
    .get(token) as { expires_at: number } | undefined;
  if (!row) return false;
  if (row.expires_at < Date.now()) {
    db.prepare('DELETE FROM admin_sessions WHERE token = ?').run(token);
    return false;
  }
  return true;
}

export function revokeAdminSession(token: string): void {
  db.prepare('DELETE FROM admin_sessions WHERE token = ?').run(token);
}
