import nodemailer from 'nodemailer';
import type { EmailServiceStatus } from '../shared/types.ts';

function getSmtpConfig() {
  const host = (process.env.SMTP_HOST || '').trim();
  const portRaw = (process.env.SMTP_PORT || '587').trim();
  const port = Number.parseInt(portRaw, 10) || 587;
  const user = (process.env.SMTP_USER || '').trim();
  const pass = (process.env.SMTP_PASS || '').trim();
  const from = (process.env.SMTP_FROM || 'APEX AUTO <editorial@apexauto.example.com>').trim();
  const contactTo = (process.env.SMTP_CONTACT_TO || user).trim();

  const configured = Boolean(host && user && pass);
  return { configured, host, port, user, pass, from, contactTo };
}

export function getEmailServiceStatus(): EmailServiceStatus {
  const cfg = getSmtpConfig();
  return {
    configured: cfg.configured,
    providerLabel: cfg.configured ? `SMTP (${cfg.host})` : 'Not Configured (Database Storage Active)',
  };
}

function createTransporter() {
  const cfg = getSmtpConfig();
  if (!cfg.configured) return null;

  return {
    transporter: nodemailer.createTransport({
      host: cfg.host,
      port: cfg.port,
      secure: cfg.port === 465,
      auth: {
        user: cfg.user,
        pass: cfg.pass,
      },
    }),
    from: cfg.from,
    contactTo: cfg.contactTo,
  };
}

export async function sendWelcomeNewsletterEmail(
  recipientEmail: string,
  unsubscribeUrl: string
): Promise<{ sent: boolean; reason?: string }> {
  const client = createTransporter();
  if (!client) {
    return { sent: false, reason: 'SMTP_NOT_CONFIGURED' };
  }

  try {
    await client.transporter.sendMail({
      from: client.from,
      to: recipientEmail,
      subject: 'Welcome to APEX AUTO — The World of Performance & Luxury',
      text: [
        'Thank you for subscribing to APEX AUTO.',
        '',
        'You are now subscribed to receive the latest supercar news, luxury car stories, comparisons, and automotive updates curated by publisher Sitoe Mkhuleko.',
        '',
        `To unsubscribe at any time, visit: ${unsubscribeUrl}`,
      ].join('\n'),
      html: `
        <div style="font-family: Georgia, serif; max-width: 600px; margin: 0 auto; background: #0A0A0C; color: #FAF9F6; padding: 36px; border: 1px solid #C9A24D;">
          <p style="font-family: sans-serif; font-size: 11px; letter-spacing: 0.22em; color: #C9A24D; margin: 0 0 12px;">APEX AUTO</p>
          <h1 style="font-size: 28px; font-weight: 600; margin: 0 0 16px; color: #FFFFFF;">Stay Ahead of the Curve</h1>
          <p style="font-family: sans-serif; font-size: 15px; line-height: 1.6; color: #D4D4D8; margin: 0 0 24px;">
            Thank you for subscribing to APEX AUTO — The World of Performance &amp; Luxury, published by Sitoe Mkhuleko.
            You will receive our latest supercar dispatches, bespoke luxury features, specification comparisons, and road tests.
          </p>
          <hr style="border: 0; border-top: 1px solid rgba(201,162,77,0.3); margin: 24px 0;" />
          <p style="font-family: sans-serif; font-size: 12px; color: #A1A1AA; margin: 0;">
            No longer wish to receive editorial updates?
            <a href="${unsubscribeUrl}" style="color: #C9A24D; text-decoration: underline;">Unsubscribe from APEX AUTO</a>.
          </p>
        </div>
      `,
    });
    return { sent: true };
  } catch (err) {
    console.error('Failed to send welcome email:', err);
    return { sent: false, reason: 'SMTP_DELIVERY_FAILED' };
  }
}

export async function sendContactNotificationEmail(payload: {
  name: string;
  email: string;
  subject: string;
  message: string;
}): Promise<{ sent: boolean; reason?: string }> {
  const client = createTransporter();
  if (!client || !client.contactTo) {
    return { sent: false, reason: 'SMTP_NOT_CONFIGURED' };
  }

  try {
    await client.transporter.sendMail({
      from: client.from,
      to: client.contactTo,
      replyTo: payload.email,
      subject: `[APEX AUTO Contact] ${payload.subject}`,
      text: [
        `New editorial contact message received via APEX AUTO:`,
        '',
        `From: ${payload.name} <${payload.email}>`,
        `Subject: ${payload.subject}`,
        '',
        payload.message,
      ].join('\n'),
    });
    return { sent: true };
  } catch (err) {
    console.error('Failed to send contact notification email:', err);
    return { sent: false, reason: 'SMTP_DELIVERY_FAILED' };
  }
}
