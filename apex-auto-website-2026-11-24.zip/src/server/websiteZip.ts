import fs from 'node:fs';
import path from 'node:path';
import { strToU8, zipSync } from 'fflate';

const ALLOWLIST_ROOT_FILES = [
  'package.json',
  'tsconfig.json',
  'vite.config.ts',
  'index.html',
  'metadata.json',
  '.env.example',
  '.gitignore',
  'server.ts',
];

const ALLOWLIST_DIRS = ['src', 'public', 'uploads'];

function isExcludedName(name: string): boolean {
  if (name === 'node_modules' || name === 'dist' || name === '.git' || name === 'data') {
    return true;
  }
  if (name === '.DS_Store' || name.endsWith('.log') || name.includes('.sqlite')) {
    return true;
  }
  if (name.startsWith('.env') && name !== '.env.example') {
    return true;
  }
  return false;
}

function collectDirectoryFiles(
  rootDir: string,
  relDir: string,
  entries: Record<string, Uint8Array>
): void {
  const fullDir = path.resolve(rootDir, relDir);
  if (
    !fullDir.startsWith(rootDir + path.sep) ||
    !fs.existsSync(fullDir) ||
    !fs.statSync(fullDir).isDirectory()
  ) {
    return;
  }

  const dirItems = fs.readdirSync(fullDir, { withFileTypes: true });
  for (const item of dirItems) {
    if (isExcludedName(item.name) || item.isSymbolicLink()) {
      continue;
    }
    const itemRelPath = path.posix.join(relDir.replace(/\\/g, '/'), item.name);
    const itemFullPath = path.resolve(rootDir, itemRelPath);
    if (!itemFullPath.startsWith(rootDir + path.sep)) {
      continue;
    }

    if (item.isDirectory()) {
      collectDirectoryFiles(rootDir, itemRelPath, entries);
    } else if (item.isFile()) {
      entries[itemRelPath] = new Uint8Array(fs.readFileSync(itemFullPath));
    }
  }
}

export function buildWebsiteSourceZip(): Uint8Array {
  const rootDir = path.resolve(process.cwd());
  const entries: Record<string, Uint8Array> = {};

  for (const filename of ALLOWLIST_ROOT_FILES) {
    const fullPath = path.resolve(rootDir, filename);
    if (fullPath.startsWith(rootDir + path.sep) && fs.existsSync(fullPath)) {
      const stat = fs.lstatSync(fullPath);
      if (stat.isFile() && !stat.isSymbolicLink()) {
        entries[filename] = new Uint8Array(fs.readFileSync(fullPath));
      }
    }
  }

  for (const dirName of ALLOWLIST_DIRS) {
    collectDirectoryFiles(rootDir, dirName, entries);
  }

  const deployReadme = [
    'APEX AUTO — Full-Stack Website Package',
    '=======================================',
    '',
    'This ZIP contains the complete APEX AUTO website (React + Express + SQLite).',
    'No secret keys, password hashes, or private user records were included.',
    '',
    'Recommended Hosting Platforms (Node.js 22+):',
    '  1. Render (render.com) — Web Service with Persistent Disk mounted at /data and /uploads',
    '  2. Railway (railway.app) — Node.js service with persistent Volume',
    '  3. Google Cloud Run or a Node.js 22+ VPS',
    '',
    'Note: Do NOT upload to static HTML-only hosts (like basic shared HTML folders',
    'or GitHub Pages), because APEX AUTO runs a Node.js backend and SQLite database.',
    '',
    'Build & Start Commands:',
    '  Build Command: npm install && npm run build',
    '  Start Command: NODE_ENV=production npm start',
    '',
    'Environment Variables (set in your hosting dashboard):',
    '  NODE_ENV=production',
    '  APP_URL=https://your-domain.com',
    '  ADMIN_PASSCODE=your-strong-admin-password',
    '  (Optional SMTP vars for live email: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM)',
    '',
  ].join('\n');

  entries['DEPLOY_README.txt'] = strToU8(deployReadme);

  return zipSync(entries, { level: 6 });
}
