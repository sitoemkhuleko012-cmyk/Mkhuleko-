export type ArticleCategory =
  | 'Supercars'
  | 'Luxury Cars'
  | 'Comparisons'
  | 'Car Reviews'
  | 'Latest Updates';

export interface VehicleSpecs {
  engine?: string;
  horsepower?: string;
  torque?: string;
  zeroToSixty?: string;
  topSpeed?: string;
  transmission?: string;
  drivetrain?: string;
  curbWeight?: string;
  price?: string;
}

export interface ComparisonVehicle {
  name: string;
  manufacturer: string;
  engine: string;
  horsepower: string;
  torque: string;
  zeroToSixty: string;
  topSpeed: string;
  weight: string;
  price: string;
  drivetrain: string;
}

export interface Article {
  id: number;
  slug: string;
  title: string;
  description: string;
  category: ArticleCategory;
  manufacturer: string;
  author: string;
  publishedAt: string;
  featuredImage: string;
  imageCaption: string;
  content: string;
  isFeatured: boolean;
  isTrending: boolean;
  readTime: string;
  specs: VehicleSpecs;
  pros: string[];
  cons: string[];
  verdict: string;
  rating: number;
  comparisonVehicles: ComparisonVehicle[];
  seoTitle: string;
  seoDescription: string;
  createdAt: string;
  updatedAt: string;
}

export interface AdPlacements {
  headerBannerEnabled: boolean;
  inArticleEnabled: boolean;
  sidebarEnabled: boolean;
  footerBannerEnabled: boolean;
}

export interface SiteSettings {
  publisherName: string;
  publisherBio: string;
  publisherPhoto: string;
  aboutContent: string;
  privacyPolicy: string;
  cookiePolicy: string;
  termsContent: string;
  instagramUrl: string;
  facebookUrl: string;
  seoSiteTitle: string;
  seoSiteDescription: string;
  googleSiteVerification: string;
  adsensePublisherId: string;
  adPlacements: AdPlacements;
}

export interface CookiePreferences {
  essential: true;
  analytics: boolean;
  advertising: boolean;
  updatedAt: string;
  version: number;
}

export interface SubscriberRecord {
  id: number;
  email: string;
  status: 'active' | 'unsubscribed';
  subscribedAt: string;
  unsubscribedAt: string | null;
}

export interface ContactMessageRecord {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: 'unread' | 'read';
  createdAt: string;
}

export interface EmailServiceStatus {
  configured: boolean;
  providerLabel: string;
}
