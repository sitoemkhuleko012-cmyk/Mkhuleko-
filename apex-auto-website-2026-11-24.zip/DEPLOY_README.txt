APEX AUTO — Full-Stack Website Package
=======================================

This ZIP contains the complete APEX AUTO website (React + Express + SQLite).
No secret keys, password hashes, or private user records were included.

Recommended Hosting Platforms (Node.js 22+):
  1. Render (render.com) — Web Service with Persistent Disk mounted at /data and /uploads
  2. Railway (railway.app) — Node.js service with persistent Volume
  3. Google Cloud Run or a Node.js 22+ VPS

Note: Do NOT upload to static HTML-only hosts (like basic shared HTML folders
or GitHub Pages), because APEX AUTO runs a Node.js backend and SQLite database.

Build & Start Commands:
  Build Command: npm install && npm run build
  Start Command: NODE_ENV=production npm start

Environment Variables (set in your hosting dashboard):
  NODE_ENV=production
  APP_URL=https://your-domain.com
  ADMIN_PASSCODE=your-strong-admin-password
  (Optional SMTP vars for live email: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM)
